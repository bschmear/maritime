<?php

declare(strict_types=1);

if (! defined('ABSPATH')) {
    exit;
}

$layoutDescriptions = [
    Helmful_Sync_Display::LAYOUT_STACKED => __('Full-width cards with nested events.', 'helmful-sync'),
    Helmful_Sync_Display::LAYOUT_GRID => __('Responsive multi-column card grid.', 'helmful-sync'),
    Helmful_Sync_Display::LAYOUT_TIMELINE => __('Events ordered by date on a timeline.', 'helmful-sync'),
    Helmful_Sync_Display::LAYOUT_COMPACT => __('Dense table-style rows for scanning.', 'helmful-sync'),
];

$tabUrl = static function (string $tab) use ($notice, $error, $revealedKey): string {
    $args = ['page' => 'helmful-sync', 'tab' => $tab];
    if ($notice !== '') {
        $args['helmful_notice'] = $notice;
    }
    if ($error !== '') {
        $args['helmful_error'] = $error;
    }
    if ($revealedKey !== '') {
        $args['helmful_new_key'] = $revealedKey;
    }

    return add_query_arg($args, admin_url('admin.php?page=helmful-sync'));
};

$renderColorFields = static function (array $labels, array $display) : void {
    foreach ($labels as $colorKey => $colorLabel) {
        $fieldId = 'helmful_'.str_replace('_', '-', $colorKey);
        $colorValue = $display[$colorKey] ?? Helmful_Sync_Display_Settings::color_defaults()[$colorKey];
        ?>
        <tr>
            <th scope="row"><label for="<?php echo esc_attr($fieldId); ?>"><?php echo esc_html($colorLabel); ?></label></th>
            <td>
                <div class="helmful-color-field" data-color-field="<?php echo esc_attr($colorKey); ?>">
                    <input type="color" id="<?php echo esc_attr($fieldId); ?>" name="helmful_sync_settings[display][<?php echo esc_attr($colorKey); ?>]" value="<?php echo esc_attr($colorValue); ?>">
                    <input type="text" class="helmful-color-field__text" value="<?php echo esc_attr($colorValue); ?>" pattern="^#[0-9a-fA-F]{6}$" aria-label="<?php echo esc_attr($colorLabel); ?>">
                </div>
            </td>
        </tr>
        <?php
    }
};

?>
<div class="wrap helmful-sync-settings">
    <style>
        .helmful-sync-settings .helmful-admin-panel { display: none; }
        .helmful-sync-settings .helmful-admin-panel.is-active { display: block; }
    </style>
    <h1><?php esc_html_e('Helmful Sync', 'helmful-sync'); ?></h1>
    <p><?php esc_html_e('Connect WordPress to Helmful, sync boat shows, brands, and inventory, and control how they appear on your site.', 'helmful-sync'); ?></p>

    <?php if ($notice !== '') { ?>
        <div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice); ?></p></div>
    <?php } ?>

    <?php if ($error !== '') { ?>
        <div class="notice notice-error is-dismissible"><p><?php echo esc_html($error); ?></p></div>
    <?php } ?>

    <nav class="nav-tab-wrapper helmful-admin-tabs" aria-label="<?php esc_attr_e('Helmful Sync sections', 'helmful-sync'); ?>">
        <a href="<?php echo esc_url($tabUrl('general')); ?>" class="nav-tab<?php echo $activeTab === 'general' ? ' nav-tab-active' : ''; ?>" data-tab="general">
            <?php esc_html_e('General', 'helmful-sync'); ?>
        </a>
        <a href="<?php echo esc_url($tabUrl('boat-shows')); ?>" class="nav-tab<?php echo $activeTab === 'boat-shows' ? ' nav-tab-active' : ''; ?>" data-tab="boat-shows">
            <?php esc_html_e('Boat Show Design', 'helmful-sync'); ?>
        </a>
        <a href="<?php echo esc_url($tabUrl('inventory')); ?>" class="nav-tab<?php echo $activeTab === 'inventory' ? ' nav-tab-active' : ''; ?>" data-tab="inventory">
            <?php esc_html_e('Inventory Design', 'helmful-sync'); ?>
        </a>
        <a href="<?php echo esc_url($tabUrl('brands')); ?>" class="nav-tab<?php echo $activeTab === 'brands' ? ' nav-tab-active' : ''; ?>" data-tab="brands">
            <?php esc_html_e('Brands Design', 'helmful-sync'); ?>
        </a>
    </nav>

    <!-- ====================================================
         GENERAL TAB
         ==================================================== -->
    <div class="helmful-admin-panel<?php echo $activeTab === 'general' ? ' is-active' : ''; ?>" data-panel="general">

        <!-- Helmful credentials -->
        <div class="helmful-section">
            <h2><?php esc_html_e('Helmful credentials', 'helmful-sync'); ?></h2>
            <p><?php esc_html_e('Your workspace domain and API key from the Helmful integrations page.', 'helmful-sync'); ?></p>

            <form method="post" action="options.php" autocomplete="off">
                <?php settings_fields('helmful_sync'); ?>
                <input type="hidden" name="helmful_active_tab" value="general">
                <!-- Absorb browser/password-manager autofill on fresh install -->
                <div class="helmful-autofill-guard" aria-hidden="true">
                    <input type="text" name="helmful_autofill_trap_user" tabindex="-1" autocomplete="username">
                    <input type="password" name="helmful_autofill_trap_pass" tabindex="-1" autocomplete="current-password">
                </div>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="tenant_domain"><?php esc_html_e('Tenant domain', 'helmful-sync'); ?></label></th>
                        <td>
                            <input
                                name="helmful_sync_settings[tenant_domain]"
                                id="tenant_domain"
                                type="text"
                                class="regular-text helmful-no-autofill"
                                value="<?php echo esc_attr($settings['tenant_domain'] ?? ''); ?>"
                                placeholder="123456.helmful.com"
                                autocomplete="off"
                                autocapitalize="off"
                                autocorrect="off"
                                spellcheck="false"
                                data-lpignore="true"
                                data-1p-ignore
                            />
                            <p class="description"><?php esc_html_e('For local sites, use the domain only — no https:// prefix.', 'helmful-sync'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="helmful_api_key"><?php esc_html_e('API key', 'helmful-sync'); ?></label></th>
                        <td>
                            <?php
                            $hasHelmfulApiKey = trim((string) ($settings['helmful_api_key'] ?? '')) !== '';
                            ?>
                            <input
                                name="helmful_sync_settings[helmful_api_key]"
                                id="helmful_api_key"
                                type="password"
                                class="regular-text helmful-no-autofill"
                                value=""
                                placeholder="<?php echo $hasHelmfulApiKey
                                    ? esc_attr__('Saved — enter a new key only to replace', 'helmful-sync')
                                    : esc_attr__('Paste the key from Helmful', 'helmful-sync'); ?>"
                                autocomplete="new-password"
                                data-lpignore="true"
                                data-1p-ignore
                            />
                            <?php if ($hasHelmfulApiKey) { ?>
                                <p class="description"><?php esc_html_e('An API key is saved. Leave this field blank to keep it.', 'helmful-sync'); ?></p>
                            <?php } else { ?>
                                <p class="description"><?php esc_html_e('Generated on the Helmful WordPress integration page.', 'helmful-sync'); ?></p>
                            <?php } ?>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Save credentials', 'helmful-sync')); ?>
            </form>
        </div>

        <!-- WordPress API key -->
        <div class="helmful-section">
            <h2><?php esc_html_e('WordPress API key', 'helmful-sync'); ?></h2>
            <p><?php esc_html_e('Generate a key here and paste it into Helmful so it can push data to this site.', 'helmful-sync'); ?></p>

            <?php if (Helmful_Sync_Settings::has_api_key()) { ?>
                <div class="helmful-status-badge"><?php esc_html_e('API key configured', 'helmful-sync'); ?></div>
            <?php } ?>

            <?php if ($revealedKey !== '') { ?>
                <code class="helmful-key-reveal"><?php echo esc_html($revealedKey); ?></code>
                <p class="description" style="margin-bottom:1rem;"><?php esc_html_e('Copy this key and paste it into Helmful. It won\'t be shown again.', 'helmful-sync'); ?></p>
            <?php } ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('helmful_sync_generate_key'); ?>
                <input type="hidden" name="action" value="helmful_sync_generate_key">
                <input type="hidden" name="helmful_active_tab" value="general">
                <?php submit_button(__('Generate new API key', 'helmful-sync'), 'secondary'); ?>
            </form>
        </div>

        <!-- Sync -->
        <div class="helmful-section">
            <h2><?php esc_html_e('Sync', 'helmful-sync'); ?></h2>
            <p><?php esc_html_e('Pull content from Helmful into WordPress, or test that the connection is working.', 'helmful-sync'); ?></p>

            <?php if ($lastPull !== '') { ?>
                <p class="description" style="margin-bottom:1rem;"><?php echo esc_html(sprintf(__('Last pull: %s', 'helmful-sync'), $lastPull)); ?></p>
            <?php } ?>

            <div class="helmful-action-row">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('helmful_sync_test'); ?>
                    <input type="hidden" name="action" value="helmful_sync_test">
                    <input type="hidden" name="helmful_active_tab" value="general">
                    <?php submit_button(__('Test connection', 'helmful-sync'), 'secondary', 'submit', false); ?>
                </form>
            </div>

            <h3 class="helmful-sync-subheading"><?php esc_html_e('Pull from Helmful', 'helmful-sync'); ?></h3>
            <p class="description"><?php esc_html_e('Sync each content type separately. Brands should be pulled before inventory if you use brand filters on your site.', 'helmful-sync'); ?></p>

            <div class="helmful-action-row">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('helmful_sync_pull_boat_shows'); ?>
                    <input type="hidden" name="action" value="helmful_sync_pull_boat_shows">
                    <input type="hidden" name="helmful_active_tab" value="general">
                    <?php submit_button(__('Pull boat shows & events', 'helmful-sync'), 'primary', 'submit', false); ?>
                </form>

                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('helmful_sync_pull_brands'); ?>
                    <input type="hidden" name="action" value="helmful_sync_pull_brands">
                    <input type="hidden" name="helmful_active_tab" value="general">
                    <?php submit_button(__('Pull brands', 'helmful-sync'), 'secondary', 'submit', false); ?>
                </form>

                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('helmful_sync_pull_inventory'); ?>
                    <input type="hidden" name="action" value="helmful_sync_pull_inventory">
                    <input type="hidden" name="helmful_active_tab" value="general">
                    <?php submit_button(__('Pull inventory', 'helmful-sync'), 'secondary', 'submit', false); ?>
                </form>
            </div>
        </div>

        <!-- Shortcodes -->
        <div class="helmful-section">
            <h2><?php esc_html_e('Shortcodes', 'helmful-sync'); ?></h2>
            <p><?php esc_html_e('Add these to any page or post. They use your design settings by default — individual attributes override them.', 'helmful-sync'); ?></p>
            <p class="description"><?php esc_html_e('Create a Page at /boat-shows/ with [helmful_boat_shows] for the listing. Single show and event URLs use custom Helmful templates automatically (not blog posts). After updating, save Permalinks once.', 'helmful-sync'); ?></p>

            <div class="helmful-shortcode-grid">
                <div class="helmful-shortcode-card helmful-shortcode-card--featured">
                    <p class="helmful-shortcode-card__label"><?php esc_html_e('Recommended', 'helmful-sync'); ?></p>
                    <code>[helmful_boat_shows]</code>
                    <p><?php esc_html_e('Displays all boat shows using your saved layout and design settings.', 'helmful-sync'); ?></p>
                </div>

                <div class="helmful-shortcode-card">
                    <p class="helmful-shortcode-card__label"><?php esc_html_e('Override layout', 'helmful-sync'); ?></p>
                    <code>[helmful_boat_shows layout="grid"]</code>
                    <p><?php esc_html_e('Force a specific layout: stacked, grid, timeline, or compact.', 'helmful-sync'); ?></p>
                </div>

                <div class="helmful-shortcode-card">
                    <p class="helmful-shortcode-card__label"><?php esc_html_e('Single show', 'helmful-sync'); ?></p>
                    <code>[helmful_boat_shows slug="miami-boat-show"]</code>
                    <p><?php esc_html_e('Display one boat show by its Helmful slug.', 'helmful-sync'); ?></p>
                </div>

                <div class="helmful-shortcode-card">
                    <p class="helmful-shortcode-card__label"><?php esc_html_e('Events only', 'helmful-sync'); ?></p>
                    <code>[helmful_boat_show_events]</code>
                    <p><?php esc_html_e('List boat show events without the parent show wrapper.', 'helmful-sync'); ?></p>
                </div>

                <div class="helmful-shortcode-card">
                    <p class="helmful-shortcode-card__label"><?php esc_html_e('Filter by year', 'helmful-sync'); ?></p>
                    <code>[helmful_boat_show_events year="2026"]</code>
                    <p><?php esc_html_e('Show only events from a specific year.', 'helmful-sync'); ?></p>
                </div>

                <div class="helmful-shortcode-card helmful-shortcode-card--featured">
                    <p class="helmful-shortcode-card__label"><?php esc_html_e('Brands landing page', 'helmful-sync'); ?></p>
                    <code>[helmful_brands]</code>
                    <p><?php esc_html_e('Grid of all synced brands with logos. Each brand links to your inventory page filtered by brand.', 'helmful-sync'); ?></p>
                </div>

                <div class="helmful-shortcode-card">
                    <p class="helmful-shortcode-card__label"><?php esc_html_e('Brand grid columns', 'helmful-sync'); ?></p>
                    <code>[helmful_brands columns="3"]</code>
                    <p><?php esc_html_e('Adjust the number of brand columns (2–6).', 'helmful-sync'); ?></p>
                </div>

                <div class="helmful-shortcode-card helmful-shortcode-card--featured">
                    <p class="helmful-shortcode-card__label"><?php esc_html_e('Inventory listing', 'helmful-sync'); ?></p>
                    <code>[helmful_inventory]</code>
                    <p><?php esc_html_e('All synced inventory with a brand sidebar filter. Create a page at /inventory/ for the listing.', 'helmful-sync'); ?></p>
                </div>

                <div class="helmful-shortcode-card">
                    <p class="helmful-shortcode-card__label"><?php esc_html_e('Filter inventory by brand', 'helmful-sync'); ?></p>
                    <code>[helmful_inventory brand="sea-ray"]</code>
                    <p><?php esc_html_e('Show inventory for one brand by slug. Each brand also has its own URL under the brands page, e.g. /brands/sea-ray/.', 'helmful-sync'); ?></p>
                </div>
            </div>
        </div>

    </div><!-- /general -->

    <!-- ====================================================
         BOAT SHOW DESIGN TAB
         ==================================================== -->
    <div class="helmful-admin-panel<?php echo $activeTab === 'boat-shows' ? ' is-active' : ''; ?>" data-panel="boat-shows">

        <div class="helmful-section">
            <form method="post" action="options.php">
                <?php settings_fields('helmful_sync'); ?>
                <input type="hidden" name="helmful_active_tab" value="boat-shows">

                <h2><?php esc_html_e('Boat Show Design', 'helmful-sync'); ?></h2>
                <p class="description"><?php esc_html_e('Controls layout and styling for [helmful_boat_shows] and boat show templates.', 'helmful-sync'); ?></p>

                <!-- Layout -->
                <h3><?php esc_html_e('Layout', 'helmful-sync'); ?></h3>
                <div class="helmful-layout-picker" role="radiogroup" aria-label="<?php esc_attr_e('Boat show layout', 'helmful-sync'); ?>">
                    <?php foreach (Helmful_Sync_Display::layout_options() as $value => $label) { ?>
                        <?php
                        $thumbClass = match ($value) {
                            Helmful_Sync_Display::LAYOUT_GRID => 'helmful-thumb-grid',
                            Helmful_Sync_Display::LAYOUT_TIMELINE => 'helmful-thumb-timeline',
                            Helmful_Sync_Display::LAYOUT_COMPACT => 'helmful-thumb-compact',
                            default => 'helmful-thumb-stacked',
                        };
                        ?>
                        <label class="helmful-layout-option">
                            <input
                                type="radio"
                                name="helmful_sync_settings[display][layout]"
                                value="<?php echo esc_attr($value); ?>"
                                <?php checked($display['layout'], $value); ?>
                            >
                            <span class="helmful-layout-card">
                                <span class="helmful-layout-card__thumb <?php echo esc_attr($thumbClass); ?>">
                                    <?php if ($value === Helmful_Sync_Display::LAYOUT_STACKED) { ?>
                                        <span class="bar bar--lg"></span><span class="bar"></span><span class="bar"></span>
                                    <?php } elseif ($value === Helmful_Sync_Display::LAYOUT_GRID) { ?>
                                        <span></span><span></span><span></span><span></span>
                                    <?php } elseif ($value === Helmful_Sync_Display::LAYOUT_TIMELINE) { ?>
                                        <span></span><span></span><span></span>
                                    <?php } else { ?>
                                        <span></span><span></span><span></span>
                                    <?php } ?>
                                </span>
                                <span class="helmful-layout-card__title"><?php echo esc_html($label); ?></span>
                                <span class="helmful-layout-card__desc"><?php echo esc_html($layoutDescriptions[$value] ?? ''); ?></span>
                            </span>
                        </label>
                    <?php } ?>
                </div>

                <!-- Content options -->
                <h3><?php esc_html_e('Content', 'helmful-sync'); ?></h3>
                <table class="form-table" role="presentation">
                    <tr class="helmful-field--columns<?php echo $display['layout'] !== Helmful_Sync_Display::LAYOUT_GRID ? ' is-hidden' : ''; ?>">
                        <th scope="row"><label for="helmful_columns"><?php esc_html_e('Grid columns', 'helmful-sync'); ?></label></th>
                        <td>
                            <select name="helmful_sync_settings[display][columns]" id="helmful_columns">
                                <option value="2" <?php selected($display['columns'], 2); ?>><?php esc_html_e('2 columns', 'helmful-sync'); ?></option>
                                <option value="3" <?php selected($display['columns'], 3); ?>><?php esc_html_e('3 columns', 'helmful-sync'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Descriptions', 'helmful-sync'); ?></th>
                        <td>
                            <fieldset>
                                <label>
                                    <input type="checkbox" name="helmful_sync_settings[display][show_description]" value="1" <?php checked($display['show_description']); ?>>
                                    <?php esc_html_e('Show boat show descriptions', 'helmful-sync'); ?>
                                </label>
                            </fieldset>
                        </td>
                    </tr>
                </table>

                <h3><?php esc_html_e('Colors', 'helmful-sync'); ?></h3>
                <p class="description"><?php esc_html_e('Theme overrides can target CSS custom properties on .helmful-boat-shows-shell.', 'helmful-sync'); ?></p>
                <table class="form-table" role="presentation">
                    <?php $renderColorFields(Helmful_Sync_Display_Settings::boat_shows_color_labels(), $display); ?>
                    <tr>
                        <th scope="row"><label for="helmful_card_style"><?php esc_html_e('Card style', 'helmful-sync'); ?></label></th>
                        <td>
                            <select name="helmful_sync_settings[display][card_style]" id="helmful_card_style">
                                <?php foreach (Helmful_Sync_Display_Settings::card_style_options() as $value => $label) { ?>
                                    <option value="<?php echo esc_attr($value); ?>" <?php selected($display['card_style'], $value); ?>><?php echo esc_html($label); ?></option>
                                <?php } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="helmful_spacing"><?php esc_html_e('Spacing', 'helmful-sync'); ?></label></th>
                        <td>
                            <select name="helmful_sync_settings[display][spacing]" id="helmful_spacing">
                                <?php foreach (Helmful_Sync_Display_Settings::spacing_options() as $value => $label) { ?>
                                    <option value="<?php echo esc_attr($value); ?>" <?php selected($display['spacing'], $value); ?>><?php echo esc_html($label); ?></option>
                                <?php } ?>
                            </select>
                        </td>
                    </tr>
                </table>

                <!-- Preview -->
                <div class="helmful-display-preview">
                    <h3><?php esc_html_e('Style preview', 'helmful-sync'); ?></h3>
                    <div class="helmful-display-preview__frame" data-preview-layout="<?php echo esc_attr($display['layout']); ?>">
                        <div class="helmful-boat-shows helmful-layout-<?php echo esc_attr($display['layout']); ?>">
                            <article class="helmful-boat-show">
                                <header class="helmful-boat-show__header">
                                    <h3 class="helmful-boat-show__title"><a class="helmful-boat-show__title-link" href="#"><?php esc_html_e('Sample Boat Show', 'helmful-sync'); ?></a></h3>
                                    <?php if ($display['show_description']) { ?>
                                        <div class="helmful-boat-show__description"><?php esc_html_e('Preview of how synced boat shows will look on your site.', 'helmful-sync'); ?></div>
                                    <?php } ?>
                                </header>
                                <ul class="helmful-event-list helmful-event-list--nested">
                                    <li class="helmful-event">
                                        <div class="helmful-event__body">
                                            <div class="helmful-event__title"><a class="helmful-event__title-link" href="#"><?php esc_html_e('Opening Day', 'helmful-sync'); ?></a></div>
                                            <div class="helmful-event__dates"><span class="helmful-icon" aria-hidden="true">📅</span><?php esc_html_e('Jun 12 – Jun 14, 2026', 'helmful-sync'); ?></div>
                                            <div class="helmful-event__location"><span class="helmful-icon" aria-hidden="true">📍</span><?php esc_html_e('Miami Beach, FL', 'helmful-sync'); ?></div>
                                            <div class="helmful-event__links">
                                                <a class="helmful-link helmful-link--primary" href="#"><?php esc_html_e('View event', 'helmful-sync'); ?></a>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </article>
                        </div>
                    </div>
                </div>

                <?php submit_button(__('Save boat show design', 'helmful-sync')); ?>
            </form>
        </div>

    </div><!-- /boat-shows -->

    <!-- ====================================================
         INVENTORY DESIGN TAB
         ==================================================== -->
    <div class="helmful-admin-panel<?php echo $activeTab === 'inventory' ? ' is-active' : ''; ?>" data-panel="inventory">

        <div class="helmful-section">
            <form method="post" action="options.php">
                <?php settings_fields('helmful_sync'); ?>
                <input type="hidden" name="helmful_active_tab" value="inventory">

                <h2><?php esc_html_e('Inventory Design', 'helmful-sync'); ?></h2>
                <p class="description"><?php esc_html_e('Controls layout, pagination, quote requests, and styling for [helmful_inventory].', 'helmful-sync'); ?></p>

                <h3><?php esc_html_e('Listing', 'helmful-sync'); ?></h3>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="helmful_inventory_per_page"><?php esc_html_e('Items per page', 'helmful-sync'); ?></label></th>
                        <td>
                            <input type="number" min="1" max="100" step="1" id="helmful_inventory_per_page" name="helmful_sync_settings[display][inventory_per_page]" value="<?php echo esc_attr((string) $display['inventory_per_page']); ?>" class="small-text">
                            <p class="description"><?php esc_html_e('Number of inventory items shown per page.', 'helmful-sync'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="helmful_inventory_columns"><?php esc_html_e('Grid columns', 'helmful-sync'); ?></label></th>
                        <td>
                            <select name="helmful_sync_settings[display][inventory_columns]" id="helmful_inventory_columns">
                                <option value="3" <?php selected($display['inventory_columns'], 3); ?>><?php esc_html_e('3 columns', 'helmful-sync'); ?></option>
                                <option value="4" <?php selected($display['inventory_columns'], 4); ?>><?php esc_html_e('4 columns', 'helmful-sync'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="helmful_quote_email"><?php esc_html_e('Quote request email', 'helmful-sync'); ?></label></th>
                        <td>
                            <input type="email" id="helmful_quote_email" name="helmful_sync_settings[display][quote_email]" value="<?php echo esc_attr($display['quote_email']); ?>" class="regular-text" placeholder="<?php echo esc_attr((string) get_option('admin_email')); ?>">
                            <p class="description"><?php esc_html_e('Quote requests from the inventory modal are sent here. Leave blank to use the WordPress admin email.', 'helmful-sync'); ?></p>
                        </td>
                    </tr>
                </table>

                <h3><?php esc_html_e('Colors', 'helmful-sync'); ?></h3>
                <p class="description"><?php esc_html_e('Inventory uses the accent color from Boat Show Design for badges, filters, and buttons.', 'helmful-sync'); ?></p>
                <table class="form-table" role="presentation">
                    <?php $renderColorFields(Helmful_Sync_Display_Settings::inventory_color_labels(), $display); ?>
                </table>

                <?php submit_button(__('Save inventory design', 'helmful-sync')); ?>
            </form>
        </div>

    </div><!-- /inventory -->

    <!-- ====================================================
         BRANDS DESIGN TAB
         ==================================================== -->
    <div class="helmful-admin-panel<?php echo $activeTab === 'brands' ? ' is-active' : ''; ?>" data-panel="brands">

        <div class="helmful-section">
            <form method="post" action="options.php">
                <?php settings_fields('helmful_sync'); ?>
                <input type="hidden" name="helmful_active_tab" value="brands">

                <h2><?php esc_html_e('Brands Design', 'helmful-sync'); ?></h2>
                <p class="description"><?php esc_html_e('Controls layout and styling for [helmful_brands].', 'helmful-sync'); ?></p>

                <h3><?php esc_html_e('Layout', 'helmful-sync'); ?></h3>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="helmful_brands_columns"><?php esc_html_e('Grid columns', 'helmful-sync'); ?></label></th>
                        <td>
                            <select name="helmful_sync_settings[display][brands_columns]" id="helmful_brands_columns">
                                <?php for ($brandCols = 2; $brandCols <= 6; $brandCols++) { ?>
                                    <option value="<?php echo esc_attr((string) $brandCols); ?>" <?php selected($display['brands_columns'], $brandCols); ?>>
                                        <?php echo esc_html(sprintf(__('%d columns', 'helmful-sync'), $brandCols)); ?>
                                    </option>
                                <?php } ?>
                            </select>
                            <p class="description"><?php esc_html_e('Default column count for the brands grid. Can be overridden with [helmful_brands columns="3"].', 'helmful-sync'); ?></p>
                        </td>
                    </tr>
                </table>

                <h3><?php esc_html_e('Colors', 'helmful-sync'); ?></h3>
                <table class="form-table" role="presentation">
                    <?php $renderColorFields(Helmful_Sync_Display_Settings::brands_color_labels(), $display); ?>
                </table>

                <?php submit_button(__('Save brands design', 'helmful-sync')); ?>
            </form>
        </div>

    </div><!-- /brands -->

</div>
