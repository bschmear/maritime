<?php
/**
 * Template Name: FAQ
 */
get_header();
while (have_posts()) : the_post();

$faq_groups = get_field('faq_group') ?? [];
?>

<!-- ===== PAGE HERO ===== -->
<div class="bg-white pt-20 pb-16 text-center border-b border-gray-100">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="flex items-center justify-center gap-3 mb-5">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Questions</span>
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
    </div>
    <?php the_title('<h1 class="text-gray-900 font-black leading-tight mb-4" style="font-size: clamp(2.5rem, 6vw, 4rem);">', '</h1>'); ?>
    <p class="text-gray-500 text-lg max-w-xl mx-auto">
      Browse our most commonly asked questions, organized by topic.
    </p>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<?php if (!empty($faq_groups)) : ?>

<!-- Sticky category nav -->
<div class="sticky z-40 bg-white border-b border-gray-200 shadow-sm lg:top-[106px]" >
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="flex flex-wrap gap-0 overflow-x-auto" id="faq-tab-nav">
      <?php foreach ($faq_groups as $faq_gi => $faq_group) : ?>
        <a
          href="#faq-cat-<?php echo $faq_gi; ?>"
          onclick="faqScrollTo('faq-cat-<?php echo $faq_gi; ?>', event)"
          class="faq-cat-btn flex-shrink-0 px-5 py-4 text-sm font-bold uppercase tracking-widest border-b-2 transition-all duration-150 whitespace-nowrap border-transparent text-gray-400 hover:text-[#ff9101] hover:border-[#ff9101]">
          <?php echo esc_html(trim($faq_group['category_title'])); ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</div>


<!-- FAQ sections -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="flex flex-col gap-16">

      <?php foreach ($faq_groups as $faq_gi => $faq_group) :
        $faq_qas = $faq_group['questionsanswers'] ?? [];
      ?>
        <div id="faq-cat-<?php echo $faq_gi; ?>" class="faq-cat-section scroll-mt-[160px]">

          <!-- Section heading -->
          <div class="flex items-center gap-3 mb-8">
            <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
            <h2 class="text-gray-900 font-black text-xl uppercase tracking-widest">
              <?php echo esc_html(trim($faq_group['category_title'])); ?>
            </h2>
          </div>

          <!-- Two column grid -->
          <div class=" md:columns-2 gap-4">
            <?php foreach ($faq_qas as $faq_qa) : ?>
              <div class="bg-white border border-gray-100 rounded-sm shadow-sm p-7 mb-4 break-inside-avoid">
                <h3 class="text-gray-900 font-black text-base mb-3 leading-snug text-xl">
                  <?php echo $faq_qa['question']; ?>
                </h3>
                <div class="text-gray-500 text-sm leading-relaxed text-xl">
                  <?php
                  $faq_answer = trim($faq_qa['answer']);
                  $faq_paras  = array_filter(preg_split('/\n{2,}/', $faq_answer));
                  foreach ($faq_paras as $faq_para) {
                    echo '<p class="mb-2 last:mb-0">' . $faq_para . '</p>';
                  }
                  ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

        </div>
      <?php endforeach; ?>

    </div>
  </div>
</div>
<?php endif; ?>


<!-- ===== CTA BAND ===== -->
<div class="bg-[#032972] py-14">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14 flex flex-col sm:flex-row items-center justify-between gap-6">
    <p class="text-white font-black text-2xl md:text-3xl">Still have questions?</p>
    <a href="<?php echo home_url('/contact/'); ?>"
      class="flex-shrink-0 inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-[#ff9101] font-black px-8 py-4 text-base uppercase tracking-[0.2em] transition-all duration-200">
      Contact Us
      <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
      </svg>
    </a>
  </div>
</div>


<script>
function faqScrollTo(id, e) {
  e.preventDefault();
  var target = document.getElementById(id);
  if (!target) return;
  var top = target.getBoundingClientRect().top + window.scrollY - 170;
  window.scrollTo({ top: top, behavior: 'smooth' });
}

(function () {
  var sections = document.querySelectorAll('.faq-cat-section');
  var tabs     = document.querySelectorAll('.faq-cat-btn');

  function setActive(index) {
    tabs.forEach(function(t) {
      t.classList.remove('border-[#ff9101]', 'text-[#ff9101]');
      t.classList.add('border-transparent', 'text-gray-400');
    });
    if (tabs[index]) {
      tabs[index].classList.add('border-[#ff9101]', 'text-[#ff9101]');
      tabs[index].classList.remove('border-transparent', 'text-gray-400');
    }
  }

  window.addEventListener('scroll', function () {
    var scrollY = window.scrollY + 180;
    var current = 0;
    sections.forEach(function(sec, i) {
      if (sec.offsetTop <= scrollY) current = i;
    });
    setActive(current);
  }, { passive: true });

  setActive(0);
})();
</script>

<?php
endwhile;
get_footer();
?>