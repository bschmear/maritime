    <div id="footer-locations" class="site-width">
      <?php if (is_active_sidebar('footer-locations')) dynamic_sidebar('footer-locations'); ?>
    </div>

    <?php
    $ofr = get_page_by_path('orange-footer-ribbon');
    if ($ofr->post_status == "publish") {
      echo '<div id="orange-footer-ribbon">'."\n";
        echo '<div class="absolute inset-0 opacity-[0.06]" style="background-image: repeating-linear-gradient(45deg, #000 0, #000 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>'."\n";
        echo '<div class="site-width relative z-10">'."\n";
          if (has_post_thumbnail($ofr->ID)) echo get_the_post_thumbnail($ofr->ID);
          echo apply_filters('the_content', get_the_content("", false, $ofr->ID));
        echo "</div> <!-- /.site-width -->\n";
      echo "</div> <!-- /#orange-footer-ribbon -->\n";
    }
    ?>
    
    <footer class="bg-[#111111] text-white">

      <div class="h-[3px] bg-[#ff9101]"></div>

      <div class="max-w-screen-2xl mx-auto px-6 md:px-14 py-16">
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-12 gap-12">

          <!-- Logo + social -->
          <div class="xl:col-span-4 flex flex-col gap-8">
            <a href="<?php echo home_url(); ?>" id="footer-logo" aria-label="Return to home page"
              class="block w-[280px] h-[60px]"
              style="background: url(<?php echo get_template_directory_uri(); ?>/images/logo-white.webp) no-repeat left center; background-size: contain;">
            </a>

            <p class="text-white/70 text-lg leading-relaxed max-w-xs">
              Florida's trusted inflatable boat dealer — serving Southwest Florida and beyond.
            </p>

            <a href="tel:85569836337"
              class="inline-flex items-center gap-3 text-white hover:text-[#ff9101] transition-colors duration-150 group w-fit">
              <span class="w-10 h-10 bg-white/10 group-hover:bg-[#ff9101]/20 flex items-center justify-center flex-shrink-0 transition-colors duration-150">
                <svg class="w-5 h-5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 8V5z"/>
                </svg>
              </span>
              <span class="font-black text-xl">(855) MYTENDER</span>
            </a>

            <div class="flex items-center gap-3">
              <?php if (get_theme_mod('fg_instagram')) : ?>
              <a href="<?php echo esc_url(get_theme_mod('fg_instagram')); ?>"
                aria-label="Visit us on Instagram" target="_blank" rel="noopener"
                class="w-11 h-11 bg-white/10 hover:bg-[#ff9101] flex items-center justify-center transition-all duration-200">
                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
              <?php endif; ?>
              <?php if (get_theme_mod('fg_facebook')) : ?>
              <a href="<?php echo esc_url(get_theme_mod('fg_facebook')); ?>"
                aria-label="Visit us on Facebook" target="_blank" rel="noopener"
                class="w-11 h-11 bg-white/10 hover:bg-[#ff9101] flex items-center justify-center transition-all duration-200">
                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>
              <?php endif; ?>
            </div>

          </div>

          <!-- Nav -->
          <div class="xl:col-span-4">
            <p class="text-white/50 text-sm font-bold uppercase tracking-[0.25em] mb-6">Navigation</p>
            <?php
            wp_nav_menu(array(
              'theme_location' => 'footer-menu',
              'container'      => false,
              'menu_class'     => 'grid grid-cols-2 gap-x-6 gap-y-4',
              'link_before'    => '<span class="text-white/70 hover:text-[#ff9101] font-semibold text-lg transition-colors duration-150">',
              'link_after'     => '</span>',
            ));
            ?>
          </div>

          <!-- Newsletter -->
          <div class="xl:col-span-4">
            <p class="text-white/50 text-sm font-bold uppercase tracking-[0.25em] mb-6">Mailing List</p>
            <h3 class="text-white font-black text-2xl mb-2">Join Our Mailing List</h3>
            <p class="text-white/70 text-lg mb-6">Get the latest boats, deals, and Florida boating news.</p>

            <form action="https://inflatableboatsofflorida.us12.list-manage.com/subscribe/post?u=671dea5290aeac86e3c5b4dd8&amp;id=d638171195&amp;f_id=003b5ae0f0"
              method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form"
              target="_blank" novalidate>

              <div style="position: absolute; left: -5000px;" aria-hidden="true">
                <input type="text" name="b_671dea5290aeac86e3c5b4dd8_d638171195" tabindex="-1" value="">
              </div>

              <div class="flex">
                <input type="email" name="EMAIL" id="mce-EMAIL" required placeholder="Your email address"
                  class="flex-1 min-w-0 bg-white/10 border-2 border-white/20 focus:border-[#ff9101] text-white placeholder:text-white/50 font-semibold text-lg px-4 py-3.5 focus:outline-none transition-colors duration-150">
                <button type="submit"
                  class="flex-shrink-0 bg-[#ff9101] hover:bg-[#e07f00] text-white font-black text-sm uppercase tracking-[0.2em] px-6 py-3.5 transition-all duration-200">
                  Subscribe
                </button>
              </div>

              <div id="mce-responses" class="mt-3">
                <div id="mce-error-response" class="hidden text-red-400 text-base font-semibold"></div>
                <div id="mce-success-response" class="hidden text-green-400 text-base font-semibold"></div>
              </div>

            </form>
          </div>

        </div>
      </div>

      <!-- Copyright bar -->
      <div class="border-t border-white/20">
        <div class="max-w-screen-2xl mx-auto px-6 md:px-14 py-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p class="text-white/60 text-base font-semibold">
            &copy; <?php echo date('Y'); ?> Inflatable Boats of Florida. All rights reserved.
          </p>
          <a href="https://foresitegrp.com" target="_blank" rel="noopener"
            class="text-white/40 hover:text-white/70 text-sm font-bold uppercase tracking-widest transition-colors duration-150">
            Website by Foresite
          </a>
        </div>
      </div>

    </footer>

    <script>
    [...document.links].forEach(link => {
      if (link.hostname != window.location.hostname || link.href.split('.').pop() === 'pdf') {
        link.target = '_blank';
        link.rel = 'noopener';
      }
    });

    document.querySelectorAll('.mbq-link').forEach(link => {
      link.addEventListener('click', () => {
        if (document.cookie.indexOf('IBOFmbq') > -1) {
          const res = document.cookie.match('(^|;)\\s*IBOFmbq\\s*=\\s*([^;]+)')?.pop() || '';
          if (!res.includes(link.dataset.postid))
            document.cookie = 'IBOFmbq=' + res + ',' + link.dataset.postid + '; SameSite=Lax; path=/';
        } else {
          document.cookie = 'IBOFmbq=' + link.dataset.postid + '; SameSite=Lax; path=/';
        }
      });
    });
    </script>

    <?php wp_footer(); ?>

  </body>
</html>