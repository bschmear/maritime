<?php
get_header();

while (have_posts()) : the_post();
  $member_id = get_the_ID();
  $member_name = get_the_title();
  $member_content = get_the_content();
  $member_excerpt = get_the_excerpt();

  // Get member details from ACF or post meta
  $member_position = get_field('position') ?: get_post_meta($member_id, 'position', true) ?: get_post_meta($member_id, 'role', true);
  $member_email = get_field('email') ?: get_post_meta($member_id, 'email', true);
  $member_phone = get_field('phone') ?: get_post_meta($member_id, 'phone', true);
  // $member_linkedin = get_field('linkedin') ?: get_post_meta($member_id, 'linkedin', true);

  $member_photo = get_the_post_thumbnail_url($member_id, 'large');
?>

<!-- ===== PAGE HERO ===== -->
<div class="relative min-h-[300px] flex items-end bg-[#111111] overflow-hidden">
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
  <div class="absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14 pt-24">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Team Member</span>
    </div>
    <h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">
      <?php echo esc_html($member_name); ?>
    </h1>
    <?php if ($member_position) : ?>
      <p class="text-white/80 text-lg md:text-xl leading-relaxed max-w-2xl mt-4">
        <?php echo esc_html($member_position); ?>
      </p>
    <?php endif; ?>

    <!-- Breadcrumb -->
    <div class="flex items-center gap-2 text-white/60 text-sm mt-6">
      <a href="<?php echo home_url(); ?>" class="hover:text-white transition-colors">Home</a>
      <span>/</span>
      <a href="<?php echo get_post_type_archive_link('teammember'); ?>" class="hover:text-white transition-colors">Team</a>
      <span>/</span>
      <span class="text-white"><?php echo esc_html($member_name); ?></span>
    </div>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>

<!-- ===== MEMBER CONTENT ===== -->
<div class="bg-[#f7f7f7]  pb-24">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14 py-16">

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">

      <!-- Member Photo & Contact -->
      <div class="lg:col-span-1">
        <div class="sticky top-8">

          <!-- Photo -->
          <div class="bg-white rounded-lg shadow-md overflow-hidden mb-8">
            <?php if ($member_photo) : ?>
              <img src="<?php echo esc_url($member_photo); ?>"
                   alt="<?php echo esc_attr($member_name); ?>"
                   class="w-full h-auto">
            <?php else : ?>
              <div class="aspect-square bg-gray-100 flex items-center justify-center">
                <svg class="w-20 h-20 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                </svg>
              </div>
            <?php endif; ?>
          </div>

          <!-- Contact Info -->
          <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-gray-900 font-bold text-lg mb-6">Contact Information</h3>

            <div class="space-y-4">
              <?php if ($member_position) : ?>
                <div class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-[#ff9101] mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                  </svg>
                  <div>
                    <p class="text-gray-600 text-sm font-medium">Position</p>
                    <p class="text-gray-900"><?php echo esc_html($member_position); ?></p>
                  </div>
                </div>
              <?php endif; ?>

              <?php if ($member_email) : ?>
                <div class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-[#ff9101] mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                  </svg>
                  <div>
                    <p class="text-gray-600 text-sm font-medium">Email</p>
                    <a href="mailto:<?php echo esc_attr($member_email); ?>" class="text-[#ff9101] hover:text-[#e07f00] transition-colors">
                      <?php echo esc_html($member_email); ?>
                    </a>
                  </div>
                </div>
              <?php endif; ?>

              <?php if ($member_phone) : ?>
                <div class="flex items-start gap-3">
                  <svg class="w-5 h-5 text-[#ff9101] mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 8V5z"/>
                  </svg>
                  <div>
                    <p class="text-gray-600 text-sm font-medium">Phone</p>
                    <a href="tel:<?php echo preg_replace('/[^0-9]/', '', $member_phone); ?>" class="text-[#ff9101] hover:text-[#e07f00] transition-colors">
                      <?php echo esc_html($member_phone); ?>
                    </a>
                  </div>
                </div>
              <?php endif; ?>


            </div>
          </div>

        </div>
      </div>

      <!-- Member Bio -->
      <div class="lg:col-span-2">
        <div class="bg-white rounded-lg shadow-md p-8">
<!-- 
          <?php if ($member_excerpt) : ?>
            <div class="border-l-4 border-[#ff9101] pl-6 mb-8">
              <p class="text-gray-600 text-lg italic leading-relaxed">
                "<?php // echo $member_excerpt; ?>"
              </p>
            </div>
          <?php endif; ?> -->

          <?php if ($member_content) : ?>
            <div class="text-gray-500 text-xl leading-relaxed space-y-4 [&>p]:mb-4 [&>ul]:list-disc [&>ul]:pl-5 [&>ol]:list-decimal [&>ol]:pl-5 [&>h2]:font-black [&>h2]:text-gray-900 [&>h3]:font-bold [&>h3]:text-gray-900">
  <?php the_content(); ?>
</div>
          <?php else : ?>
            <div class="text-center py-12">
              <svg class="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                  d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
              </svg>
              <p class="text-gray-500 text-lg">No additional information available for this team member.</p>
            </div>
          <?php endif; ?>

        </div>
      </div>

    </div>

  </div>
</div>

<?php
endwhile;
get_footer();
?>