<?php
/**
 * Template Name: Marine Partners
 */
get_header();
while (have_posts()) : the_post();

// Pull post meta safely
$mp_green_footer = get_post_meta($post->ID, 'green_footer_text', true);
?>

<!-- ===== PAGE HERO ===== -->
<div class="mp-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden <?php echo !has_post_thumbnail() ? 'bg-[#111111]' : ''; ?>"
  <?php if (has_post_thumbnail()) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>

  <?php if (!has_post_thumbnail()) : ?>
  <div class="absolute inset-0 opacity-[0.04]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <?php endif; ?>

  <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Our Network</span>
    </div>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== PARTNERS / GALLERY ===== -->
<?php
$mp_intro    = get_field('intro_copy');
$mp_sections = get_field('section'); // <-- verify this matches your ACF field name exactly
?>

<?php if ($mp_intro || !empty($mp_sections)) : ?>

<div class="bg-white py-20 border-t border-gray-100">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <!-- Intro -->
    <?php if ($mp_intro) : ?>
    <div class="max-w-4xl mb-16">
      <div class="flex items-center gap-3 mb-5">
        <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
        <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Our Partners</span>
      </div>
      <div class="text-gray-500 text-lg md:text-xl lg:text-2xl leading-relaxed">
        <?php echo wp_kses_post($mp_intro); ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Sections -->
    <?php if (!empty($mp_sections)) :
      foreach ($mp_sections as $mp_sec) :
        $mp_title    = isset($mp_sec['section_title']) ? $mp_sec['section_title'] : '';
        $mp_partners = isset($mp_sec['partners'])      ? $mp_sec['partners']      : array();

        // Flatten all logos — handle both flat and nested partner group structures
        $mp_all_logos = array();
        foreach ($mp_partners as $mp_p) {
          // Try nested group first, fall back to flat
          if (isset($mp_p['partner']['logos'])) {
            $mp_logos = $mp_p['partner']['logos'];
          } elseif (isset($mp_p['logos'])) {
            $mp_logos = $mp_p['logos'];
          } else {
            $mp_logos = array();
          }
          foreach ($mp_logos as $mp_logo) {
            if (!empty($mp_logo)) $mp_all_logos[] = $mp_logo;
          }
        }

        if (empty($mp_all_logos)) continue;
    ?>

    <div class="mp-section mb-16 last:mb-0">

      <?php if ($mp_title) : ?>
      <div class="flex items-center gap-4 mb-8">
        <h3 class="text-gray-900 font-black text-xl md:text-2xl lg:text-3xl uppercase tracking-widest flex-shrink-0">
          <?php echo esc_html($mp_title); ?>
        </h3>
        <div class="h-px flex-1 bg-gray-100"></div>
        <span class="flex-shrink-0 text-[#ff9101] text-xs font-bold uppercase tracking-widest">
          <?php echo count($mp_all_logos); ?> <?php echo count($mp_all_logos) === 1 ? 'Partner' : 'Partners'; ?>
        </span>
      </div>
      <?php endif; ?>

      <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-px bg-gray-100 border border-gray-100 rounded-md overflow-hidden">
        <?php foreach ($mp_all_logos as $mp_img) :
          if (empty($mp_img)) continue;

          // Handle both array (ACF image object) and plain URL string
          if (is_array($mp_img)) {
            $mp_img_thumb = isset($mp_img['sizes']['medium']) ? $mp_img['sizes']['medium'] : $mp_img['url'];
            $mp_img_full  = $mp_img['url'];
            $mp_img_alt   = isset($mp_img['alt']) ? $mp_img['alt'] : '';
          } else {
            $mp_img_thumb = $mp_img;
            $mp_img_full  = $mp_img;
            $mp_img_alt   = '';
          }
        ?>
          <a href="<?php echo esc_url($mp_img_full); ?>"
            class="mp-gallery-item group bg-white flex items-center justify-center p-6 md:p-8 hover:bg-[#ff9101]/5 transition-colors duration-200 glightbox"
            data-gallery="mp-partners">
            <img src="<?php echo esc_url($mp_img_thumb); ?>"
              alt="<?php echo esc_attr($mp_img_alt); ?>"
              class="max-h-14 w-auto object-contain group-hover:opacity-100 transition-all duration-300"
              loading="lazy">
          </a>
        <?php endforeach; ?>
      </div>

    </div>

    <?php
      endforeach;
    endif;
    ?>

  </div>
</div>

<?php endif; ?>


<!-- ===== CTA BAND ===== -->
<?php if ($mp_green_footer) : ?>
<div class="bg-[#ff9101] py-14 relative overflow-hidden">
  <div class="absolute inset-0 opacity-[0.06]"
    style="background-image: repeating-linear-gradient(45deg, #000 0, #000 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <div class="relative z-10 max-w-screen-2xl mx-auto px-6 md:px-14 flex flex-col sm:flex-row items-center justify-between gap-6">
    <p class="text-white font-black text-2xl md:text-3xl">
      <?php echo wp_kses_post($mp_green_footer); ?>
    </p>
    <a href="<?php echo esc_url(home_url('/contact/')); ?>"
      class="flex-shrink-0 inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-[#ff9101] font-black px-8 py-4 text-sm uppercase tracking-[0.2em] transition-all duration-200">
      Contact Us
      <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
      </svg>
    </a>
  </div>
</div>
<?php endif; ?>

<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/inc/glightbox.min.css" media="screen">
<script src="<?php echo get_template_directory_uri(); ?>/inc/glightbox.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
  GLightbox({ selector: '.mp-gallery-item', touchNavigation: true, loop: true });
});
</script>

<?php
endwhile;
get_footer();
?>
