<?php
/**
 * Template Name: Outbound Sales
 */
get_header();
while (have_posts()) : the_post();
?>

<!-- ===== PAGE HERO ===== -->
<div class="obs-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden"
  <?php if (has_post_thumbnail()) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>

  <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Outboard Sales</span>
    </div>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== INTRO TEXT ===== -->
<?php $obs_intro = get_field('intro'); if ($obs_intro) : ?>
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="max-w-4xl">
      <div class="flex items-center gap-3 mb-5">
        <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
        <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Introduction</span>
      </div>
      <p class="text-gray-700 font-semibold leading-relaxed"
        style="font-size: clamp(1.2rem, 2.5vw, 1.6rem);">
        <?php echo wp_kses_post($obs_intro); ?>
      </p>
    </div>
  </div>
</div>
<?php endif; ?>


<?php
$obs_content_block = get_field('content_block');
if ($obs_content_block) :
  $obs_cb_header    = $obs_content_block['header']    ?? '';
  $obs_cb_text      = $obs_content_block['text_area'] ?? '';
  $obs_cb_logos     = $obs_content_block['logos']     ?? [];
  $obs_cb_locations = $obs_content_block['locations'] ?? [];
?>
<div class="bg-white py-20 border-t border-gray-100">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <!-- Header + text -->
    <?php if ($obs_cb_header || $obs_cb_text) : ?>
    <div class="grid grid-cols-1 gap-4 items-start mb-16">
      <?php if ($obs_cb_header) : ?>
      <div>
        <div class="flex items-center gap-3 mb-5">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">What We Carry</span>
        </div>
        <h2 class="text-gray-900 font-black leading-tight"
          style="font-size: clamp(1.8rem, 4vw, 3rem);">
          <?php echo esc_html($obs_cb_header); ?>
        </h2>
      </div>
      <?php endif; ?>
      <?php if ($obs_cb_text) : ?>
      <div class="text-gray-500 text-lg md:text-xl lg:text-2xl leading-relaxed">
        <?php echo wp_kses_post($obs_cb_text); ?>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>


    <!-- Locations / Phone directory -->
    <?php if (!empty($obs_cb_locations)) : ?>
    <div class="mb-16">

      <div class="flex items-center gap-3 mb-8">
        <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
        <p class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Call Us At</p>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        <?php foreach ($obs_cb_locations as $obs_loc) :
          $obs_p = $obs_loc['phone']         ?? '';
          $obs_l = $obs_loc['location_name'] ?? '';
          if (empty($obs_p) && empty($obs_l)) continue;
          $obs_phone_clean = preg_replace('/[^0-9]/', '', $obs_p);
        ?>

        <div class="group bg-gray-50 hover:bg-[#ff9101] border border-gray-100 hover:border-[#ff9101] rounded-md p-6 flex items-center gap-5 transition-all duration-200">

          <!-- Phone icon -->
          <span class="flex-shrink-0 w-11 h-11 rounded-sm bg-[#ff9101]/10 group-hover:bg-white/20 flex items-center justify-center transition-colors duration-200">
            <svg class="w-5 h-5 text-[#ff9101] group-hover:text-white transition-colors duration-200" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 8V5z"/>
            </svg>
          </span>

          <div class="min-w-0">
            <?php if ($obs_l) : ?>
            <p class="text-gray-400 group-hover:text-white/70 text-xs font-bold uppercase tracking-widest mb-1 transition-colors duration-200">
              <?php echo esc_html($obs_l); ?>
            </p>
            <?php endif; ?>
            <?php if ($obs_p) : ?>
            <a href="tel:<?php echo esc_attr($obs_phone_clean); ?>"
              class="text-gray-900 group-hover:text-white font-black text-xl md:text-2xl leading-tight transition-colors duration-200 hover:underline">
              <?php echo esc_html($obs_p); ?>
            </a>
            <?php endif; ?>
          </div>

        </div>

        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>


    <!-- Logos grid -->
    <?php if (!empty($obs_cb_logos)) : ?>
    <div>
      <p class="text-xs font-bold uppercase tracking-[0.3em] text-gray-300 mb-8 text-center">Brands We Carry</p>
      <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-px bg-gray-100 border border-gray-100 rounded-md overflow-hidden">
        <?php foreach ($obs_cb_logos as $obs_logo) :
          $obs_logo_url = $obs_logo['sizes']['medium'] ?? $obs_logo['url'];
          $obs_logo_alt = $obs_logo['alt'] ?? '';
        ?>
          <div class="bg-white flex items-center justify-center p-6 hover:bg-[#ff9101]/5 transition-colors duration-200">
            <img src="<?php echo esc_url($obs_logo_url); ?>"
              alt="<?php echo esc_attr($obs_logo_alt); ?>"
              class="max-h-12 w-auto object-contain opacity-70 hover:opacity-100 transition-opacity duration-200"
              loading="lazy">
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>
<?php endif; ?>


<!-- ===== QUESTIONS / Q&A ===== -->
<?php
$obs_group    = get_field('questions');
if ($obs_group) :
  $obs_header   = $obs_group['header']    ?? '';
  $obs_subhead  = $obs_group['subheader'] ?? '';
  $obs_repeater = $obs_group['questions'] ?? [];
?>
<div class="bg-[#f7f7f7] py-20 border-t border-gray-200">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <!-- Section header -->
    <?php if ($obs_header || $obs_subhead) : ?>
    <div class="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-16 pb-10 border-b-2 border-gray-200">
      <?php if ($obs_header) : ?>
      <div>
        <div class="flex items-center gap-3 mb-4">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Overview</span>
        </div>
        <h2 class="text-gray-900 font-black leading-tight"
          style="font-size: clamp(1.8rem, 4vw, 3rem);">
          <?php echo esc_html($obs_header); ?>
        </h2>
      </div>
      <?php endif; ?>
      <?php if ($obs_subhead) : ?>
      <div class="text-gray-500 text-lg md:text-xl leading-relaxed lg:max-w-lg lg:text-right">
        <?php echo wp_kses_post($obs_subhead); ?>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Q&A rows -->
    <?php if (!empty($obs_repeater)) :
      $obs_i = 0;
      foreach ($obs_repeater as $obs_row) :
        $obs_q = $obs_row['question'] ?? '';
        $obs_a = $obs_row['answer']   ?? '';
        if (empty($obs_q)) continue;
        $obs_i++;
    ?>
    <div class="obs-row group grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-16 py-10 border-b border-gray-200 hover:border-[#ff9101] transition-colors duration-300">

      <!-- Left: number + question -->
      <div class="lg:col-span-5 flex items-start gap-5">
        <span class="flex-shrink-0 font-black text-gray-200 group-hover:text-[#ff9101]/20 transition-colors duration-300 leading-none select-none"
          style="font-size: clamp(3.5rem, 6vw, 5rem); line-height: 1;">
          <?php echo str_pad($obs_i, 2, '0', STR_PAD_LEFT); ?>
        </span>
        <h3 class="text-gray-900 font-black text-xl md:text-2xl lg:text-3xl leading-tight pt-2">
          <?php echo esc_html($obs_q); ?>
        </h3>
      </div>

      <!-- Right: vertical line + answer -->
      <div class="lg:col-span-7 flex gap-6 items-start">
        <div class="hidden lg:block flex-shrink-0 w-[3px] self-stretch bg-gray-200 group-hover:bg-[#ff9101] transition-colors duration-300 rounded-full"></div>
        <?php if ($obs_a) : ?>
        <div class="text-gray-500 text-lg md:text-xl lg:text-2xl leading-relaxed">
          <?php echo wp_kses_post($obs_a); ?>
        </div>
        <?php endif; ?>
      </div>

    </div>
    <?php
      endforeach;
    endif;
    ?>

  </div>
</div>
<?php endif; ?>


<!-- ===== CTA BAND ===== -->
<?php
$obs_footer = get_post_meta(get_the_ID(), 'green_footer_text', true);
if (!empty($obs_footer)) :
?>
<div class="bg-[#ff9101] py-14 relative overflow-hidden">
  <div class="absolute inset-0 opacity-[0.06]"
    style="background-image: repeating-linear-gradient(45deg, #000 0, #000 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <div class="relative z-10 max-w-screen-2xl mx-auto px-6 md:px-14 flex flex-col sm:flex-row items-center justify-between gap-6">
    <p class="text-white font-black text-2xl md:text-3xl">
      <?php echo wp_kses_post($obs_footer); ?>
    </p>
    <a href="<?php echo esc_url(home_url('/contact/')); ?>"
      class="flex-shrink-0 inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-[#ff9101] font-black px-8 py-4 text-sm uppercase tracking-[0.2em] transition-all duration-200">
      Contact Us
      <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
      </svg>
    </a>
  </div>
</div>
<?php endif; ?>

<?php
endwhile;
get_footer();
?>
