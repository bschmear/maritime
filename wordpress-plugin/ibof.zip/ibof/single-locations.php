<?php
get_header();
while (have_posts()) : the_post();
?>

<!-- ===== PAGE HERO ===== -->
<div class="location-hero relative min-h-[420px] flex items-end bg-[#111111] overflow-hidden">
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
  <div class="absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <?php if (has_post_thumbnail()) : ?>
    <div class="absolute inset-0 bg-cover bg-center"
      style="background-image: url(<?php the_post_thumbnail_url('large'); ?>);"></div>
    <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>
  <?php endif; ?>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14 pt-24">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Location</span>
    </div>
    <h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);"><?php the_title(); ?></h1>

    <?php if (get_the_content()) : ?>
      <div class="text-white/80 text-lg md:text-xl leading-relaxed max-w-2xl mt-4">
        <?php echo wp_trim_words(get_the_content(), 30, '...'); ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== LOCATION DETAILS ===== -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-4xl mx-auto px-6 md:px-14">

    <div class="bg-white rounded-md shadow-sm overflow-hidden">

      <!-- Location Content -->
      <div class="p-8 md:p-12">
        <div class="prose prose-lg max-w-none">
          <?php the_content(); ?>
        </div>
      </div>

      <!-- Contact Information -->
      <?php
      $location_address = get_post_meta(get_the_ID(), 'location_address', true);
      $location_phone = get_post_meta(get_the_ID(), 'location_phone', true);
      $location_email = get_post_meta(get_the_ID(), 'location_email', true);
      $location_hours = get_post_meta(get_the_ID(), 'location_hours', true);

      if ($location_address || $location_phone || $location_email || $location_hours) :
      ?>
        <div class="border-t border-gray-100 p-8 md:p-12 bg-gray-50">
          <h3 class="text-gray-900 font-black text-xl mb-6 uppercase tracking-widest">Contact Information</h3>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

            <?php if ($location_address) : ?>
              <div class="flex items-start gap-3">
                <svg class="w-5 h-5 text-[#ff9101] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
                <div>
                  <p class="text-gray-400 text-sm font-bold uppercase tracking-widest mb-1">Address</p>
                  <p class="text-gray-900 font-semibold"><?php echo nl2br(esc_html($location_address)); ?></p>
                </div>
              </div>
            <?php endif; ?>

            <?php if ($location_phone) : ?>
              <div class="flex items-start gap-3">
                <svg class="w-5 h-5 text-[#ff9101] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                </svg>
                <div>
                  <p class="text-gray-400 text-sm font-bold uppercase tracking-widest mb-1">Phone</p>
                  <a href="tel:<?php echo esc_attr($location_phone); ?>" class="text-gray-900 font-semibold hover:text-[#ff9101] transition-colors">
                    <?php echo esc_html($location_phone); ?>
                  </a>
                </div>
              </div>
            <?php endif; ?>

            <?php if ($location_email) : ?>
              <div class="flex items-start gap-3">
                <svg class="w-5 h-5 text-[#ff9101] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                </svg>
                <div>
                  <p class="text-gray-400 text-sm font-bold uppercase tracking-widest mb-1">Email</p>
                  <a href="mailto:<?php echo esc_attr($location_email); ?>" class="text-gray-900 font-semibold hover:text-[#ff9101] transition-colors">
                    <?php echo esc_html($location_email); ?>
                  </a>
                </div>
              </div>
            <?php endif; ?>

            <?php if ($location_hours) : ?>
              <div class="flex items-start gap-3">
                <svg class="w-5 h-5 text-[#ff9101] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <div>
                  <p class="text-gray-400 text-sm font-bold uppercase tracking-widest mb-1">Hours</p>
                  <p class="text-gray-900 font-semibold"><?php echo nl2br(esc_html($location_hours)); ?></p>
                </div>
              </div>
            <?php endif; ?>

          </div>
        </div>
      <?php endif; ?>

    </div>

  </div>
</div>

<?php
endwhile;
get_footer();
?>