<?php
get_header();

if (is_home()) {
?>

  <!-- ===== BLOG INDEX HERO ===== -->
  <div class="relative min-h-[320px] flex items-end bg-[#111111] overflow-hidden">
    <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
    <div class="absolute inset-0 opacity-[0.03]"
      style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

    <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14 pt-24">
      <div class="flex items-center gap-3 mb-4">
        <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
        <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">
          Latest News
        </span>
      </div>

      <h1 class="text-white font-black leading-tight"
          style="font-size: clamp(2.5rem, 6vw, 4.5rem);">
        <?php
        $blog_title = get_the_title(get_option('page_for_posts'));
        echo $blog_title ? $blog_title : 'Blog';
        ?>
      </h1>
    </div>
  </div>
  <div class="h-[3px] bg-[#ff9101]"></div>

  <div class="bg-[#f7f7f7] py-16 ">
    <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

      <!-- Category filters -->
      <?php
      $blg_cats = get_categories(array('orderby' => 'name', 'order' => 'ASC', 'hide_empty' => true));
      if (!empty($blg_cats)) :
        $blg_current_cat = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
      ?>
      <div class="flex flex-wrap items-center gap-3 mb-10 pb-8 border-b-2 border-gray-200">
        <span class="text-gray-400 font-bold text-xs uppercase tracking-[0.25em] flex-shrink-0">Filter:</span>

        <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>"
          class="text-sm font-bold uppercase tracking-widest px-5 py-2 transition-all duration-200
            <?php echo empty($blg_current_cat) ? 'bg-[#ff9101] text-white' : 'bg-white text-gray-500 border border-gray-200 hover:border-[#ff9101] hover:text-[#ff9101]'; ?>">
          All Posts
        </a>

        <?php foreach ($blg_cats as $blg_cat) :
          $blg_is_active = ($blg_current_cat === $blg_cat->slug);
        ?>
          <a href="<?php echo add_query_arg('category', $blg_cat->slug, get_permalink(get_option('page_for_posts'))); ?>"
            class="text-sm font-bold uppercase tracking-widest px-5 py-2 transition-all duration-200
              <?php echo $blg_is_active ? 'bg-[#ff9101] text-white' : 'bg-white text-gray-500 border border-gray-200 hover:border-[#ff9101] hover:text-[#ff9101]'; ?>">
            <?php echo esc_html($blg_cat->name); ?>
            <span class="opacity-60 font-semibold">(<?php echo $blg_cat->count; ?>)</span>
          </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php
      if (isset($_GET['category']) && !empty($_GET['category'])) {
        $blg_cat_slug = sanitize_text_field($_GET['category']);
        $blg_filter_cat = get_category_by_slug($blg_cat_slug);
        if ($blg_filter_cat) {
          query_posts(array('cat' => $blg_filter_cat->term_id, 'paged' => get_query_var('paged') ?: 1));
        }
      }
      ?>

      <?php if (have_posts()) : ?>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-14">
          <?php while (have_posts()) : the_post();
            $blg_post_cats = get_the_category();
          ?>

          <article class="group bg-white rounded-md shadow-sm overflow-hidden border border-gray-100 hover:border-[#ff9101] hover:shadow-xl transition-all duration-300 flex flex-col">

            <!-- Image -->
            <?php if (has_post_thumbnail()) : ?>
            <div class="relative overflow-hidden bg-gray-100 flex-shrink-0" style="padding-top: 58%;">
              <a href="<?php the_permalink(); ?>" class="absolute inset-0 block">
                <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'large')); ?>"
                  alt="<?php the_title_attribute(); ?>"
                  class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
              </a>
              <?php if (!empty($blg_post_cats)) : ?>
                <a href="<?php echo get_category_link($blg_post_cats[0]->term_id); ?>"
                  class="absolute top-3 left-3 bg-[#ff9101] text-white text-xs font-bold uppercase tracking-widest px-3 py-1 hover:bg-[#e07f00] transition-colors">
                  <?php echo esc_html($blg_post_cats[0]->name); ?>
                </a>
              <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="flex flex-col flex-1 p-7">

              <!-- Date + author -->
              <div class="flex items-center gap-3 text-gray-400 text-sm font-semibold mb-4">
                <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date('M j, Y'); ?></time>
                <span class="text-gray-200">•</span>
                <span><?php echo get_the_author(); ?></span>
              </div>

              <!-- Title -->
              <h2 class="text-gray-900 font-black text-xl md:text-2xl leading-tight mb-4">
                <a href="<?php the_permalink(); ?>" class="hover:text-[#ff9101] transition-colors duration-150">
                  <?php the_title(); ?>
                </a>
              </h2>

              <!-- Excerpt -->
              <p class="text-gray-500 text-base md:text-lg leading-relaxed mb-6 flex-1">
                <?php echo wp_trim_words(has_excerpt() ? get_the_excerpt() : get_the_content(), 22, '...'); ?>
              </p>

              <!-- Read more -->
              <a href="<?php the_permalink(); ?>"
                class="self-start inline-flex items-center gap-2 text-[#ff9101] font-black text-xs uppercase tracking-[0.2em] hover:gap-3 transition-all duration-150">
                Read More
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
              </a>

            </div>
          </article>

          <?php endwhile; ?>
        </div>

<!-- Pagination -->
<?php
global $wp_query;

// Debug pagination numbers
if (isset($_GET['debug'])) {
    echo '<div style="background: yellow; padding: 10px; margin: 10px; border: 1px solid black;">';
    echo '<strong>Pagination Debug:</strong><br>';
    echo 'Found posts: ' . $wp_query->found_posts . '<br>';
    echo 'Posts per page: ' . $wp_query->query_vars['posts_per_page'] . '<br>';
    echo 'Max pages: ' . $wp_query->max_num_pages . '<br>';
    echo 'Current page: ' . max(1, get_query_var('paged')) . '<br>';
    echo '</div>';
}

if ($wp_query->max_num_pages > 1) : ?>
<div class="flex justify-center gap-1 flex-wrap mt-12">
  <?php echo paginate_links(array(
    'prev_text' => '<svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg> Previous',
    'next_text' => 'Next <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>',
    'current'   => max(1, get_query_var('paged')),
    'total'     => $wp_query->max_num_pages,
    'end_size'  => 1,
    'mid_size'  => 2,
  )); ?>
</div>
<?php endif; ?>
      <?php else : ?>
        <div class="text-center py-24">
          <svg class="w-16 h-16 text-gray-200 mx-auto mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
          </svg>
          <h2 class="text-gray-900 font-black text-2xl mb-3">No Posts Found</h2>
          <p class="text-gray-400 text-lg">Check back later for new content.</p>
        </div>
      <?php endif; ?>

    </div>
  </div>

<?php } elseif (is_single()) {

  while (have_posts()) : the_post();
    $blg_cats    = get_the_category();
    $blg_tags    = get_the_tags();
    $blg_wc      = str_word_count(strip_tags(get_the_content()));
    $blg_rt      = max(1, ceil($blg_wc / 200));
    $blg_related = get_posts(array(
      'category__in' => wp_get_post_categories(get_the_ID()),
      'numberposts'  => 3,
      'post__not_in' => array(get_the_ID()),
      'orderby'      => 'rand'
    ));
?>

  <!-- ===== SINGLE POST HERO ===== -->
  <div class="relative flex items-end bg-[#111111] overflow-hidden"
    style="min-height: <?php echo has_post_thumbnail() ? '520px' : '360px'; ?>;">

    <?php if (has_post_thumbnail()) : ?>
      <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>"
        alt="<?php the_title_attribute(); ?>"
        class="absolute inset-0 w-full h-full object-cover opacity-40">
    <?php endif; ?>

    <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
    <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-transparent"></div>

    <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14 pt-24">

      <!-- Breadcrumb -->
      <div class="flex items-center gap-2 text-xs font-bold uppercase tracking-widest mb-6">
        <a href="<?php echo home_url(); ?>" class="text-white/40 hover:text-[#ff9101] transition-colors">Home</a>
        <span class="text-white/20">/</span>
        <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" class="text-white/40 hover:text-[#ff9101] transition-colors">Blog</a>
        <?php if (!empty($blg_cats)) : ?>
          <span class="text-white/20">/</span>
          <a href="<?php echo get_category_link($blg_cats[0]->term_id); ?>" class="text-[#ff9101]">
            <?php echo esc_html($blg_cats[0]->name); ?>
          </a>
        <?php endif; ?>
      </div>

      <h1 class="text-white font-black leading-tight mb-6" style="font-size: clamp(2rem, 5vw, 4rem); max-width: 900px;">
        <?php the_title(); ?>
      </h1>

      <div class="flex flex-wrap items-center gap-4 text-white/60 text-sm font-semibold">
        <span class="flex items-center gap-2">
          <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
          </svg>
          <?php echo get_the_date('F j, Y'); ?>
        </span>
        <span class="text-white/20">•</span>
        <span class="flex items-center gap-2">
          <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
          </svg>
          <?php echo get_the_author(); ?>
        </span>
        <span class="text-white/20">•</span>
        <span class="flex items-center gap-2">
          <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
          </svg>
          <?php echo $blg_rt; ?> min read
        </span>
      </div>
    </div>
  </div>
  <div class="h-[3px] bg-[#ff9101]"></div>


  <!-- ===== SINGLE POST BODY ===== -->
  <div class="bg-[#f7f7f7] py-16">
    <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-10">

        <!-- Main content -->
        <div class="lg:col-span-8">
          <article class="bg-white rounded-md shadow-sm overflow-hidden">
            <div class="p-8 md:p-14">

              <!-- Post content with explicit styling -->
              <div class="blg-content">
                <?php the_content(); ?>
              </div>

              <!-- Tags -->
              <?php if (!empty($blg_tags)) : ?>
              <div class="mt-12 pt-8 border-t border-gray-100 flex flex-wrap items-center gap-3">
                <span class="text-gray-400 text-xs font-bold uppercase tracking-widest">Tags:</span>
                <?php foreach ($blg_tags as $blg_tag) : ?>
                  <a href="<?php echo get_tag_link($blg_tag->term_id); ?>"
                    class="bg-gray-100 hover:bg-[#ff9101] hover:text-white text-gray-500 font-bold text-xs uppercase tracking-widest px-4 py-1.5 transition-all duration-150">
                    <?php echo esc_html($blg_tag->name); ?>
                  </a>
                <?php endforeach; ?>
              </div>
              <?php endif; ?>

              <!-- Share -->
              <div class="mt-8 pt-8 border-t border-gray-100 flex flex-wrap items-center gap-4">
                <span class="text-gray-400 text-xs font-bold uppercase tracking-widest">Share:</span>
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>"
                  target="_blank" rel="noopener"
                  class="inline-flex items-center gap-2 bg-[#4267B2] hover:bg-[#365899]  font-bold text-xs uppercase tracking-widest px-5 py-2.5 transition-all duration-150">
                  <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                  Facebook
                </a>
                <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>"
                  target="_blank" rel="noopener"
                  class="inline-flex items-center gap-2 bg-[#1da1f2] hover:bg-[#1a91da]  font-bold text-xs uppercase tracking-widest px-5 py-2.5 transition-all duration-150">
                  <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
                  Twitter
                </a>
              </div>

            </div>
          </article>

          <!-- Back to blog -->
          <div class="mt-8">
            <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>"
              class="inline-flex items-center gap-2 text-gray-400 hover:text-[#ff9101] font-bold text-sm uppercase tracking-widest transition-colors duration-150">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M7 16l-4-4m0 0l4-4m-4 4h18"/>
              </svg>
              Back to Blog
            </a>
          </div>
        </div>

        <!-- Sidebar -->
        <aside class="lg:col-span-4 flex flex-col gap-6">

          <!-- Post details -->
          <div class="bg-white rounded-md shadow-sm overflow-hidden">
            <div class="bg-[#111111] px-6 py-4">
              <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Post Details</h3>
            </div>
            <div class="p-6 flex flex-col gap-5">
              <div class="flex items-center gap-4">
                <span class="flex-shrink-0 w-9 h-9 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                  <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                  </svg>
                </span>
                <div>
                  <p class="text-gray-400 text-xs font-bold uppercase tracking-widest">Published</p>
                  <p class="text-gray-900 font-black text-base"><?php echo get_the_date('F j, Y'); ?></p>
                </div>
              </div>
              <div class="flex items-center gap-4">
                <span class="flex-shrink-0 w-9 h-9 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                  <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                  </svg>
                </span>
                <div>
                  <p class="text-gray-400 text-xs font-bold uppercase tracking-widest">Author</p>
                  <p class="text-gray-900 font-black text-base"><?php echo get_the_author(); ?></p>
                </div>
              </div>
              <div class="flex items-center gap-4">
                <span class="flex-shrink-0 w-9 h-9 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                  <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                  </svg>
                </span>
                <div>
                  <p class="text-gray-400 text-xs font-bold uppercase tracking-widest">Reading Time</p>
                  <p class="text-gray-900 font-black text-base"><?php echo $blg_rt; ?> min read</p>
                </div>
              </div>
            </div>
          </div>

          <!-- Categories -->
          <?php if (!empty($blg_cats)) : ?>
          <div class="bg-white rounded-md shadow-sm overflow-hidden">
            <div class="bg-[#111111] px-6 py-4">
              <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Categories</h3>
            </div>
            <div class="p-6 flex flex-wrap gap-2">
              <?php foreach ($blg_cats as $blg_cat) : ?>
                <a href="<?php echo get_category_link($blg_cat->term_id); ?>"
                  class="bg-gray-100 hover:bg-[#ff9101] hover:text-white text-gray-600 font-bold text-sm uppercase tracking-widest px-4 py-2 transition-all duration-150">
                  <?php echo esc_html($blg_cat->name); ?>
                </a>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>

          <!-- Related posts -->
          <?php if (!empty($blg_related)) : ?>
          <div class="bg-white rounded-md shadow-sm overflow-hidden sticky top-[130px]"  style="top: 130px;">
            <div class="bg-[#111111] px-6 py-4">
              <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Related Posts</h3>
            </div>
            <div class="divide-y divide-gray-100">
              <?php foreach ($blg_related as $blg_rel) : setup_postdata($blg_rel); ?>
              <a href="<?php echo get_permalink($blg_rel->ID); ?>"
                class="group flex gap-4 p-5 hover:bg-gray-50 transition-colors duration-150">
                <?php if (has_post_thumbnail($blg_rel->ID)) : ?>
                  <div class="flex-shrink-0 w-16 h-16 rounded-sm overflow-hidden bg-gray-100">
                    <img src="<?php echo esc_url(get_the_post_thumbnail_url($blg_rel->ID, 'thumbnail')); ?>"
                      alt="" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                  </div>
                <?php endif; ?>
                <div class="min-w-0">
                  <h4 class="text-gray-900 font-black text-base leading-snug group-hover:text-[#ff9101] transition-colors duration-150 mb-1">
                    <?php echo get_the_title($blg_rel->ID); ?>
                  </h4>
                  <p class="text-gray-400 text-sm font-semibold">
                    <?php echo get_the_date('M j, Y', $blg_rel->ID); ?>
                  </p>
                </div>
              </a>
              <?php endforeach; wp_reset_postdata(); ?>
            </div>
          </div>
          <?php endif; ?>

        </aside>

      </div>
    </div>
  </div>



<?php
  endwhile;

} else {

  while (have_posts()) : the_post();

  $hero_eyebrow  = get_field('hero_eyebrow');
  $hero_subtitle = get_field('hero_subtitle');
  $hero_image    = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
  $page_id       = get_the_ID();
  $ancestors     = array_reverse(get_post_ancestors($page_id));
  ?>

  <div class="relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden <?php echo !$hero_image ? 'bg-[#111111]' : ''; ?>"
    <?php if ($hero_image) echo 'style="background-image: url('.esc_url($hero_image).');"'; ?>>

    <?php if (!$hero_image) : ?>
      <div class="absolute inset-0 opacity-[0.04]"
        style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
    <?php endif; ?>

    <div class="absolute inset-0 bg-gradient-to-t <?php echo $hero_image ? 'from-[#0d0d0d] via-[#0d0d0d]/80 to-black/30' : 'from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20'; ?>"></div>
    <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
    <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
      <?php if ($hero_eyebrow) : ?>
        <div class="flex items-center gap-3 mb-4">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">
            <?php echo esc_html($hero_eyebrow); ?>
          </span>
        </div>
      <?php endif; ?>
      <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
      <?php if ($hero_subtitle) : ?>
        <div class="text-white/80 text-lg md:text-xl leading-relaxed max-w-2xl mt-4">
          <?php echo esc_html($hero_subtitle); ?>
        </div>
      <?php endif; ?>
      <?php if (!is_front_page()) : ?>
        <div class="flex items-center gap-2 text-white/60 text-sm mt-6">
          <a href="<?php echo esc_url(home_url('/')); ?>" class="hover:text-white transition-colors">Home</a>
          <?php foreach ($ancestors as $ancestor_id) : ?>
            <span>/</span>
            <a href="<?php echo esc_url(get_permalink($ancestor_id)); ?>" class="hover:text-white transition-colors">
              <?php echo esc_html(get_the_title($ancestor_id)); ?>
            </a>
          <?php endforeach; ?>
          <span>/</span>
          <span class="text-white"><?php echo esc_html(get_the_title()); ?></span>
        </div>
      <?php endif; ?>
    </div>
  </div>
  <div class="h-[3px] bg-[#ff9101]"></div>

  <div class="bg-[#f7f7f7] py-16">
    <div class="max-w-screen-2xl mx-auto px-6 md:px-14"> 
		
    <!--  <div class="bg-white rounded-md shadow-sm p-8 md:p-14 blg-content"> -->
      <div class="">
        <?php the_content(); ?>
      </div>
    </div>
  </div>

  <?php endwhile;
}

get_footer();
?>
