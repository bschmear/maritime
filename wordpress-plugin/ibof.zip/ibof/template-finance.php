<?php
/**
 * Template Name: Finance
 */
get_header();
while (have_posts()) : the_post();
?>

<!-- ===== PAGE HERO ===== -->
<div class="fin-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden"
  <?php if (has_post_thumbnail()) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>

  <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Boat Financing</span>
    </div>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== PAGE CONTENT ===== -->
<?php $fin_content = get_the_content(); if ($fin_content) : ?>
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="max-w-4xl mx-auto text-center text-gray-600 text-lg md:text-xl lg:text-2xl leading-relaxed">
      <?php the_content(); ?>
    </div>
  </div>
</div>
<?php endif; ?>
<?php
endwhile;
get_footer();
?>