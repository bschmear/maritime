<?php
get_header();
?>

<!-- ===== PAGE HERO ===== -->
<div class="locations-hero relative min-h-[420px] flex items-end bg-[#111111] overflow-hidden">
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
  <div class="absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Our Locations</span>
    </div>
    <h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">Find Us Near You</h1>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== LOCATIONS GRID ===== -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <?php if (have_posts()) : ?>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">

        <?php while (have_posts()) : the_post(); ?>

          <article class="location-card group bg-white rounded-md shadow-sm overflow-hidden border border-gray-100 hover:border-[#ff9101] hover:shadow-lg transition-all duration-300">

            <!-- Featured Image -->
            <?php if (has_post_thumbnail()) : ?>
              <div class="relative overflow-hidden bg-gray-100" style="padding-top: 60%;">
                <a href="<?php the_permalink(); ?>" class="absolute inset-0 block">
                  <img src="<?php the_post_thumbnail_url('large'); ?>"
                    alt="<?php the_title_attribute(); ?>"
                    class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                </a>
              </div>
            <?php else : ?>
              <div class="relative overflow-hidden bg-gray-100" style="padding-top: 60%;">
                <a href="<?php the_permalink(); ?>" class="absolute inset-0 block flex items-center justify-center">
                  <svg class="w-16 h-16 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                      d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                      d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                  </svg>
                </a>
              </div>
            <?php endif; ?>

            <!-- Card Content -->
            <div class="p-6">

              <h2 class="text-gray-900 font-black text-xl leading-tight mb-4">
                <a href="<?php the_permalink(); ?>" class="hover:text-[#ff9101] transition-colors">
                  <?php the_title(); ?>
                </a>
              </h2>

              <!-- Location excerpt -->
              <div class="text-gray-600 text-base leading-relaxed mb-4">
                <?php
                if (has_excerpt()) {
                  the_excerpt();
                } else {
                  echo wp_trim_words(get_the_content(), 15, '...');
                }
                ?>
              </div>

              <!-- View Details Button -->
              <a href="<?php the_permalink(); ?>"
                class="inline-flex items-center gap-2 text-[#ff9101] font-bold text-sm uppercase tracking-widest hover:underline">
                View Location
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
              </a>

            </div>

          </article>

        <?php endwhile; ?>

      </div>

    <?php else : ?>

      <div class="text-center py-16">
        <svg class="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
            d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
            d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
        </svg>
        <h2 class="text-gray-900 font-black text-2xl mb-2">No Locations Found</h2>
        <p class="text-gray-500 text-lg">Check back later for location updates.</p>
      </div>

    <?php endif; ?>

  </div>
</div>

<?php get_footer(); ?>