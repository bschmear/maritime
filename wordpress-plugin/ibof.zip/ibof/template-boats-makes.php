<?php
/*
Template Name: Boats Makes
*/
get_header();

// Get all makes
$makes = get_categories(array('taxonomy' => 'make'));

// Check if we're on a specific term page
$current_term = get_queried_object();
if ($current_term && $current_term->taxonomy === 'make') {
    // This is a specific make page, but we're loading the makes template
    // This shouldn't happen with our template_include filter, but just in case
    wp_redirect(get_term_link($current_term));
    exit;
}
?>

<!-- ===== PAGE HERO ===== -->
<div class="boats-makes-hero relative min-h-[420px] flex items-end bg-[#111111] overflow-hidden">
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
  <div class="absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Boat Brands</span>
    </div>
    <h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">
      Choose Your Brand
    </h1>
    <p class="text-white/80 text-lg md:text-xl leading-relaxed max-w-2xl mt-4">
      Browse our collection of premium inflatable boat brands. Each manufacturer offers unique features and quality craftsmanship.
    </p>

    <!-- Breadcrumb -->
    <div class="flex items-center gap-2 text-white/60 text-sm mt-6">
      <a href="<?php echo home_url(); ?>" class="hover:text-white transition-colors">Home</a>
      <span>/</span>
      <a href="<?php echo home_url('/boats/'); ?>" class="hover:text-white transition-colors">Boats</a>
      <span>/</span>
      <span class="text-white">Makes</span>
    </div>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>

<!-- ===== BRANDS GRID ===== -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">


    <?php if (!empty($makes)) : ?>

      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">

        <?php foreach ($makes as $make) :
          $make_image = get_term_meta($make->term_id, 'tax_image', true);
          $make_logo = get_term_meta($make->term_id, 'tax_logo', true);

          // Skip brands without images
          if (!$make_image && !$make_logo) {
            continue;
          }

          // Get boat count for this make
          $make_args = array(
            'post_type' => 'boats',
            'tax_query' => array(
              array('taxonomy' => 'make', 'field' => 'slug', 'terms' => $make->slug)
            ),
            'posts_per_page' => -1
          );

          // Exclude sold boats by default unless show_sold is checked
          if (!isset($_GET['show_sold']) || !$_GET['show_sold']) {
            $make_args['meta_query'] = array(
              array(
                'key' => 'boat_sold',
                'compare' => 'NOT EXISTS' // Exclude boats that have the boat_sold meta key (which means they're sold)
              )
            );
          }

          $make_query = new WP_Query($make_args);
          $boat_count = $make_query->found_posts;
          wp_reset_postdata();
        ?>

          <a href="<?php echo get_term_link($make); ?>"
            class="group block bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-200 hover:border-[#ff9101]">

            <!-- Brand image/logo area -->
            <div class="aspect-square bg-gray-50 flex items-center justify-center p-8 relative overflow-hidden cursor-pointer">
              <?php if ($make_logo) : ?>
                <img src="<?php echo esc_url($make_logo); ?>"
                  alt="<?php echo esc_attr($make->name); ?>"
                  class="max-w-full max-h-full w-auto h-auto object-contain transition-transform duration-300 group-hover:scale-105 pointer-events-none">
              <?php elseif ($make_image) : ?>
                <div class="absolute inset-0 bg-cover bg-center"
                  style="background-image: url(<?php echo esc_url($make_image); ?>);"></div>
                <div class="absolute inset-0 bg-black/10 group-hover:bg-black/20 transition-colors duration-300"></div>
              <?php else : ?>
                <div class="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                  <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                      d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                  </svg>
                </div>
              <?php endif; ?>

              <!-- Subtle hover indicator -->
              <div class="absolute inset-0 bg-[#ff9101]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>

            <!-- Brand name -->
            <div class="p-6 text-center bg-white">
              <h3 class="text-gray-900 font-bold text-lg mb-2 group-hover:text-[#ff9101] transition-colors duration-200">
                <?php echo esc_html($make->name); ?>
              </h3>
              <p class="text-gray-500 text-sm">
                <?php echo $boat_count; ?> <?php echo $boat_count === 1 ? 'boat' : 'boats'; ?> available
              </p>

              <!-- View boats link -->
              <div class="mt-4 inline-flex items-center gap-2 text-[#ff9101] font-semibold text-sm group-hover:text-[#e07f00] transition-colors duration-200">
                View Collection
                <svg class="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
              </div>
            </div>

          </a>

        <?php endforeach; ?>

      </div>

    <?php else : ?>

      <div class="text-center py-16">
        <svg class="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
            d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
        </svg>
        <h2 class="text-gray-900 font-black text-2xl mb-2">No Brands Found</h2>
        <p class="text-gray-500 text-lg">Check back later for new boat brands.</p>
      </div>

    <?php endif; ?>

  </div>
</div>

<?php get_footer(); ?>