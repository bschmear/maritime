<?php
/**
 * Template Name: Careers
 */
get_header();

while (have_posts()) : the_post();

$careers_query = new WP_Query(array(
  'post_type'      => 'careers',
  'posts_per_page' => -1,
  'orderby'        => 'title',
  'order'          => 'ASC',
  'meta_query'     => array(
    'relation' => 'OR',
    array(
      'key'     => 'active',
      'compare' => 'NOT EXISTS',
    ),
    array(
      'key'     => 'active',
      'value'   => '1',
      'compare' => '=',
    ),
    array(
      'key'     => 'active',
      'value'   => 1,
      'compare' => '=',
    ),
  ),
));

$hero_subtitle = trim(get_the_excerpt());
if (!$hero_subtitle) {
  $hero_subtitle = 'Explore open positions at Inflatable Boats of Florida and build your career on the water.';
}

$open_count = $careers_query->found_posts;
?>

<!-- ===== CAREERS HEADER (unique layout) ===== -->
<section class="careers-hero relative overflow-hidden bg-[#eef4fa] border-b border-[#d6e4f0]">
  <div class="absolute top-0 right-0 w-1/2 h-full bg-[#032972] hidden lg:block skew-x-[-6deg] translate-x-24 origin-top-right"></div>

  <div class="relative max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center py-14 md:py-20 lg:py-24">

      <div class="lg:col-span-7 xl:col-span-6">
        <div class="inline-flex items-center gap-2 bg-white border border-[#ff9101]/30 text-[#ff9101] text-xs font-black uppercase tracking-[0.25em] px-4 py-2 rounded-full mb-8 shadow-sm">
          <span class="w-2 h-2 rounded-full bg-[#ff9101] animate-pulse"></span>
          We're Hiring
        </div>

        <?php the_title('<h1 class="text-[#032972] font-black leading-[1.02] mb-6" style="font-size: clamp(2.75rem, 6vw, 4.75rem);">', '</h1>'); ?>

        <p class="text-[#4f7cb1] text-xl md:text-2xl leading-relaxed max-w-xl mb-8">
          <?php echo esc_html($hero_subtitle); ?>
        </p>

        <?php if (get_the_content()) : ?>
          <div class="text-gray-600 text-lg leading-relaxed max-w-2xl mb-10 ibof-wysiwyg">
            <?php the_content(); ?>
          </div>
        <?php endif; ?>

        <div class="flex flex-col sm:flex-row sm:items-center gap-5 sm:gap-8">
          <a href="#open-positions"
            class="inline-flex items-center justify-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-black text-sm uppercase tracking-[0.2em] px-8 py-4 transition-all duration-200 shadow-lg shadow-[#ff9101]/20">
            View Open Roles
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
            </svg>
          </a>

          <div class="flex items-center gap-6 text-sm">
            <div>
              <p class="text-[#032972] font-black text-3xl leading-none"><?php echo esc_html($open_count); ?></p>
              <p class="text-gray-500 font-semibold uppercase tracking-widest mt-1">
                <?php echo $open_count === 1 ? 'Open Role' : 'Open Roles'; ?>
              </p>
            </div>
            <div class="w-px h-10 bg-[#c5d8ea]"></div>
            <div>
              <p class="text-[#032972] font-black text-lg leading-tight">Southwest Florida</p>
              <p class="text-gray-500 font-semibold uppercase tracking-widest mt-1">Marine Industry</p>
            </div>
          </div>
        </div>
      </div>

      <div class="lg:col-span-5 xl:col-span-6">
        <div class="space-y-4">
          <div class="rounded-2xl bg-[#032972] text-white p-8 md:p-10 shadow-xl shadow-[#032972]/15">
            <p class="text-[#ff9101] text-xs font-bold uppercase tracking-[0.3em] mb-3">Life at IBOF</p>
            <p class="font-black text-2xl md:text-3xl leading-tight">
              Work where the water meets world-class boats.
            </p>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
            <div class="bg-white border border-[#d6e4f0] rounded-xl p-6 shadow-sm">
              <div class="w-10 h-10 rounded-full bg-[#ff9101]/10 flex items-center justify-center mb-4">
                <svg class="w-5 h-5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
              </div>
              <p class="text-gray-400 text-[12px] font-bold uppercase tracking-widest mb-1">Culture</p>
              <p class="text-[#032972] font-black text-lg leading-snug">Team-driven · Customer-focused</p>
            </div>

            <div class="bg-white border border-[#d6e4f0] rounded-xl p-6 shadow-sm">
              <div class="w-10 h-10 rounded-full bg-[#4f7cb1]/10 flex items-center justify-center mb-4">
                <svg class="w-5 h-5 text-[#4f7cb1]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                </svg>
              </div>
              <p class="text-gray-400 text-[12px] font-bold uppercase tracking-widest mb-1">Industry</p>
              <p class="text-[#032972] font-black text-lg leading-snug">Premium inflatables &amp; outboard expertise</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ===== OPEN POSITIONS ===== -->
<div id="open-positions" class="bg-[#f7f7f7] py-16 min-h-[50vh] scroll-mt-8">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <?php if ($careers_query->have_posts()) : ?>

      <div class="flex items-center gap-4 mb-10">
        <p class="text-gray-500 text-lg font-medium flex-shrink-0">
          <span class="text-gray-900 font-black text-lg"><?php echo esc_html($careers_query->found_posts); ?></span>
          <?php echo $careers_query->found_posts === 1 ? 'open position' : 'open positions'; ?>
        </p>
        <div class="h-px flex-1 bg-gray-200"></div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <?php while ($careers_query->have_posts()) : $careers_query->the_post();
          $job_title = ibof_get_career_title();
          $job_location = ibof_get_career_location_name();
        ?>
          <article class="group bg-white rounded-md shadow-sm border border-gray-100 hover:border-[#ff9101] hover:shadow-lg transition-all duration-300 flex flex-col">
            <div class="p-8 flex flex-col flex-1">
              <?php if ($job_location) : ?>
                <p class="text-[#ff9101] text-[12px] font-bold uppercase tracking-[0.25em] mb-2">
                  <?php echo esc_html($job_location); ?>
                </p>
              <?php endif; ?>

              <h2 class="text-gray-900 font-black text-2xl leading-tight mb-4">
                <a href="<?php the_permalink(); ?>" class="hover:text-[#ff9101] transition-colors duration-150">
                  <?php echo esc_html($job_title); ?>
                </a>
              </h2>

              <div class="text-gray-500 text-lg leading-relaxed mb-6 line-clamp-4">
                <?php echo wp_trim_words(wp_strip_all_tags(ibof_get_career_description()), 28, '...'); ?>
              </div>

              <a href="<?php the_permalink(); ?>"
                class="mt-auto inline-flex items-center gap-2 text-[#ff9101] font-bold text-sm uppercase tracking-widest group-hover:gap-3 transition-all duration-200">
                View Position
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
              </a>
            </div>
          </article>
        <?php endwhile; ?>
      </div>

      <?php wp_reset_postdata(); ?>

    <?php else : ?>

      <div class="flex flex-col items-center justify-center py-24 text-center">
        <svg class="w-16 h-16 text-gray-200 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
            d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
        </svg>
        <h2 class="text-gray-900 font-black text-2xl mb-3">No Open Positions Right Now</h2>
        <p class="text-gray-400 text-lg mb-8 max-w-md">
          We do not have any active listings at the moment. Check back soon or reach out to introduce yourself.
        </p>
        <a href="<?php echo esc_url(home_url('/contact/')); ?>"
          class="inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold px-7 py-3.5 text-md uppercase tracking-[0.2em] transition-all duration-200">
          Contact Us
        </a>
      </div>

    <?php endif; ?>

  </div>
</div>

<?php
endwhile;
get_footer();
?>
