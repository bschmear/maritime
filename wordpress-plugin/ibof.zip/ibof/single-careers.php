<?php
get_header();

while (have_posts()) : the_post();
  $career_id = get_the_ID();
  $job_title = ibof_get_career_title($career_id);
  $job_location = ibof_get_career_location_name($career_id);
  $job_description = ibof_get_career_description($career_id);
  $recipient_email = ibof_get_career_recipient_email($career_id);
  $is_active = ibof_career_is_active($career_id);
?>

<!-- ===== PAGE HERO ===== -->
<div class="relative min-h-[360px] flex items-end bg-[#111111] overflow-hidden">
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
  <div class="absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14 pt-24">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Career Opportunity</span>
    </div>
    <h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">
      <?php echo esc_html($job_title); ?>
    </h1>
    <?php if ($job_location) : ?>
      <p class="text-white/80 text-lg md:text-xl leading-relaxed max-w-2xl mt-4 flex items-center gap-2">
        <svg class="w-5 h-5 text-[#ff9101] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
          <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
        </svg>
        <?php echo esc_html($job_location); ?>
      </p>
    <?php endif; ?>

    <div class="flex items-center gap-2 text-white/60 text-sm mt-6">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="hover:text-white transition-colors">Home</a>
      <span>/</span>
      <a href="<?php echo esc_url(ibof_get_careers_page_url()); ?>" class="hover:text-white transition-colors">Careers</a>
      <span>/</span>
      <span class="text-white"><?php echo esc_html($job_title); ?></span>
    </div>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>

<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">



    <div class="grid grid-cols-1 lg:grid-cols-12 gap-10">

      <div class="lg:col-span-7">
        <div class="bg-white rounded-md shadow-sm border border-gray-100 overflow-hidden">
          <div class="bg-[#111111] px-8 py-5">
            <h2 class="text-white font-black text-sm uppercase tracking-[0.25em]">Position Details</h2>
          </div>
          <div class="p-8 md:p-10 ibof-wysiwyg">
            <?php echo $job_description; ?>
          </div>
        </div>
      </div>

      <div class="lg:col-span-5">
        <?php if (!$is_active) : ?>
          <div class="bg-white rounded-md shadow-sm border border-gray-200 p-8 text-center">
            <h2 class="text-gray-900 font-black text-xl mb-3">Position Closed</h2>
            <p class="text-gray-500 mb-6">This role is no longer accepting applications.</p>
            <a href="<?php echo esc_url(ibof_get_careers_page_url()); ?>"
              class="inline-flex items-center gap-2 text-[#ff9101] font-bold text-sm uppercase tracking-widest hover:underline">
              View other openings
            </a>
          </div>
        <?php elseif ($recipient_email) : ?>
          <div class="bg-white rounded-md shadow-sm border border-gray-100 overflow-hidden">
            <div class="bg-[#111111] px-8 py-5 flex items-center gap-3">
              <svg class="w-5 h-5 text-[#ff9101] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              <h2 class="text-white font-black text-sm uppercase tracking-[0.25em]">Apply for This Role</h2>
            </div>

            <form action="<?php echo esc_url(get_template_directory_uri() . '/form-career-apply.php'); ?>"
              method="POST" id="form-career-apply" novalidate class="p-8 md:p-10">

              <input type="text" name="username" tabindex="-1" aria-hidden="true" autocomplete="new-password" class="hidden">
              <input type="hidden" name="career_id" value="<?php echo esc_attr($career_id); ?>">

              <?php
              $ca_input = "w-full border-0 border-b-2 border-gray-200 focus:border-[#ff9101] bg-transparent px-0 py-2.5 text-lg text-gray-800 font-semibold focus:outline-none focus:ring-0 transition-colors duration-150 placeholder:text-gray-300";
              $ca_label = "block text-xs font-bold uppercase tracking-[0.2em] text-gray-400 mb-1";
              ?>

              <div class="space-y-4 mb-8">
                <div class="">
                  <label class="<?php echo $ca_label; ?>">Name <span class="text-[#ff9101]">*</span></label>
                  <input type="text" name="name" placeholder="Your full name" required class="<?php echo $ca_input; ?>">
                </div>
                <div>
                  <label class="<?php echo $ca_label; ?>">Email <span class="text-[#ff9101]">*</span></label>
                  <input type="email" name="email" placeholder="your@email.com" required class="<?php echo $ca_input; ?>">
                </div>
                <div>
                  <label class="<?php echo $ca_label; ?>">Phone <span class="text-[#ff9101]">*</span></label>
                  <input type="tel" name="phone" placeholder="(000) 000-0000" required class="<?php echo $ca_input; ?>">
                </div>
                <div>
                  <label class="<?php echo $ca_label; ?>">Cover Letter / Message <span class="text-[#ff9101]">*</span></label>
                  <textarea name="message" required rows="6"
                    placeholder="Tell us why you are a great fit for this role."
                    class="w-full border-2 border-gray-200 focus:border-[#ff9101] bg-transparent px-4 py-3 text-md text-gray-800 font-semibold focus:outline-none focus:ring-0 transition-colors duration-150 resize-none rounded-sm placeholder:text-gray-300 mt-1"></textarea>
                </div>
              </div>

              <div class="flex flex-col gap-6 pt-6 border-t border-gray-100">
                <div class="g-recaptcha" data-sitekey="<?php echo esc_attr(get_theme_mod('fg_recaptcha_site_key')); ?>"></div>
                <button type="submit" id="career-submit"
                  class="w-full inline-flex items-center justify-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] disabled:opacity-40 text-white font-black text-sm uppercase tracking-[0.2em] px-10 py-4 transition-all duration-200">
                  Submit Application
                </button>
              </div>
            </form>
          </div>
        <?php else : ?>
          <div class="bg-white rounded-md shadow-sm border border-gray-200 p-8 text-center">
            <h2 class="text-gray-900 font-black text-xl mb-3">Interested in this role?</h2>
            <p class="text-gray-500 mb-6">Please contact us to learn more about applying.</p>
            <a href="<?php echo esc_url(home_url('/contact/')); ?>"
              class="inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold px-7 py-3.5 text-sm uppercase tracking-[0.2em] transition-all duration-200">
              Contact Us
            </a>
          </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>

<div id="career-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-6 hidden">
  <div class="bg-white rounded-md shadow-2xl w-full max-w-md overflow-hidden">
    <div class="bg-[#111111] px-6 py-4 flex items-center justify-between">
      <span class="text-white font-black text-sm uppercase tracking-[0.25em]">Application Sent</span>
      <button id="career-modal-close" type="button" class="text-white/40 hover:text-white transition-colors">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
        </svg>
      </button>
    </div>
    <div class="p-8 text-center">
      <div id="career-modal-content" class="text-gray-600 text-lg leading-relaxed"></div>
    </div>
  </div>
</div>

<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script>
(function () {
  const form = document.getElementById('form-career-apply');
  if (!form) return;

  const modal = document.getElementById('career-modal');
  const closeBtn = document.getElementById('career-modal-close');
  const content = document.getElementById('career-modal-content');
  const submitBtn = document.getElementById('career-submit');

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    let valid = true;
    form.querySelectorAll('[required]').forEach(function (el) {
      if (!el.checkValidity()) {
        el.classList.add('border-red-400');
        valid = false;
      } else {
        el.classList.remove('border-red-400');
      }
    });

    if (!valid) return;

    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending...';

    fetch(form.action, { method: 'POST', body: new FormData(form) })
      .then(function (response) { return response.text(); })
      .then(function (result) {
        content.innerHTML = result;
        modal.classList.remove('hidden');
        form.reset();
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Application';
      })
      .catch(function () {
        content.innerHTML = 'Something went wrong. Please try again or contact us directly.';
        modal.classList.remove('hidden');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Application';
      });
  });

  closeBtn.addEventListener('click', function () { modal.classList.add('hidden'); });
  modal.addEventListener('click', function (e) { if (e.target === modal) modal.classList.add('hidden'); });
})();
</script>

<?php
endwhile;
get_footer();
?>
