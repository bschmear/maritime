<?php
/*
Template Name: Boats by Make
*/
get_header();

// Get the make term from the taxonomy query
$make_term = get_queried_object();
$make_slug = $make_term ? $make_term->slug : '';
$make_name = $make_term ? $make_term->name : 'Unknown Brand';

// Handle pagination
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

// Query boats for this make
$args = array(
    'post_type' => 'boats',
    'posts_per_page' => 50,
    'paged' => $paged,
    'tax_query' => array(
        array(
            'taxonomy' => 'make',
            'field' => 'slug',
            'terms' => $make_slug
        )
    )
);

// Exclude sold boats by default unless show_sold is checked
if (!isset($_GET['show_sold']) || !$_GET['show_sold']) {
    $args['meta_query'] = array(
        array(
            'key' => 'boat_sold',
            'compare' => 'NOT EXISTS' // Exclude boats that have the boat_sold meta key (which means they're sold)
        )
    );
}

$boats_query = new WP_Query($args);
?>

<!-- ===== PAGE HERO ===== -->
<div class="boats-by-make-hero relative min-h-[420px] flex items-end bg-[#111111] overflow-hidden">
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
  <div class="absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <?php if ($make_term) : ?>
    <?php $make_image = get_term_meta($make_term->term_id, 'tax_image', true); ?>
    <?php if ($make_image) : ?>
      <div class="absolute inset-0 bg-cover bg-center"
        style="background-image: url(<?php echo esc_url($make_image); ?>);"></div>
      <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/80 to-black/30"></div>
    <?php endif; ?>
  <?php endif; ?>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Boat Brand</span>
    </div>
    <h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">
      <?php echo esc_html($make_name); ?> Boats
    </h1>
    <p class="text-white/80 text-lg md:text-xl leading-relaxed max-w-2xl mt-4">
      Discover our complete collection of <?php echo esc_html($make_name); ?> boats. Each model offers premium quality and exceptional performance.
    </p>

    <!-- Breadcrumb -->
    <div class="flex items-center gap-2 text-white/60 text-sm mt-6">
      <a href="<?php echo home_url(); ?>" class="hover:text-white transition-colors">Home</a>
      <span>/</span>
      <a href="<?php echo home_url('/boats/'); ?>" class="hover:text-white transition-colors">Boats</a>
      <span>/</span>
      <a href="<?php echo home_url('/make/'); ?>" class="hover:text-white transition-colors">Makes</a>
      <span>/</span>
      <span class="text-white"><?php echo esc_html($make_name); ?></span>
    </div>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>

<!-- ===== BOATS GRID ===== -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
<!-- Brand Switcher + Filter Bar -->
<div class="mb-10 bg-white border border-gray-100 shadow-sm overflow-hidden">
  <div class="flex flex-col sm:flex-row items-stretch sm:items-center divide-y sm:divide-y-0 sm:divide-x divide-gray-100">

    <!-- Label -->
    <div class="flex items-center gap-2 px-6 py-4 flex-shrink-0">
      <svg class="w-4 h-4 text-[#ff9101] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M8 7h12M8 12h12M8 17h12M4 7h.01M4 12h.01M4 17h.01"/>
      </svg>
      <span class="text-gray-400 font-bold text-xs uppercase tracking-[0.25em] whitespace-nowrap">Filter</span>
    </div>

    <!-- Brand select — navigates to brand URL -->
    <div class="flex-1 relative">
      <select onchange="if(this.value) window.location.href=this.value"
        class="w-full bg-transparent border-0 px-6 py-4 text-gray-900 font-semibold text-base focus:outline-none focus:ring-0 cursor-pointer appearance-none pr-10">
        <option value="">All Brands</option>
        <?php
        $all_makes = get_categories(array('taxonomy' => 'make'));
        foreach ($all_makes as $brand) :
          // Skip brands without images
          $brand_image = get_term_meta($brand->term_id, 'tax_image', true);
          $brand_logo = get_term_meta($brand->term_id, 'tax_logo', true);
          if (!$brand_image && !$brand_logo) {
            continue;
          }

          $brand_url = get_term_link($brand);
          $selected  = ($brand->slug === $make_slug) ? 'selected' : '';
        ?>
          <option value="<?php echo esc_url($brand_url); ?>" <?php echo $selected; ?>>
            <?php echo esc_html($brand->name); ?> (<?php echo $brand->count; ?>)
          </option>
        <?php endforeach; ?>
      </select>
      <svg class="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
      </svg>
    </div>

    <!-- Sold toggle — GET param on current URL -->
    <?php
    $show_sold   = isset($_GET['show_sold']) && $_GET['show_sold'];
    $toggle_url  = $show_sold
      ? remove_query_arg('show_sold')
      : add_query_arg('show_sold', '1');
    ?>
    <a href="<?php echo esc_url($toggle_url); ?>"
      class="flex items-center gap-3 px-6 py-4 flex-shrink-0 group cursor-pointer <?php echo $show_sold ? 'bg-gray-50' : ''; ?>">
      <!-- Toggle track -->
      <div class="relative flex-shrink-0 w-10 h-6">
        <div class="w-10 h-6 <?php echo $show_sold ? 'bg-[#ff9101]' : 'bg-gray-200'; ?> transition-colors duration-200"></div>
        <div class="absolute top-1 left-1 w-4 h-4 bg-white shadow-sm transition-transform duration-200 <?php echo $show_sold ? 'translate-x-4' : ''; ?>"></div>
      </div>
      <span class="font-bold text-xs uppercase tracking-[0.25em] whitespace-nowrap transition-colors duration-150 <?php echo $show_sold ? 'text-gray-900' : 'text-gray-400'; ?>">
        Show Sold
      </span>
    </a>

    <!-- All Brands link -->
    <a href="<?php echo home_url('/make/'); ?>"
      class="flex items-center justify-center gap-2 px-7 py-4 bg-[#ff9101] hover:bg-[#e07f00] text-white font-black text-xs uppercase tracking-[0.2em] transition-all duration-200 flex-shrink-0 whitespace-nowrap">
      All Brands
      <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
      </svg>
    </a>

  </div>
</div>

    <?php if ($boats_query->have_posts()) : ?>

      <!-- Result count bar -->
      <div class="flex items-center gap-4 mb-8">
        <p class="text-gray-500 text-lg font-medium flex-shrink-0">
          <span class="text-gray-900 font-black text-lg"><?php echo $boats_query->found_posts; ?></span>
          <?php echo $boats_query->found_posts === 1 ? 'boat' : 'boats'; ?> found
        </p>
        <div class="h-px flex-1 bg-gray-200"></div>
        <span class="flex-shrink-0 text-[#ff9101] text-lg font-bold uppercase tracking-widest">
          <?php echo esc_html($make_name); ?>
        </span>
      </div>

      <!-- Boats grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <?php while ($boats_query->have_posts()) : $boats_query->the_post(); ?>

          <?php
          $bfl_make_terms = has_term('', 'make') ? get_the_terms($post->ID, 'make') : array();
          $bfl_make_name  = (!empty($bfl_make_terms) && !is_wp_error($bfl_make_terms)) ? $bfl_make_terms[0]->name : '';
          $bfl_type_terms = get_the_terms($post->ID, 'type');
          $bfl_type_name  = (!empty($bfl_type_terms) && !is_wp_error($bfl_type_terms)) ? $bfl_type_terms[0]->name : '';
          $bfl_img        = (!empty($post->boat_images['image'][0])) ? $post->boat_images['image'][0] : '';
          ?>

          <article class="bfl-boat group bg-white rounded-md overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col">

            <!-- Image -->
            <a href="<?php the_permalink(); ?>"
              class="block relative overflow-hidden bg-gray-100 flex-shrink-0"
              style="padding-top: 62%;">
              <?php if ($bfl_img) : ?>
                <img src="<?php echo esc_url($bfl_img); ?>"
                  alt="<?php the_title_attribute(); ?>"
                  class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 lazy">
              <?php else : ?>
                <div class="absolute inset-0 flex items-center justify-center bg-gray-50">
                  <svg class="w-14 h-14 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                      d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                  </svg>
                </div>
              <?php endif; ?>

              <!-- Type badge -->
              <?php if ($bfl_type_name) : ?>
                <span class="absolute top-3 left-3 bg-[#ff9101] text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">
                  <?php echo esc_html($bfl_type_name); ?>
                </span>
              <?php endif; ?>

              <!-- Sold badge -->
              <?php if ($post->boat_sold) : ?>
                <span class="absolute top-3 right-3 bg-red-600 text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">
                  SOLD
                </span>
              <?php endif; ?>
            </a>

            <!-- Card body -->
            <div class="flex flex-col flex-1 p-6">

              <?php if ($bfl_make_name) : ?>
                <p class="text-[#ff9101] text-md font-bold uppercase tracking-widest mb-1">
                  <?php echo esc_html($bfl_make_name); ?>
                </p>
              <?php endif; ?>

              <h2 class="text-gray-900 font-black text-2xl leading-tight mb-4">
                <a href="<?php the_permalink(); ?>" class="hover:text-[#ff9101] transition-colors duration-150">
                  <?php the_title(); ?>
                </a>
              </h2>

              <!-- Specs -->
              <?php if ($post->boat_length || $post->boat_weight || $post->boat_passengers || $post->boat_hp) : ?>
              <div class="grid grid-cols-2 gap-2 mb-5 pb-5 border-b border-gray-100">
                <?php if ($post->boat_length) : ?>
                <div class="flex flex-col">
                  <span class="text-[12px] font-bold uppercase tracking-widest text-gray-400">Length</span>
                  <span class="text-gray-900 font-black text-md"><?php echo esc_html($post->boat_length); ?>'</span>
                </div>
                <?php endif; ?>
                <?php if ($post->boat_weight) : ?>
                <div class="flex flex-col">
                  <span class="text-[12px] font-bold uppercase tracking-widest text-gray-400">Weight</span>
                  <span class="text-gray-900 font-black text-md"><?php echo esc_html($post->boat_weight); ?> lbs</span>
                </div>
                <?php endif; ?>
                <?php if ($post->boat_passengers) : ?>
                <div class="flex flex-col">
                  <span class="text-[12px] font-bold uppercase tracking-widest text-gray-400">Max Capacity</span>
                  <span class="text-gray-900 font-black text-md"><?php echo esc_html($post->boat_passengers); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($post->boat_hp) : ?>
                <div class="flex flex-col">
                  <span class="text-[12px] font-bold uppercase tracking-widest text-gray-400">Max HP</span>
                  <span class="text-gray-900 font-black text-md"><?php echo esc_html($post->boat_hp); ?></span>
                </div>
                <?php endif; ?>
              </div>
              <?php endif; ?>

              <!-- Actions -->
              <div class="mt-auto flex flex-col sm:flex-row gap-2 sm:gap-3">
                <a href="<?php echo home_url(); ?>/my-boat-quotes/"
                  data-postid="<?php the_id(); ?>"
                  class="mbq-link w-full text-center bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-4 py-3 text-xs uppercase tracking-widest transition-all duration-150">
                  Request Quote
                </a>
                <a href="<?php the_permalink(); ?>"
                  class="w-full text-center bg-gray-900 hover:bg-[#ff9101] text-white font-bold px-4 py-3 text-xs uppercase tracking-widest transition-all duration-200">
                  View Details
                </a>
              </div>

            </div>
          </article>

        <?php endwhile; ?>
      </div>

      <!-- Pagination -->
      <?php if ($boats_query->max_num_pages > 1) : ?>
        <div class="flex justify-center mt-12">
          <?php
          echo paginate_links(array(
            'total' => $boats_query->max_num_pages,
            'current' => max(1, $paged),
            'prev_text' => '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg> Previous',
            'next_text' => 'Next <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>',
            'base' => get_term_link($make_term) . '%_%',
            'format' => 'page/%#%/'
          ));
          ?>
        </div>
      <?php endif; ?>

    <?php else : ?>

      <div class="text-center py-24">
        <svg class="w-16 h-16 text-gray-200 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
            d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <h3 class="text-gray-900 font-black text-2xl mb-3">No Boats Found</h3>
        <p class="text-gray-400 text-lg mb-8 max-w-sm mx-auto">No <?php echo esc_html($make_name); ?> boats are currently available.</p>
        <a href="<?php echo home_url('/make/'); ?>"
          class="inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold px-7 py-3.5 text-md uppercase tracking-[0.2em] transition-all duration-200">
          Browse All Brands
          <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
          </svg>
        </a>
      </div>

    <?php endif; ?>

  </div>
</div>

<?php wp_reset_postdata(); ?>
<?php get_footer(); ?>