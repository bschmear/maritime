<?php
/**
 * Careers CPT archive is disabled — landing is the Careers page template.
 */
wp_safe_redirect(ibof_get_careers_page_url(), 301);
exit;
