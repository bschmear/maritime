<?php
/**
 * Template Name: Trade Show Schedule
 */
get_header();
while (have_posts()) : the_post();
?>

<!-- ===== PAGE HERO ===== -->
<div class="tss-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden"
  <?php if (has_post_thumbnail()) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>

  <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Events</span>
    </div>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== PAGE INTRO ===== -->
<?php $tss_content = get_the_content(); if ($tss_content) : ?>
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14 text-center">
    <div class="max-w-3xl mx-auto text-gray-600 text-lg md:text-xl lg:text-2xl leading-relaxed">
      <?php the_content(); ?>
    </div>
  </div>
</div>
<?php endif; ?>

<?php endwhile; ?>


<!-- ===== EVENTS LIST ===== -->
<div class="bg-white py-20 border-t border-gray-100">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <div class="flex items-center gap-3 mb-12">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <h2 class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Upcoming Shows</h2>
    </div>

    <?php
    $tss_events = new WP_Query(array(
      'post_type'      => 'schedule',
      'posts_per_page' => -1,
      'orderby'        => 'meta_value',
      'order'          => 'ASC',
      'meta_query'     => array(array(
        'key'     => 'event_end_date',
        'value'   => date('Y-m-d'),
        'compare' => '>='
      ))
    ));

    // Collect all event dates for calendar dots
    $tss_all_dates = array();
    if ($tss_events->have_posts()) {
      foreach ($tss_events->posts as $tss_p) {
        $tss_s = get_post_meta($tss_p->ID, 'event_start_date', true);
        $tss_e = get_post_meta($tss_p->ID, 'event_end_date',   true);
        if ($tss_s && $tss_e) {
          $tss_cur = strtotime($tss_s);
          $tss_end = strtotime($tss_e);
          while ($tss_cur <= $tss_end) {
            $tss_all_dates[] = date('Y-m-d', $tss_cur);
            $tss_cur = strtotime('+1 day', $tss_cur);
          }
        }
      }
      $tss_all_dates = array_unique($tss_all_dates);

      // Get next show for countdown
      $tss_next_post   = $tss_events->posts[0];
      $tss_next_start  = get_post_meta($tss_next_post->ID, 'event_start_date', true);
      $tss_next_title  = $tss_next_post->post_title;
      $tss_next_loc    = get_post_meta($tss_next_post->ID, 'event_location', true);
    }
    ?>

    <?php if ($tss_events->have_posts()) : ?>

    <div class="grid grid-cols-1 xl:grid-cols-12 gap-10 items-start">

      <!-- ===== LEFT: Events ===== -->
      <div class="xl:col-span-8 flex flex-col gap-8 order-2 xl:order-1">
        <?php while ($tss_events->have_posts()) : $tss_events->the_post();

          $tss_start = $post->event_start_date;
          $tss_end   = $post->event_end_date;
          $tss_month = date("M", strtotime($tss_start));
          $tss_day   = date("j", strtotime($tss_start));
          $tss_suf   = date("S", strtotime($tss_start));

          if ($tss_start == $tss_end) {
            $tss_date_str = $tss_month.' '.$tss_day.'<sup>'.$tss_suf.'</sup> '.date("Y", strtotime($tss_start));
          } else {
            $tss_date_str = $tss_month.' '.$tss_day.'<sup>'.$tss_suf.'</sup>';
            if (date("Y", strtotime($tss_start)) != date("Y", strtotime($tss_end)))
              $tss_date_str .= ' '.date("Y", strtotime($tss_start));
            $tss_date_str .= ' &ndash; ';
            if (date("M", strtotime($tss_start)) != date("M", strtotime($tss_end)))
              $tss_date_str .= date("M", strtotime($tss_end)).' ';
            $tss_date_str .= date("j", strtotime($tss_end)).'<sup>'.date("S", strtotime($tss_end)).'</sup>';
            $tss_date_str .= ' '.date("Y", strtotime($tss_end));
          }
        ?>

        <div class="tss-event group relative bg-white rounded-md shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100 hover:border-[#ff9101]">

          <?php if (has_post_thumbnail()) : ?>
          <div class="relative overflow-hidden" style="padding-top: 35%;">
            <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'large')); ?>"
              alt="<?php the_title_attribute(); ?>"
              class="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>

            <div class="absolute bottom-0 left-0 bg-[#ff9101] px-6 py-4">
              <span class="text-white font-black text-xl md:text-2xl leading-none"><?php echo $tss_date_str; ?></span>
            </div>

            <?php if ($post->event_caption) : ?>
              <div class="absolute top-4 right-4 bg-black/50 backdrop-blur-sm text-white text-xs font-bold uppercase tracking-widest px-3 py-1.5">
                <?php echo esc_html($post->event_caption); ?>
              </div>
            <?php endif; ?>

            <?php if ($post->event_location || $post->event_booth) : ?>
            <div class="absolute top-4 left-4 flex flex-wrap gap-2">
              <?php if ($post->event_location) : ?>
                <span class="bg-white/15 backdrop-blur-sm border border-white/30 text-white text-xs font-bold uppercase tracking-widest px-3 py-1.5">
                  <?php echo esc_html($post->event_location); ?>
                </span>
              <?php endif; ?>
              <?php if ($post->event_booth) : ?>
                <span class="bg-white/15 backdrop-blur-sm border border-white/30 text-white text-xs font-bold uppercase tracking-widest px-3 py-1.5">
                  Booth <?php echo esc_html($post->event_booth); ?>
                </span>
              <?php endif; ?>
            </div>
            <?php endif; ?>
          </div>

          <?php else : ?>
          <div class="bg-[#111111] px-8 py-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div class="flex flex-wrap gap-2">
              <?php if ($post->event_location) : ?>
                <span class="bg-white/10 text-white text-xs font-bold uppercase tracking-widest px-3 py-1.5">
                  <?php echo esc_html($post->event_location); ?>
                </span>
              <?php endif; ?>
              <?php if ($post->event_booth) : ?>
                <span class="bg-white/10 text-white/60 text-xs font-bold uppercase tracking-widest px-3 py-1.5">
                  Booth <?php echo esc_html($post->event_booth); ?>
                </span>
              <?php endif; ?>
            </div>
            <div class="bg-[#ff9101] px-5 py-3 flex-shrink-0">
              <span class="text-white font-black text-lg md:text-xl leading-none"><?php echo $tss_date_str; ?></span>
            </div>
          </div>
          <?php endif; ?>

          <div class="px-8 py-7 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-6">
            <div class="flex-1 min-w-0">
              <?php the_title('<h2 class="text-gray-900 font-black text-xl md:text-2xl lg:text-3xl leading-tight mb-3">', '</h2>'); ?>
              <?php $tss_body = get_the_content(); if ($tss_body) : ?>
              <div class="text-gray-500 text-base md:text-lg leading-relaxed"><?php the_content(); ?></div>
              <?php endif; ?>
            </div>
            <?php if ($post->event_url || $post->event_directions) : ?>
            <div class="flex flex-col gap-3 flex-shrink-0 sm:min-w-[180px]">
              <?php if ($post->event_directions) : ?>
                <a href="https://maps.apple.com/?saddr=My+Location&daddr=<?php echo urlencode($post->event_directions); ?>"
                  target="_blank" rel="noopener"
                  class="w-full text-center inline-flex items-center justify-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold text-xs uppercase tracking-widest px-5 py-3 transition-all duration-150">
                  <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                  </svg>
                  Get Directions
                </a>
              <?php endif; ?>
              <?php if ($post->event_url) : ?>
                <a href="<?php echo esc_url($post->event_url); ?>"
                  target="_blank" rel="noopener"
                  class="w-full text-center inline-flex items-center justify-center gap-2 border-2 border-gray-200 hover:border-[#ff9101] text-gray-500 hover:text-[#ff9101] font-bold text-xs uppercase tracking-widest px-5 py-3 transition-all duration-150">
                  <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                  </svg>
                  Event Website
                </a>
              <?php endif; ?>
            </div>
            <?php endif; ?>
          </div>

          <div class="h-1 bg-gray-100 group-hover:bg-[#ff9101] transition-colors duration-300"></div>
        </div>

        <?php endwhile; wp_reset_postdata(); ?>
      </div>


      <!-- ===== RIGHT: Sidebar ===== -->
      <aside class="xl:col-span-4 flex flex-col gap-6 order-0 xl:order-2">

        <!-- Countdown -->
        <?php if (!empty($tss_next_start)) : ?>
        <div class="bg-[#111111] rounded-md overflow-hidden shadow-sm">
          <div class="bg-[#ff9101] px-6 py-4 flex items-center gap-2">
            <svg class="w-4 h-4 text-white flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Next Show Countdown</h3>
          </div>
          <div class="p-6">
            <p class="text-white font-black text-lg leading-tight mb-1"><?php echo esc_html($tss_next_title); ?></p>
            <?php if ($tss_next_loc) : ?>
              <p class="text-white/50 text-xs font-bold uppercase tracking-widest mb-6"><?php echo esc_html($tss_next_loc); ?></p>
            <?php endif; ?>
            <div class="grid grid-cols-4 gap-2" id="tss-countdown">
              <?php foreach (['days' => 'Days', 'hours' => 'Hrs', 'minutes' => 'Min', 'seconds' => 'Sec'] as $tss_unit => $tss_label) : ?>
              <div class="bg-white/5 rounded-sm flex flex-col items-center justify-center py-4 px-2">
                <span id="tss-<?php echo $tss_unit; ?>" class="text-white font-black leading-none mb-1" style="font-size: clamp(1.5rem, 3vw, 2.25rem);">--</span>
                <span class="text-white/40 text-[10px] font-bold uppercase tracking-widest"><?php echo $tss_label; ?></span>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
        <?php endif; ?>


        <!-- Mini Calendar -->
        <div class="bg-white rounded-md overflow-hidden shadow-sm border border-gray-100">
          <div class="bg-[#111111] px-6 py-4 flex items-center justify-between">
            <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Event Calendar</h3>
            <div class="flex items-center gap-3">
              <button id="tss-cal-prev" class="text-white/40 hover:text-[#ff9101] transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
                </svg>
              </button>
              <span id="tss-cal-label" class="text-white text-xs font-bold uppercase tracking-widest w-24 text-center"></span>
              <button id="tss-cal-next" class="text-white/40 hover:text-[#ff9101] transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                </svg>
              </button>
            </div>
          </div>
          <div class="p-5">
            <!-- Day headers -->
            <div class="grid grid-cols-7 mb-2">
              <?php foreach (['Su','Mo','Tu','We','Th','Fr','Sa'] as $tss_d) : ?>
                <div class="text-center text-[10px] font-bold uppercase tracking-widest text-gray-300 py-1"><?php echo $tss_d; ?></div>
              <?php endforeach; ?>
            </div>
            <!-- Calendar grid -->
            <div id="tss-cal-grid" class="grid grid-cols-7 gap-y-1"></div>

            <!-- Legend -->
            <div class="flex items-center gap-2 mt-4 pt-4 border-t border-gray-100">
              <span class="w-3 h-3 rounded-full bg-[#ff9101] flex-shrink-0"></span>
              <span class="text-gray-400 text-xs font-semibold">Event day</span>
            </div>
          </div>
        </div>

        <!-- Quick list -->
        <div class="bg-white rounded-md overflow-hidden shadow-sm border border-gray-100">
          <div class="bg-[#111111] px-6 py-4">
            <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">All Upcoming Shows</h3>
          </div>
          <div class="divide-y divide-gray-100">
            <?php
            $tss_quick = new WP_Query(array(
              'post_type'      => 'schedule',
              'posts_per_page' => -1,
              'orderby'        => 'meta_value',
              'order'          => 'ASC',
              'meta_query'     => array(array('key' => 'event_end_date', 'value' => date('Y-m-d'), 'compare' => '>='))
            ));
            if ($tss_quick->have_posts()) :
              while ($tss_quick->have_posts()) : $tss_quick->the_post();
                $tss_qs = $post->event_start_date;
                $tss_ql = $post->event_location;
            ?>
            <div class="px-5 py-4 flex items-center gap-4 hover:bg-gray-50 transition-colors">
              <div class="flex-shrink-0 bg-[#ff9101]/10 rounded-sm px-3 py-2 text-center min-w-[52px]">
                <p class="text-[#ff9101] font-black text-lg leading-none"><?php echo date('j', strtotime($tss_qs)); ?></p>
                <p class="text-[#ff9101] text-[10px] font-bold uppercase tracking-widest"><?php echo date('M', strtotime($tss_qs)); ?></p>
              </div>
              <div class="min-w-0">
                <p class="text-gray-900 font-black text-sm leading-tight truncate"><?php the_title(); ?></p>
                <?php if ($tss_ql) : ?>
                  <p class="text-gray-400 text-xs font-semibold truncate"><?php echo esc_html($tss_ql); ?></p>
                <?php endif; ?>
              </div>
            </div>
            <?php endwhile; wp_reset_postdata(); endif; ?>
          </div>
        </div>

      </aside>

    </div>

    <?php else : ?>
      <div class="flex flex-col items-center justify-center py-24 text-center">
        <svg class="w-16 h-16 text-gray-200 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
        </svg>
        <h3 class="text-gray-900 font-black text-2xl mb-3">No Upcoming Trade Shows</h3>
        <p class="text-gray-400 text-lg max-w-sm">Check back soon for our updated schedule.</p>
      </div>
    <?php endif; ?>

  </div>
</div>

<!-- Event popup overlay -->
<div id="tss-popup-overlay"
  class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-6 opacity-0 pointer-events-none transition-opacity duration-200">
  <div id="tss-popup"
    class="bg-white rounded-md shadow-2xl w-full max-w-lg overflow-hidden transform scale-95 transition-transform duration-200">

    <!-- Popup header -->
    <div class="bg-[#111111] px-6 py-4 flex items-center justify-between">
      <div class="flex items-center gap-2">
        <span class="block w-6 h-[2px] bg-[#ff9101]"></span>
        <span id="tss-popup-date" class="text-[#ff9101] text-xs font-bold uppercase tracking-[0.25em]"></span>
      </div>
      <button id="tss-popup-close"
        class="text-white/40 hover:text-white transition-colors duration-150">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
        </svg>
      </button>
    </div>

    <!-- Popup image -->
    <div id="tss-popup-img-wrap" class="relative overflow-hidden bg-gray-100 hidden" style="padding-top: 40%;">
      <img id="tss-popup-img" src="" alt=""
        class="absolute inset-0 w-full h-full object-cover">
    </div>

    <!-- Popup body -->
    <div class="p-7">
      <h3 id="tss-popup-title" class="text-gray-900 font-black text-2xl leading-tight mb-2"></h3>
      <div id="tss-popup-location" class="hidden mb-4">
        <span class="bg-[#ff9101]/10 text-[#ff9101] text-xs font-bold uppercase tracking-widest px-3 py-1"></span>
      </div>
      <div id="tss-popup-booth" class="hidden mb-4">
        <span class="bg-gray-100 text-gray-500 text-xs font-bold uppercase tracking-widest px-3 py-1"></span>
      </div>
      <p id="tss-popup-body" class="text-gray-500 text-base leading-relaxed mb-6 hidden"></p>

      <div id="tss-popup-actions" class="flex flex-col sm:flex-row gap-3"></div>
    </div>

  </div>
</div>

<script>
(function () {

  // ===== EVENT DATA from PHP =====
  const tssEventDates = <?php echo json_encode(array_values($tss_all_dates)); ?>;

  // Build a map of date -> array of events
  const tssEventMap = {};
  <?php
  $tss_map_query = new WP_Query(array(
    'post_type'      => 'schedule',
    'posts_per_page' => -1,
    'orderby'        => 'meta_value',
    'order'          => 'ASC',
    'meta_query'     => array(array('key' => 'event_end_date', 'value' => date('Y-m-d'), 'compare' => '>='))
  ));
  if ($tss_map_query->have_posts()) :
    while ($tss_map_query->have_posts()) : $tss_map_query->the_post();
      $tss_map_s    = $post->event_start_date;
      $tss_map_e    = $post->event_end_date;
      $tss_map_cur  = strtotime($tss_map_s);
      $tss_map_end  = strtotime($tss_map_e);
      $tss_map_data = array(
        'title'      => get_the_title(),
        'location'   => $post->event_location   ?? '',
        'booth'      => $post->event_booth       ?? '',
        'body'       => strip_tags(get_the_content()),
        'url'        => $post->event_url         ?? '',
        'directions' => $post->event_directions  ?? '',
        'image'      => has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'large') : '',
        'start'      => $tss_map_s,
        'end'        => $tss_map_e,
      );
      while ($tss_map_cur <= $tss_map_end) {
        $tss_map_date = date('Y-m-d', $tss_map_cur);
        echo 'tssEventMap["'.$tss_map_date.'"] = tssEventMap["'.$tss_map_date.'"] || [];'."\n";
        echo 'tssEventMap["'.$tss_map_date.'"].push('.json_encode($tss_map_data).');'."\n";
        $tss_map_cur = strtotime('+1 day', $tss_map_cur);
      }
    endwhile;
    wp_reset_postdata();
  endif;
  ?>

  const tssMonthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  let tssCalYear  = new Date().getFullYear();
  let tssCalMonth = new Date().getMonth();


  // ===== POPUP =====
  const tssOverlay = document.getElementById('tss-popup-overlay');
  const tssPopup   = document.getElementById('tss-popup');

    // Decode HTML entities helper
    function tssDecode(str) {
      const txt = document.createElement('textarea');
      txt.innerHTML = str;
      return txt.value;
    }

  function tssShowPopup(dateStr) {
    const events = tssEventMap[dateStr];
    if (!events || !events.length) return;

    // Use first event on that date (multi-event dates could be extended later)
    const ev = events[0];

    const dateObj  = new Date(dateStr + 'T00:00:00');
    const dateLabel = tssMonthNames[dateObj.getMonth()] + ' ' + dateObj.getDate() + ', ' + dateObj.getFullYear();

    // Build date range label
    let rangeLabel = dateLabel;
    if (ev.start !== ev.end) {
      const endObj = new Date(ev.end + 'T00:00:00');
      rangeLabel = tssMonthNames[new Date(ev.start+'T00:00:00').getMonth()] + ' ' +
                   new Date(ev.start+'T00:00:00').getDate() + ' &ndash; ' +
                   tssMonthNames[endObj.getMonth()] + ' ' + endObj.getDate() + ', ' + endObj.getFullYear();
    }

    document.getElementById('tss-popup-date').innerHTML  = rangeLabel;
    document.getElementById('tss-popup-title').textContent = tssDecode(ev.title);

    // Image
    const imgWrap = document.getElementById('tss-popup-img-wrap');
    const img     = document.getElementById('tss-popup-img');
    if (ev.image) {
      img.src = ev.image;
      img.alt = ev.title;
      imgWrap.classList.remove('hidden');
    } else {
      imgWrap.classList.add('hidden');
    }

    // Location
    const locWrap = document.getElementById('tss-popup-location');
    if (ev.location) {
      locWrap.querySelector('span').textContent = ev.location;
      locWrap.classList.remove('hidden');
    } else {
      locWrap.classList.add('hidden');
    }

    // Booth
    const boothWrap = document.getElementById('tss-popup-booth');
    if (ev.booth) {
      boothWrap.querySelector('span').textContent = 'Booth ' + ev.booth;
      boothWrap.classList.remove('hidden');
    } else {
      boothWrap.classList.add('hidden');
    }

    // Body
    const bodyEl = document.getElementById('tss-popup-body');
    if (ev.body) {
      bodyEl.textContent = tssDecode(ev.body);
      bodyEl.classList.remove('hidden');
    } else {
      bodyEl.classList.add('hidden');
    }

    // Actions
    const actions = document.getElementById('tss-popup-actions');
    actions.innerHTML = '';
    if (ev.directions) {
      actions.innerHTML += '<a href="https://maps.apple.com/?saddr=My+Location&daddr=' + encodeURIComponent(ev.directions) + '" target="_blank" rel="noopener" class="flex-1 text-center inline-flex items-center justify-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold text-xs uppercase tracking-widest px-5 py-3 transition-all duration-150"><svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>Get Directions</a>';
    }
    if (ev.url) {
      actions.innerHTML += '<a href="' + ev.url + '" target="_blank" rel="noopener" class="flex-1 text-center inline-flex items-center justify-center gap-2 border-2 border-gray-200 hover:border-[#ff9101] text-gray-500 hover:text-[#ff9101] font-bold text-xs uppercase tracking-widest px-5 py-3 transition-all duration-150"><svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>Event Website</a>';
    }

    // Show overlay
    tssOverlay.classList.remove('opacity-0', 'pointer-events-none');
    tssPopup.classList.remove('scale-95');
    tssPopup.classList.add('scale-100');
    document.body.style.overflow = 'hidden';
  }

  function tssHidePopup() {
    tssOverlay.classList.add('opacity-0', 'pointer-events-none');
    tssPopup.classList.add('scale-95');
    tssPopup.classList.remove('scale-100');
    document.body.style.overflow = '';
  }

  document.getElementById('tss-popup-close').addEventListener('click', tssHidePopup);
  tssOverlay.addEventListener('click', function (e) {
    if (e.target === tssOverlay) tssHidePopup();
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') tssHidePopup();
  });


  // ===== CALENDAR =====
  function tssRenderCalendar() {
    const grid  = document.getElementById('tss-cal-grid');
    const label = document.getElementById('tss-cal-label');
    if (!grid || !label) return;

    label.textContent = tssMonthNames[tssCalMonth].slice(0, 3) + ' ' + tssCalYear;

    const firstDay    = new Date(tssCalYear, tssCalMonth, 1).getDay();
    const daysInMonth = new Date(tssCalYear, tssCalMonth + 1, 0).getDate();
    const todayStr    = new Date().toISOString().split('T')[0];

    let html = '';
    for (let i = 0; i < firstDay; i++) html += '<div></div>';

    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = tssCalYear + '-' +
                      String(tssCalMonth + 1).padStart(2, '0') + '-' +
                      String(d).padStart(2, '0');
      const isEvent = !!tssEventMap[dateStr];
      const isToday = dateStr === todayStr;
      const isPast  = dateStr < todayStr;

      let cls = 'relative flex flex-col items-center justify-center text-xs font-bold rounded-sm py-1.5 transition-all duration-150 ';

      if (isEvent && isToday)  cls += 'bg-[#ff9101] text-white cursor-pointer';
      else if (isEvent)        cls += 'bg-[#ff9101]/15 text-[#ff9101] cursor-pointer hover:bg-[#ff9101]/30';
      else if (isToday)        cls += 'ring-2 ring-[#ff9101] text-gray-900';
      else if (isPast)         cls += 'text-gray-200';
      else                     cls += 'text-gray-500';

      const clickAttr = isEvent ? ' data-date="' + dateStr + '" onclick="tssCalClick(this)"' : '';

      html += '<div class="' + cls + '"' + clickAttr + '>' + d;
      if (isEvent) {
        html += '<span class="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full ' +
                (isToday ? 'bg-white' : 'bg-[#ff9101]') + '"></span>';
      }
      html += '</div>';
    }

    grid.innerHTML = html;
  }

  // Global so inline onclick can reach it
  window.tssCalClick = function (el) {
    tssShowPopup(el.dataset.date);
  };

  document.getElementById('tss-cal-prev').addEventListener('click', function () {
    tssCalMonth--;
    if (tssCalMonth < 0) { tssCalMonth = 11; tssCalYear--; }
    tssRenderCalendar();
  });

  document.getElementById('tss-cal-next').addEventListener('click', function () {
    tssCalMonth++;
    if (tssCalMonth > 11) { tssCalMonth = 0; tssCalYear++; }
    tssRenderCalendar();
  });

  tssRenderCalendar();


  // ===== COUNTDOWN =====
  <?php if (!empty($tss_next_start)) : ?>
  const tssTarget = new Date('<?php echo esc_js($tss_next_start); ?>T00:00:00').getTime();
  function tssUpdateCountdown() {
    const diff = tssTarget - Date.now();
    if (diff <= 0) return;
    const vals = {
      days:    Math.floor(diff / 86400000),
      hours:   Math.floor((diff % 86400000) / 3600000),
      minutes: Math.floor((diff % 3600000)  / 60000),
      seconds: Math.floor((diff % 60000)    / 1000)
    };
    Object.keys(vals).forEach(function (u) {
      const el = document.getElementById('tss-' + u);
      if (el) el.textContent = String(vals[u]).padStart(2, '0');
    });
  }
  tssUpdateCountdown();
  setInterval(tssUpdateCountdown, 1000);
  <?php endif; ?>

})();
</script>

<!-- ===== CTA BAND ===== -->
<div class="bg-[#032972] py-14 relative overflow-hidden">
  <div class="absolute inset-0 opacity-[0.08]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <div class="relative z-10 max-w-screen-2xl mx-auto px-6 md:px-14 flex flex-col sm:flex-row items-center justify-between gap-6">
    <p class="text-white font-black text-2xl md:text-3xl">Have any questions?</p>
    <a href="<?php echo esc_url(home_url('/contact/')); ?>"
      class="flex-shrink-0 inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-black px-8 py-4 text-sm uppercase tracking-[0.2em] transition-all duration-200">
      Contact Us
      <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
      </svg>
    </a>
  </div>
</div>

<?php get_footer(); ?>
