<?php
/**
 * Template Name: My Boat Quotes
 */

header('Expires: Thu, 1 Jan 1970 00:00:00 GMT');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');

get_header();


$mbq_noboats = '<div class="mbq-noboats flex flex-col items-center justify-center py-12 text-center" >
  <svg class="w-12 h-12 text-gray-200 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
      d="M3 3h2l.4 2M7 13h10l4-4H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>
  </svg>
  <p class="text-gray-400 font-semibold text-lg">You need to select at least one boat to get a quote.</p>
  <a href="' . home_url('/boats/') . '" class="mt-4 inline-flex items-center gap-2 text-[#ff9101] font-bold text-sm uppercase tracking-widest hover:underline">
    Browse Boats
    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
    </svg>
  </a>
</div>';
?>

<!-- ===== PAGE HERO ===== -->
<div class="mbq-hero relative min-h-[320px] flex items-end bg-[#111111] overflow-hidden">
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
  <div class="absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14 pt-24">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Get Pricing</span>
    </div>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== FORM ===== -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <form action="<?php echo get_template_directory_uri(); ?>/form-my-boat-quotes.php"
      method="POST" id="form-mbq" novalidate>

      <!-- Honeypot -->
      <input type="text" name="username" tabindex="-1" aria-hidden="true" autocomplete="new-password"
        class="hidden">

      <!-- Debug field (remove after testing) -->
      <input type="hidden" name="debug" value="1">

      <div class="grid grid-cols-1 xl:grid-cols-2 gap-10 items-start">

        <!-- ===== LEFT: Selected boats ===== -->
<div <?php if (!isset($_COOKIE['IBOFmbq'])) { echo 'class="sticky top-[150px]" style="top: 150px;"'; } ?>>
  <div class="flex items-center gap-3 mb-6">
    <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
    <h2 class="text-gray-900 font-black text-xl uppercase tracking-widest">Your Selected Boats</h2>
  </div>

  <?php
  $mbq_content = '';

  if (isset($_COOKIE['IBOFmbq'])) {
    $mbq_query = new WP_Query(array(
      'post_type'      => 'boats',
      'posts_per_page' => -1,
      'post__in'       => explode(',', $_COOKIE['IBOFmbq']),
      'orderby'        => 'title'
    ));

    if ($mbq_query->have_posts()) :
      while ($mbq_query->have_posts()) : $mbq_query->the_post();

        $mbq_img  = (!empty($post->boat_images['image'][0])) ? $post->boat_images['image'][0] : '';
        $mbq_make = '';
        if (has_term('', 'make')) {
          $mbq_terms = get_the_terms($post->ID, 'make');
          if (!empty($mbq_terms)) $mbq_make = $mbq_terms[0]->name;
        }

        $mbq_content .= '
        <div id="my_boats_'.$post->ID.'" class="mbq-boat-item group bg-white rounded-md shadow-sm overflow-hidden mb-4 border border-gray-100 hover:border-[#ff9101] hover:shadow-lg transition-all duration-300">

          <!-- Full width image top -->
          <div class="relative overflow-hidden bg-gray-100" style="padding-top: 52%;">';

            if ($mbq_img) {
              $mbq_content .= '
              <img src="'.esc_url($mbq_img).'"
                alt="'.esc_attr(get_the_title()).'"
                class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">';
            } else {
              $mbq_content .= '
              <div class="absolute inset-0 flex items-center justify-center bg-gray-50">
                <svg class="w-14 h-14 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
              </div>';
            }

            // Type badge over image
            $mbq_type_terms = get_the_terms($post->ID, 'type');
            if (!empty($mbq_type_terms) && !is_wp_error($mbq_type_terms)) {
              $mbq_content .= '<span class="absolute top-3 left-3 bg-[#ff9101] text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">'.esc_html($mbq_type_terms[0]->name).'</span>';
            }

            // Sold badge
            if ($post->boat_sold) {
              $mbq_content .= '<span class="absolute top-3 right-3 bg-red-600 text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">SOLD</span>';
            }

          $mbq_content .= '</div>

          <!-- Card body -->
          <div class="p-6">

            <!-- Make + title -->
            <div class="mb-5">';
              if ($mbq_make) {
                $mbq_content .= '<p class="text-[#ff9101] text-xs font-bold uppercase tracking-widest mb-1">'.esc_html($mbq_make).'</p>';
              }
              $mbq_content .= '<h3 class="text-gray-900 font-black text-xl leading-tight">'.get_the_title().'</h3>';
            $mbq_content .= '</div>

            <!-- Specs grid -->
            <div class="grid grid-cols-2 gap-px bg-gray-100 rounded-sm overflow-hidden mb-5">';

              $mbq_specs = array(
                array('label' => 'Length',   'val' => $post->boat_length     ? $post->boat_length."'"       : null),
                array('label' => 'Weight',   'val' => $post->boat_weight     ? $post->boat_weight.' lbs'    : null),
                array('label' => 'Capacity', 'val' => $post->boat_passengers ? $post->boat_passengers.' pax': null),
                array('label' => 'Max HP',   'val' => $post->boat_hp         ? $post->boat_hp.' HP'         : null),
              );

              $mbq_has_specs = false;
              foreach ($mbq_specs as $mbq_s) {
                if (!$mbq_s['val']) continue;
                $mbq_has_specs = true;
                $mbq_content .= '
                <div class="bg-white px-4 py-3">
                  <span class="text-gray-400 text-[10px] font-bold uppercase tracking-widest block mb-0.5">'.$mbq_s['label'].'</span>
                  <strong class="text-gray-900 font-black text-base">'.$mbq_s['val'].'</strong>
                </div>';
              }

              if (!$mbq_has_specs) $mbq_content .= '<div class="col-span-2 bg-white px-4 py-3 text-gray-300 text-sm">No specs listed</div>';

            $mbq_content .= '</div>

            <!-- Remove -->
            <button data-postid="'.$post->ID.'"
              class="remove w-full flex items-center justify-center gap-2 border-2 border-gray-200 hover:border-red-300 text-gray-400 hover:text-red-400 font-bold text-xs uppercase tracking-widest py-2.5 transition-all duration-150">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
              </svg>
              Remove Boat
            </button>

          </div>

          <input type="hidden" name="boatlist[]" value="'.get_the_title().'">
          <input type="hidden" name="boat_ids[]" value="'.get_the_ID().'">
          <input type="hidden" name="boat_make[]" value="'.$mbq_make.'">
          <input type="hidden" name="boat_length[]" value="'.$post->boat_length.'">
          <input type="hidden" name="boat_weight[]" value="'.$post->boat_weight.'">
          <input type="hidden" name="boat_capacity[]" value="'.$post->boat_passengers.'">
          <input type="hidden" name="boat_hp[]" value="'.$post->boat_hp.'">
        </div>';

      endwhile;
    endif;

    wp_reset_postdata();
  } else {
    $mbq_content = $mbq_noboats;
  }
  ?>

  <div id="myboats" ><?php echo $mbq_content; ?></div>
</div>


        <!-- ===== RIGHT: Quote form ===== -->
        <div class="bg-white rounded-md shadow-sm border border-gray-100 overflow-hidden">

          <!-- Form header -->
          <div class="bg-[#111111] px-8 py-5 flex items-center gap-3">
            <svg class="w-5 h-5 text-[#ff9101] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
            <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Request a Quote</h3>
          </div>

          <div class="px-8 py-8 flex flex-col gap-6">

            <!-- WP content -->
            <?php $mbq_pg_content = get_the_content(); if ($mbq_pg_content) : ?>
            <div class="text-gray-500 text-base leading-relaxed border-b border-gray-100 pb-6">
              <?php the_content(); ?>
            </div>
            <?php endif; ?>

            <?php
            $mbq_input   = "w-full border-0 border-b-2 border-gray-200 focus:border-[#ff9101] bg-transparent px-0 py-2.5 text-base text-gray-800 font-semibold focus:outline-none focus:ring-0 transition-colors duration-150 placeholder:text-gray-300";
            $mbq_label   = "block text-xs font-bold uppercase tracking-[0.2em] text-gray-400 mb-1";
            $mbq_chkwrap = "flex items-center gap-3 cursor-pointer";
            $mbq_chk     = "w-4 h-4 accent-[#ff9101] cursor-pointer flex-shrink-0";
            $mbq_chklbl  = "text-gray-600 font-semibold text-base";
            ?>

            <!-- Name / Email / Phone -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label class="<?php echo $mbq_label; ?>">Name <span class="text-[#ff9101]">*</span></label>
                <input type="text" name="name" placeholder="Your full name" required class="<?php echo $mbq_input; ?>">
              </div>
              <div>
                <label class="<?php echo $mbq_label; ?>">Email <span class="text-[#ff9101]">*</span></label>
                <input type="email" name="email" placeholder="your@email.com" required class="<?php echo $mbq_input; ?>">
              </div>
              <div class="sm:col-span-2">
                <label class="<?php echo $mbq_label; ?>">Phone <span class="text-[#ff9101]">*</span></label>
                <input type="tel" name="phone" placeholder="(000) 000-0000" required class="<?php echo $mbq_input; ?>">
              </div>
            </div>

            <!-- Preferred location -->
            <div>
              <label class="<?php echo $mbq_label; ?>">Preferred Location <span class="text-[#ff9101]">*</span></label>
              <div class="mt-3 flex flex-col gap-3">
                <?php
                $mbq_locs = get_posts(array(
                  'post_type'      => 'page',
                  'meta_key'       => '_wp_page_template',
                  'meta_value'     => 'template-location.php',
                  'orderby'        => 'post_title',
                  'order'          => 'ASC',
                  'posts_per_page' => -1
                ));
                foreach ($mbq_locs as $mbq_loc) :
                ?>
                  <label class="<?php echo $mbq_chkwrap; ?>">
                    <input type="checkbox" name="location[]" value="<?php echo esc_attr($mbq_loc->post_title); ?>"
                      id="loc<?php echo $mbq_loc->ID; ?>" class="<?php echo $mbq_chk; ?>">
                    <span class="<?php echo $mbq_chklbl; ?>"><?php echo esc_html($mbq_loc->post_title); ?></span>
                  </label>
                <?php endforeach; ?>
              </div>
            </div>

            <!-- Also interested in -->
            <div>
              <label class="<?php echo $mbq_label; ?>">I Am Also Interested In</label>
              <div class="mt-3 grid grid-cols-2 gap-3">
                <?php
                $mbq_interests = array(
                  'c1' => 'Financing',
                  'c2' => 'Boat Warranty',
                  'c3' => 'Trade In',
                  'c4' => 'Delivery',
                );
                foreach ($mbq_interests as $mbq_id => $mbq_val) :
                ?>
                  <label class="<?php echo $mbq_chkwrap; ?>">
                    <input type="checkbox" name="interest[]" value="<?php echo $mbq_val; ?>"
                      id="<?php echo $mbq_id; ?>" class="<?php echo $mbq_chk; ?>">
                    <span class="<?php echo $mbq_chklbl; ?>"><?php echo $mbq_val; ?></span>
                  </label>
                <?php endforeach; ?>
              </div>
            </div>

<!-- Sea trial -->
<div>
  <label class="<?php echo $mbq_chkwrap; ?>">
    <input type="checkbox" name="seatrial" value="I would like to schedule a sea trial"
      id="seatrial" class="<?php echo $mbq_chk; ?>">
    <span class="<?php echo $mbq_chklbl; ?>">I would like to schedule a sea trial</span>
  </label>
</div>

<!-- Timeline + Budget (side by side) -->
<div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
  <div>
    <label class="<?php echo $mbq_label; ?>">Purchase Timeline <span class="text-[#ff9101]">*</span></label>
    <select name="timeline" required
      class="<?php echo $mbq_input; ?> appearance-none cursor-pointer">
      <option value="" disabled selected>Select timeline...</option>
      <option value="This Week">This Week</option>
      <option value="1–2 Weeks">1–2 Weeks</option>
      <option value="2–4 Weeks">2–4 Weeks</option>
      <option value="1–3 Months">1–3 Months</option>
      <option value="3–6 Months">3–6 Months</option>
      <option value="6–12 Months">6–12 Months</option>
      <option value="12+ Months">12+ Months</option>
    </select>
  </div>
  <div>
    <label class="<?php echo $mbq_label; ?>">Budget Range <span class="text-[#ff9101]">*</span></label>
    <select name="budget" required
      class="<?php echo $mbq_input; ?> appearance-none cursor-pointer">
      <option value="" disabled selected>Select budget...</option>
      <option value="Under $5,000">Under $5,000</option>
      <option value="$5,000 – $10,000">$5,000 – $10,000</option>
      <option value="$10,000 – $20,000">$10,000 – $20,000</option>
      <option value="$20,000 – $35,000">$20,000 – $35,000</option>
      <option value="$35,000 – $50,000">$35,000 – $50,000</option>
      <option value="$50,000 – $75,000">$50,000 – $75,000</option>
      <option value="$75,000 – $100,000">$75,000 – $100,000</option>
      <option value="$100,000+">$100,000+</option>
    </select>
  </div>
</div>

<!-- Callback time -->
<div>
  <label class="<?php echo $mbq_label; ?>">Best Time For Callback</label>
  <select name="callback" class="<?php echo $mbq_input; ?> appearance-none cursor-pointer">
    <option value="" disabled>Select a time...</option>
    <?php
    $mbq_start = strtotime('8:00 AM');
    $mbq_end   = strtotime('6:00 PM');
    for ($mbq_t = $mbq_start; $mbq_t <= $mbq_end; $mbq_t += 1800) :
      $mbq_val = date('g:i A', $mbq_t);
    ?>
      <option value="<?php echo $mbq_val; ?>" <?php selected($mbq_val, '12:00 PM'); ?>>
        <?php echo $mbq_val; ?>
      </option>
    <?php endfor; ?>
  </select>
</div>

            <!-- Message -->
            <div>
              <label class="<?php echo $mbq_label; ?>">Questions / Notes</label>
              <textarea name="message" rows="4"
                class="w-full border-2 border-gray-200 focus:border-[#ff9101] bg-transparent px-4 py-3 text-base text-gray-800 font-semibold focus:outline-none focus:ring-0 transition-colors duration-150 resize-none mt-1 rounded-sm placeholder:text-gray-300"
                placeholder="Any questions or additional details..."></textarea>
            </div>

            <input type="hidden" name="id" value="<?php echo $post->ID; ?>">

            <!-- reCAPTCHA + Submit -->
            <div class="flex flex-col gap-4 pt-2 border-t border-gray-100">
              <div class="g-recaptcha" data-sitekey="<?php echo get_theme_mod('fg_recaptcha_site_key'); ?>"></div>
              <button type="submit" id="submit"
                class="w-full bg-[#ff9101] hover:bg-[#e07f00] disabled:opacity-40 disabled:cursor-not-allowed text-white font-black text-sm uppercase tracking-[0.2em] py-4 px-8 flex items-center justify-center gap-2 transition-all duration-200">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
                </svg>
                Submit Quote Request
              </button>
            </div>

          </div>
        </div>
        <!-- END right form -->

      </div>
    </form>

  </div>
</div>

<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<script>
(function () {
  const noboats = <?php echo json_encode($mbq_noboats); ?>;

  function getCookieValues() {
    const boats = document.cookie.match('(^|;)\\s*IBOFmbq\\s*=\\s*([^;]+)')?.pop() || '';
    return boats.split(',').sort();
  }

  // Disable submit if no cookie
  if (document.cookie.indexOf('IBOFmbq') === -1) {
    document.getElementById('submit').disabled = true;
  }

  // Remove boat
  document.querySelectorAll('.remove').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const boatsarr = getCookieValues();
      let remaining = boatsarr.filter(id => id !== btn.dataset.postid).join(',');

      document.getElementById('my_boats_' + btn.dataset.postid).remove();

      if (remaining) {
        document.cookie = 'IBOFmbq=' + remaining + '; SameSite=Lax; path=/';
      } else {
        document.cookie = 'IBOFmbq=; expires=Thu, 01 Jan 1970 00:00:00 UTC; SameSite=Lax; path=/;';
        document.getElementById('myboats').innerHTML = noboats;
        document.getElementById('submit').disabled = true;
      }
    });
  });

  // Form submit
  const form = document.getElementById('form-mbq');
  form.addEventListener('submit', function (e) {
    e.preventDefault();

    console.log('Form submission started');
    console.log('Form element:', form);
    console.log('Form action:', form.action);

    let valid = true;

    form.querySelectorAll('[required]').forEach(function (el) {
      if (!el.checkValidity()) {
        el.classList.add('border-red-400');
        valid = false;
        console.log('Field validation failed:', el.name);
      } else {
        el.classList.remove('border-red-400');
      }
    });

    const data = new FormData(form);
    if (!data.has('location[]')) {
      valid = false;
      console.log('Location validation failed - no location selected');
    }
    if (!data.has('boatlist[]')) {
      valid = false;
      document.getElementById('myboats').innerHTML = noboats;
      document.getElementById('submit').disabled = true;
      console.log('Boat validation failed - no boats selected');
    }

    // Ensure debug field is included
    if (!data.has('debug')) {
      data.append('debug', '1');
    }

    console.log('Form validation result:', valid);
    console.log('FormData contents:', Array.from(data.entries()));
    if (!valid) return;

    const btn = document.getElementById('submit');
    btn.disabled = true;
    btn.innerHTML = '<svg class="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path></svg> Sending...';

    console.log('Submitting form to:', form.action);
    console.log('About to make fetch call...');

    fetch(form.action, { method: 'POST', body: data })
      .then(function(response) {
        console.log('Fetch completed. Response status:', response.status);
        console.log('Response headers:', response.headers);
        if (!response.ok) {
          throw new Error('HTTP error! status: ' + response.status + ', url: ' + response.url);
        }
        return response.text();
      })
      .then(function (result) {
        console.log('Server response received:', result.substring(0, 200) + '...');
        console.log('Full server response:', result);
        document.getElementById('myboats').innerHTML =
          '<div class="flex flex-col items-center justify-center py-12 text-center">' +
          '<svg class="w-12 h-12 text-[#ff9101] mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>' +
          '<p class="text-gray-700 font-black text-xl mb-2">Quote Sent!</p>' +
          '<p class="text-gray-400 text-base">' + result + '</p>' +
          '</div>';

        form.reset();
        document.cookie = 'IBOFmbq=; expires=Thu, 01 Jan 1970 00:00:00 UTC; SameSite=Lax; path=/;';

        btn.innerHTML = '<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg> Submitted';
      })
      .catch(function(error) {
        console.error('Form submission error:', error);
        btn.disabled = false;
        btn.innerHTML = 'Error - Please Try Again';
        document.getElementById('myboats').innerHTML =
          '<div class="flex flex-col items-center justify-center py-12 text-center">' +
          '<svg class="w-12 h-12 text-red-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>' +
          '<p class="text-gray-700 font-black text-xl mb-2">Submission Failed</p>' +
          '<p class="text-gray-400 text-base">Please check the console for details and try again.</p>' +
          '</div>';
      });
  });
})();
</script>

<?php get_footer(); ?>
