<?php if (!empty($args['isCarousel'])) : ?>
<div class="rbc-wrap flex-shrink-0 w-72">
<?php endif; ?>

  <a href="<?php the_permalink(); ?>"
    class="rbc-card group bg-white rounded-md overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col">

    <!-- Image -->
    <div class="rbc-img relative overflow-hidden bg-gray-100" style="padding-top: 62%;">
      <?php if ($post->boat_images) : ?>
        <img src="<?php echo esc_url($post->boat_images['image'][0]); ?>"
          alt="<?php the_title_attribute(); ?>"
          class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
      <?php else : ?>
        <div class="absolute inset-0 flex items-center justify-center bg-gray-50">
          <svg class="w-10 h-10 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
              d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
          </svg>
        </div>
      <?php endif; ?>

      <!-- Type badge -->
      <?php
      $rbc_types = get_the_terms($post->ID, 'type');
      if (!empty($rbc_types) && !is_wp_error($rbc_types)) :
      ?>
        <span class="absolute top-3 left-3 bg-[#ff9101] text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">
          <?php echo esc_html($rbc_types[0]->name); ?>
        </span>
      <?php endif; ?>
    </div>

    <!-- Body -->
    <div class="rbc-body flex flex-col flex-1 p-5">

      <?php
      $rbc_make = has_term('', 'make') ? get_the_terms($post->ID, 'make') : array();
      if (!empty($rbc_make) && !is_wp_error($rbc_make)) :
      ?>
        <p class="text-[#ff9101] text-[11px] font-bold uppercase tracking-widest mb-1">
          <?php echo esc_html($rbc_make[0]->name); ?>
        </p>
      <?php endif; ?>

      <h3 class="text-gray-900 font-black text-lg leading-snug mb-3 group-hover:text-[#ff9101] transition-colors duration-150">
        <?php the_title(); ?>
      </h3>

      <p class="text-gray-500 text-sm leading-relaxed flex-1">
        <?php echo fg_excerpt(24, '...'); ?>
      </p>

      <div class="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between">
        <?php
        $rbc_len = get_post_meta($post->ID, 'boat_length', true);
        $rbc_hp  = get_post_meta($post->ID, 'boat_hp', true);
        ?>
        <div class="flex gap-4">
          <?php if ($rbc_len) : ?>
          <span class="flex items-center gap-1 text-xs text-gray-400 font-semibold">
            <svg class="w-3.5 h-3.5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"/>
            </svg>
            <?php echo esc_html($rbc_len); ?> ft
          </span>
          <?php endif; ?>
          <?php if ($rbc_hp) : ?>
          <span class="flex items-center gap-1 text-xs text-gray-400 font-semibold">
            <svg class="w-3.5 h-3.5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/>
            </svg>
            <?php echo esc_html($rbc_hp); ?> HP
          </span>
          <?php endif; ?>
        </div>
        <span class="text-[#ff9101] text-xs font-bold uppercase tracking-widest group-hover:gap-2 flex items-center gap-1 transition-all duration-150">
          View
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
          </svg>
        </span>
      </div>

    </div>
  </a>

<?php if (!empty($args['isCarousel'])) : ?>
</div>
<?php endif; ?>
