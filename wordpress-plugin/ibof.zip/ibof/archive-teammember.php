<?php
get_header();

// Page fields (set on the Team page in WP admin)
$team_page    = get_page_by_path('team'); // adjust slug if different
$team_fields  = $team_page ? get_fields($team_page->ID) : [];
$team_header  = $team_fields['header'] ?? '';
$team_intro   = trim($team_fields['intro'] ?? '');
$team_members = $team_fields['team_members'] ?? [];
?>

<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== INTRO ===== -->
<?php if ($team_header || $team_intro) : ?>
<div class="bg-white py-16 border-b border-gray-100">
  <div class="max-w-4xl mx-auto px-6 md:px-14 text-center">
    <?php if ($team_header) : ?>
      <div class="flex items-center justify-center gap-3 mb-5">
        <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
        <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">The Crew</span>
        <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      </div>
      <h2 class="text-gray-900 font-black mb-6" style="font-size: clamp(2rem, 4vw, 3rem);">
        <?php echo $team_header; ?>
      </h2>
    <?php endif; ?>
    <div class="text-gray-500 text-xl leading-relaxed mb-3 last:mb-0">
    <?php if ($team_intro) :
      $team_intro_paras = array_filter(preg_split('/\n{2,}/', $team_intro));
      foreach ($team_intro_paras as $team_p) : ?>
        <?php echo $team_p; ?>
      <?php endforeach;
    endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>



<!-- ===== TEAM GRID ===== -->
<?php if (!empty($team_members)) : ?>
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">

        <?php foreach ($team_members as $tm_member) :
        $tm_id      = $tm_member->ID;
        $tm_name    = get_the_title($tm_id);
        $tm_role    = get_post_meta($tm_id, 'role', true) ?: get_post_meta($tm_id, 'position', true);
        $tm_thumb   = get_the_post_thumbnail_url($tm_id, 'large');
        $tm_link    = get_permalink($tm_id);

        // Get contact info
        $tm_email = get_field('email', $tm_id) ?: get_post_meta($tm_id, 'email', true);
        $tm_phone = get_field('phone', $tm_id) ?: get_post_meta($tm_id, 'phone', true);
      ?>

        <a href="<?php echo esc_url($tm_link); ?>" class="bg-white rounded-sm shadow-sm overflow-hidden flex flex-col group hover:shadow-lg transition-shadow duration-300 block rounded-xl">

          <!-- Photo -->
          <div class="relative bg-gray-100 overflow-hidden" style="padding-top: 100%;">
            <?php if ($tm_thumb) : ?>
              <img
                src="<?php echo $tm_thumb; ?>"
                alt="<?php echo $tm_name; ?>"
                class="absolute inset-0 w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500 pointer-events-none">
            <?php else : ?>
              <div class="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-gray-100">
                <svg class="w-12 h-12 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                </svg>
              </div>
            <?php endif; ?>
            <div class="absolute bottom-0 left-0 right-0 h-1 bg-[#ff9101]"></div>
          </div>

          <!-- Content -->
          <div class="p-6 flex flex-col flex-1">
            <?php if ($tm_role) : ?>
              <p class="text-[#ff9101] text-[12px] font-bold uppercase tracking-[0.25em] mb-1">
                <?php echo $tm_role; ?>
              </p>
            <?php endif; ?>
            <h3 class="text-gray-900 font-black text-lg leading-snug mb-3">
              <?php echo $tm_name; ?>
            </h3>

            <!-- Contact Icons -->
            <?php if ($tm_email || $tm_phone) : ?>
              <div class="flex items-center gap-3 mt-auto">
                <?php if ($tm_email) : ?>
                  <div class="text-[#ff9101]" title="Email available">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                    </svg>
                  </div>
                <?php endif; ?>

                <?php if ($tm_phone) : ?>
                  <div class="text-[#ff9101]" title="Phone available">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 8V5z"/>
                    </svg>
                  </div>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>

        </a>

      <?php endforeach; ?>

    </div>
  </div>
</div>
<?php endif; ?>


<!-- ===== CTA BAND ===== -->
<div class="bg-[#032972] py-14">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14 flex flex-col sm:flex-row items-center justify-between gap-6">
    <p class="text-white font-black text-2xl md:text-3xl">Ready to get out on the water?</p>
    <a href="<?php echo home_url('/contact/'); ?>"
      class="flex-shrink-0 inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-[#ff9101] font-black px-8 py-4 text-base uppercase tracking-[0.2em] transition-all duration-200">
      Contact Us
      <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
      </svg>
    </a>
  </div>
</div>

<?php get_footer(); ?>