<?php
/**
 * Template Name: Boat Comparison
 */
get_header();
while (have_posts()) : the_post();
$mp_green_footer = get_post_meta($post->ID, 'green_footer_text', true);
?>

<!-- ===== PAGE HERO ===== -->
<div class="mp-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden <?php echo !has_post_thumbnail() ? 'bg-[#111111]' : ''; ?>"
  <?php if (has_post_thumbnail()) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>
  <?php if (!has_post_thumbnail()) : ?>
  <div class="absolute inset-0 opacity-[0.04]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <?php endif; ?>
  <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">AI Analysis</span>
    </div>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>

<!-- ===== BOAT COMPARISON TOOL ===== -->
<!-- <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet"> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>

<!-- Minimal custom CSS only for things Tailwind cannot do -->
<style>
  .font-bebas   { font-family: 'Bebas Neue', sans-serif; }
  .font-mono-jb { font-family: 'JetBrains Mono', monospace; }
  .clip-angled    { clip-path: polygon(14px 0%, 100% 0%, calc(100% - 14px) 100%, 0% 100%); }
  .clip-angled-sm { clip-path: polygon(8px 0%, 100% 0%, calc(100% - 8px) 100%, 0% 100%); }
  .grid-texture {
    background-image:
      linear-gradient(rgba(255,145,1,0.013) 1px, transparent 1px),
      linear-gradient(90deg, rgba(255,145,1,0.013) 1px, transparent 1px);
    background-size: 48px 48px;
  }
  .bar-fill-anim { transition: width 1.2s cubic-bezier(.25,1,.5,1); }
  .shimmer-btn { position: relative; overflow: hidden; }
  .shimmer-btn::after {
    content: '';
    position: absolute; inset: 0;
    background: rgba(255,255,255,0.14);
    transform: translateX(-110%) skewX(-15deg);
    transition: transform 0.4s;
  }
  .shimmer-btn:hover::after { transform: translateX(110%) skewX(-15deg); }
  select { -webkit-appearance: none; appearance: none; }
  select option { background: #1a1a1a; font-size: 14px; }
  @keyframes status-pulse { 0%,100%{opacity:1} 50%{opacity:.35} }
  .status-pulse { animation: status-pulse 2s infinite; box-shadow: 0 0 8px #22c55e; }

</style>

<div class="bg-[#0a0a0a] relative overflow-x-hidden">
  <!-- Subtle grid overlay -->
  <div class="grid-texture fixed inset-0 pointer-events-none z-0"></div>

  <div class="relative z-10 max-w-[1400px] mx-auto px-5 md:px-10 py-14">

    <!-- ══════════════════════════════════
         USE CASE
    ══════════════════════════════════ -->
    <div class="mb-12">
      <div class="flex items-center gap-4 mb-6">
        <h2 class="font-bebas text-white text-3xl tracking-widest whitespace-nowrap">YOUR USE CASE</h2>
        <div class="flex-1 h-px bg-gradient-to-r from-[rgba(255,145,1,0.25)] to-transparent"></div>
        <span class="font-mono-jb text-base tracking-[.25em] text-[#ddd] uppercase hidden md:block">Filters AI Analysis</span>
      </div>
      <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        <?php
        $use_cases = [
          ['🎣','Offshore Fishing', true],
          ['🌊','Inshore Fishing', false],
          ['⛱️','Sandbar / Cruising', false],
          ['👨‍👩‍👧','Family Boating', false],
          ['🏝️','Bahamas Trips', false],
        ];
        foreach ($use_cases as $uc) :
          $active = $uc[2]
            ? 'border-[#ff9101] bg-[rgba(255,145,1,0.10)]'
            : 'border-[rgba(255,255,255,0.07)] bg-[#111111]';
        ?>
        <button onclick="bcSetLifestyle(this)"
          class="bc-pill <?php echo $active; ?> border rounded-sm py-4 px-3 text-center cursor-pointer transition-all duration-200 hover:border-[#ff9101] hover:bg-[rgba(255,145,1,0.10)]">
          <div class="text-2xl mb-1.5"><?php echo $uc[0]; ?></div>
          <div class="text-base text-[#ddd] font-medium leading-tight"><?php echo $uc[1]; ?></div>
        </button>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- ══════════════════════════════════
         BOAT SELECTOR
    ══════════════════════════════════ -->
    <div class="bg-[#111111] border border-[rgba(255,145,1,0.22)] rounded-sm overflow-hidden mb-5">
      <div class="grid grid-cols-1 md:grid-cols-[1fr_60px_1fr_60px_1fr]">

        <div class="p-7">
          <div class="font-mono-jb text-base tracking-[.3em] uppercase text-[#ff9101] mb-2">Boat A</div>
          <select class="w-full bg-transparent border-none text-white font-bebas text-2xl tracking-wide cursor-pointer outline-none">
            <option>2024 Regulator 27</option>
            <option>2024 Grady-White 271</option>
            <option>2024 Boston Whaler 270</option>
            <option>2024 Mako 284 CC</option>
          </select>
        </div>

        <div class="flex items-center justify-center border-t md:border-t-0 md:border-x border-[rgba(255,255,255,0.06)] py-4 md:py-0">
          <span class="font-bebas text-lg tracking-[.15em] text-[#bbb]">VS</span>
        </div>

        <div class="p-7">
          <div class="font-mono-jb text-base tracking-[.3em] uppercase text-[#0ea5e9] mb-2">Boat B</div>
          <select class="w-full bg-transparent border-none text-white font-bebas text-2xl tracking-wide cursor-pointer outline-none">
            <option>2024 Sea Hunt 27</option>
            <option>2024 Pursuit OS 285</option>
            <option>2024 Robalo R272</option>
            <option>2024 Sportsman 282</option>
          </select>
        </div>

        <div class="flex items-center justify-center border-t md:border-t-0 md:border-x border-[rgba(255,255,255,0.06)] py-4 md:py-0">
          <span class="font-bebas text-lg tracking-[.15em] text-[#bbb]">VS</span>
        </div>

        <div class="p-7">
          <div class="font-mono-jb text-base tracking-[.3em] uppercase text-[#a855f7] mb-2">
            Boat C <span class="normal-case tracking-normal font-sans text-base text-[#bbb]">(optional)</span>
          </div>
          <select class="w-full bg-transparent border-none text-white font-bebas text-2xl tracking-wide cursor-pointer outline-none">
            <option value="">— Add Third Boat —</option>
            <option>2024 Sailfish 290 CC</option>
            <option>2024 Cobia 280 CC</option>
            <option>2024 Contender 28T</option>
          </select>
        </div>

      </div>
    </div>

    <!-- Analyze CTA -->
    <div class="flex justify-center mb-14">
      <button onclick="bcRunComparison()"
        class="shimmer-btn clip-angled bg-[#ff9101] text-black font-bebas text-xl tracking-[.12em] px-16 py-[18px] border-none cursor-pointer transition-all duration-200 hover:shadow-[0_0_48px_rgba(255,145,1,0.35)] hover:scale-[1.02]">
        ⚡ ANALYZE WITH AI
      </button>
    </div>

    <!-- ══════════════════════════════════
         VERDICT BANNER
    ══════════════════════════════════ -->
    <div class="flex flex-col md:flex-row md:items-center gap-6 p-7 md:p-9 mb-12
      bg-gradient-to-br from-[rgba(255,145,1,0.07)] to-[rgba(255,145,1,0.015)]
      border border-[rgba(255,145,1,0.22)] border-l-4 border-l-[#ff9101] rounded-sm">
      <div class="text-5xl leading-none shrink-0">🏆</div>
      <div class="flex-1 min-w-0">
        <div class="font-mono-jb text-base tracking-[.28em] uppercase text-[#ff9101] mb-1.5">AI Verdict — Offshore Fishing</div>
        <div class="font-bebas text-2xl md:text-3xl tracking-wide text-white mb-2 leading-snug">Regulator 27 Edges Sea Hunt for Serious Offshore Anglers</div>
        <p class="text-lg text-[#ddd] leading-relaxed max-w-2xl">With a 22° deadrise and 151-gallon fuel tank, the Regulator 27 delivers a drier, more composed ride in Gulf chop. The Sea Hunt 27 trades rough-water capability for a more versatile deck layout — the stronger choice if you mix fishing with family days.</p>
      </div>
      <div class="clip-angled-sm bg-[#ff9101] text-black font-bebas text-lg tracking-[.15em] px-5 py-2 shrink-0 self-start md:self-center">
        BEST FOR OFFSHORE
      </div>
    </div>

    <!-- ══════════════════════════════════
         STATS STRIP
    ══════════════════════════════════ -->
    <div class="grid grid-cols-2 md:grid-cols-5 bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm overflow-hidden mb-12">
      <?php
      $stats = [
        ['Length',    [['A','#ff9101','27.3','ft'],['B','#0ea5e9','28.1','ft']]],
        ['Max HP',    [['A','#ff9101','600','hp'], ['B','#0ea5e9','600','hp']]],
        ['Fuel Cap',  [['A','#ff9101','151','gal'],['B','#0ea5e9','130','gal']]],
        ['Est. Range',[['A','#ff9101','318','mi'], ['B','#0ea5e9','263','mi']]],
        ['Deadrise',  [['A','#ff9101','22°',''],   ['B','#0ea5e9','18°','']]],
      ];
      foreach ($stats as $idx => $s) :
        $border = $idx > 0 ? 'border-l border-[rgba(255,255,255,0.07)]' : '';
      ?>
      <div class="p-5 md:p-6 <?php echo $border; ?>">
        <div class="font-mono-jb text-base tracking-[.28em] uppercase text-[#ddd] mb-3"><?php echo $s[0]; ?></div>
        <div class="flex flex-col gap-1.5">
          <?php foreach ($s[1] as $r) : ?>
          <div class="flex items-center justify-between gap-2">
            <div class="flex items-center gap-1.5">
              <span class="w-[6px] h-[6px] rounded-full shrink-0" style="background:<?php echo $r[1]; ?>"></span>
              <span class="font-mono-jb text-base text-[#bbb]"><?php echo $r[0]; ?></span>
            </div>
            <span class="font-bebas text-xl leading-none" style="color:<?php echo $r[1]; ?>"><?php echo $r[2]; ?><span class="text-base text-[#ddd] ml-0.5"><?php echo $r[3]; ?></span></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- ══════════════════════════════════
         PERFORMANCE SCORES
    ══════════════════════════════════ -->
    <div class="mb-12">
      <div class="flex items-center gap-4 mb-6">
        <h2 class="font-bebas text-white text-3xl tracking-widest whitespace-nowrap">PERFORMANCE SCORES</h2>
        <div class="flex-1 h-px bg-gradient-to-r from-[rgba(255,145,1,0.25)] to-transparent"></div>
        <span class="font-mono-jb text-base tracking-[.25em] text-[#ddd] uppercase hidden md:block">AI-Calculated</span>
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <?php
        $cards = [
          ['🌊','Offshore Score', '#ff9101',88, '#0ea5e9',74],
          ['👨‍👩‍👧','Family Score',  '#ff9101',62, '#0ea5e9',81],
          ['🎣','Fishing Score',  '#ff9101',92, '#0ea5e9',84],
          ['⛱️','Sandbar Score',  '#ff9101',58, '#0ea5e9',79],
        ];
        foreach ($cards as $c) : ?>
        <div class="relative overflow-hidden bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm p-6
          transition-all duration-200 hover:border-[rgba(255,145,1,0.22)] hover:-translate-y-0.5">
          <div class="absolute top-0 left-0 right-0 h-[2px]" style="background:linear-gradient(90deg,<?php echo $c[2]; ?>,transparent)"></div>
          <div class="text-[32px] mb-3"><?php echo $c[0]; ?></div>
          <div class="font-mono-jb text-base tracking-[.22em] uppercase text-[#ddd] mb-4"><?php echo $c[1]; ?></div>
          <div class="flex flex-col gap-2">
            <div class="flex items-center gap-2">
              <span class="font-mono-jb text-base w-3" style="color:<?php echo $c[2]; ?>">A</span>
              <div class="flex-1 h-1.5 bg-[rgba(255,255,255,0.06)] rounded-full overflow-hidden">
                <div class="bar-fill-anim h-full rounded-full" style="width:<?php echo $c[3]; ?>%;background:<?php echo $c[2]; ?>"></div>
              </div>
              <span class="font-mono-jb text-base w-5 text-right" style="color:<?php echo $c[2]; ?>"><?php echo $c[3]; ?></span>
            </div>
            <div class="flex items-center gap-2">
              <span class="font-mono-jb text-base w-3" style="color:<?php echo $c[4]; ?>">B</span>
              <div class="flex-1 h-1.5 bg-[rgba(255,255,255,0.06)] rounded-full overflow-hidden">
                <div class="bar-fill-anim h-full rounded-full" style="width:<?php echo $c[5]; ?>%;background:<?php echo $c[4]; ?>"></div>
              </div>
              <span class="font-mono-jb text-base w-5 text-right" style="color:<?php echo $c[4]; ?>"><?php echo $c[5]; ?></span>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- ══════════════════════════════════
         CHARTS
    ══════════════════════════════════ -->
    <div class="mb-12">
      <div class="flex items-center gap-4 mb-6">
        <h2 class="font-bebas text-white text-3xl tracking-widest whitespace-nowrap">DATA VISUALIZATION</h2>
        <div class="flex-1 h-px bg-gradient-to-r from-[rgba(255,145,1,0.25)] to-transparent"></div>
        <span class="font-mono-jb text-base tracking-[.25em] text-[#ddd] uppercase hidden md:block">Chart.js</span>
      </div>

      <!-- Row 1 -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <div class="bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm p-7">
          <div class="font-mono-jb text-base tracking-[.22em] uppercase text-[#ddd] mb-5">⬡ Overall Performance Radar</div>
          <canvas id="bcRadarChart" style="max-height:260px"></canvas>
        </div>
        <div class="bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm p-7">
          <div class="font-mono-jb text-base tracking-[.22em] uppercase text-[#ddd] mb-5">≡ Key Spec Comparison</div>
          <canvas id="bcBarChart" style="max-height:260px"></canvas>
        </div>
      </div>

      <!-- Row 2 -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
        <div class="bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm p-7">
          <div class="font-mono-jb text-base tracking-[.22em] uppercase text-[#ddd] mb-5">〜 Fuel Burn by Speed (gph)</div>
          <canvas id="bcFuelChart" style="max-height:260px"></canvas>
        </div>
        <div class="bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm p-7">
          <div class="font-mono-jb text-base tracking-[.22em] uppercase text-[#ddd] mb-5">◎ Score Breakdown — Regulator 27</div>
          <canvas id="bcDoughnutChart" style="max-height:260px"></canvas>
        </div>
      </div>

      <!-- Row 3 full width -->
      <div class="bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm p-7">
        <div class="font-mono-jb text-base tracking-[.22em] uppercase text-[#ddd] mb-5">◫ 3-Year Ownership Cost Breakdown</div>
        <canvas id="bcCostChart" style="max-height:300px"></canvas>
      </div>
    </div>

    <!-- ══════════════════════════════════
         SPEC TABLE
    ══════════════════════════════════ -->
    <div class="mb-12">
      <div class="flex items-center gap-4 mb-6">
        <h2 class="font-bebas text-white text-3xl tracking-widest whitespace-nowrap">FULL SPEC TABLE</h2>
        <div class="flex-1 h-px bg-gradient-to-r from-[rgba(255,145,1,0.25)] to-transparent"></div>
      </div>
      <div class="overflow-x-auto rounded-sm border border-[rgba(255,255,255,0.07)]">
        <table class="w-full border-collapse bg-[#111111]">
          <thead>
            <tr class="bg-[#161616] border-b border-[rgba(255,145,1,0.2)]">
              <th class="text-left px-5 py-4 font-mono-jb text-base tracking-[.22em] uppercase text-[#ddd] font-normal">Specification</th>
              <th class="text-left px-5 py-4 font-mono-jb text-base tracking-[.22em] uppercase font-normal text-[#ff9101]">Regulator 27</th>
              <th class="text-left px-5 py-4 font-mono-jb text-base tracking-[.22em] uppercase font-normal text-[#0ea5e9]">Sea Hunt 27</th>
              <th class="text-left px-5 py-4 font-mono-jb text-base tracking-[.22em] uppercase text-[#ddd] font-normal">Difference</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $specs = [
              // label, val-A, val-B, diff, a-wins, b-wins
              ['LOA',            "27'3\"",    "28'1\"",    '−10"',      false, false],
              ['Beam',           "9'10\"",    "9'4\"",     '+6"',       true,  false],
              ['Deadrise',       '22°',       '18°',       '+4°',       true,  false],
              ['Dry Weight',     '6,200 lbs', '5,800 lbs', '−400 lbs',  false, true ],
              ['Fuel Capacity',  '151 gal',   '130 gal',   '+21 gal',   true,  false],
              ['Max HP',         '600 hp',    '600 hp',    'Same',      false, false],
              ['Seating',        '12',        '14',        '+2',        false, true ],
              ['Livewell',       '40 gal',    '30 gal',    '+10 gal',   true,  false],
              ['Est. Range',     '318 mi',    '263 mi',    '+55 mi',    true,  false],
              ['Draft (up)',     '14"',       '12"',       '−2"',       false, true ],
              ['MSRP (base)',    '$189,000',  '$164,000',  '−$25,000',  false, true ],
            ];
            foreach ($specs as $i => $row) :
              $rowBg = $i % 2 === 0 ? '' : 'bg-[rgba(255,255,255,0.01)]';
            ?>
            <tr class="<?php echo $rowBg; ?> border-b border-[rgba(255,255,255,0.05)] last:border-0 hover:bg-[rgba(255,145,1,0.02)] transition-colors">
              <td class="px-5 py-3 text-lg text-white font-medium"><?php echo $row[0]; ?></td>
              <td class="px-5 py-3 font-mono-jb text-lg <?php echo $row[4] ? 'text-[#22c55e] font-semibold' : 'text-[#ddd]'; ?>">
                <?php echo $row[1]; ?>
                <?php if ($row[4]) : ?><span class="inline-block bg-[rgba(34,197,94,0.12)] text-[#22c55e] font-mono-jb text-base tracking-[.14em] px-1.5 py-0.5 rounded-sm ml-2 align-middle">BEST</span><?php endif; ?>
              </td>
              <td class="px-5 py-3 font-mono-jb text-lg <?php echo $row[5] ? 'text-[#22c55e] font-semibold' : 'text-[#ddd]'; ?>">
                <?php echo $row[2]; ?>
                <?php if ($row[5]) : ?><span class="inline-block bg-[rgba(34,197,94,0.12)] text-[#22c55e] font-mono-jb text-base tracking-[.14em] px-1.5 py-0.5 rounded-sm ml-2 align-middle">BEST</span><?php endif; ?>
              </td>
              <td class="px-5 py-3 font-mono-jb text-lg <?php echo $row[3]==='Same' ? 'text-[#bbb]' : ($row[4] ? 'text-[#22c55e]' : ($row[5] ? 'text-[#0ea5e9]' : 'text-[#ddd]')); ?>">
                <?php echo $row[3]; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ══════════════════════════════════
         PROS & CONS
    ══════════════════════════════════ -->
    <div class="mb-12">
      <div class="flex items-center gap-4 mb-6">
        <h2 class="font-bebas text-white text-3xl tracking-widest whitespace-nowrap">PROS &amp; CONS</h2>
        <div class="flex-1 h-px bg-gradient-to-r from-[rgba(255,145,1,0.25)] to-transparent"></div>
        <span class="font-mono-jb text-base tracking-[.25em] text-[#ddd] uppercase hidden md:block">AI Generated</span>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-5">

        <!-- Boat A -->
        <div class="bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm overflow-hidden">
          <div class="flex items-center gap-2.5 px-6 py-4 border-b border-[rgba(255,255,255,0.07)]">
            <span class="w-2.5 h-2.5 rounded-full bg-[#ff9101] shrink-0"></span>
            <h3 class="font-bebas text-xl tracking-wide text-white m-0">REGULATOR 27</h3>
          </div>
          <div class="px-6 py-5">
            <div class="font-mono-jb text-base tracking-[.28em] uppercase text-[#22c55e] mb-3">✓ Pros</div>
            <ul class="flex flex-col gap-2 list-none p-0 m-0">
              <?php foreach ([
                'Steeper 22° deadrise handles Gulf chop with far less pounding',
                '151-gallon tank enables true Bahamas-capable range',
                '40-gallon livewell is tournament-grade',
                'Premium build quality with strong long-term resale value',
                'Wider beam improves stability at anchor',
              ] as $pro) : ?>
              <li class="flex gap-2.5 text-lg text-[#ddd] leading-snug">
                <span class="text-[#22c55e] text-base mt-0.5 shrink-0">→</span><?php echo $pro; ?>
              </li>
              <?php endforeach; ?>
            </ul>
          </div>
          <div class="h-px bg-[rgba(255,255,255,0.06)] mx-6"></div>
          <div class="px-6 py-5">
            <div class="font-mono-jb text-base tracking-[.28em] uppercase text-[#ef4444] mb-3">✗ Cons</div>
            <ul class="flex flex-col gap-2 list-none p-0 m-0">
              <?php foreach ([
                '$25k price premium over the Sea Hunt equivalent',
                'Less seating limits capacity on large sandbar days',
                'Deeper draft restricts very shallow water access',
              ] as $con) : ?>
              <li class="flex gap-2.5 text-lg text-[#ddd] leading-snug">
                <span class="text-[#ef4444] text-base mt-0.5 shrink-0">→</span><?php echo $con; ?>
              </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>

        <!-- Boat B -->
        <div class="bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm overflow-hidden">
          <div class="flex items-center gap-2.5 px-6 py-4 border-b border-[rgba(255,255,255,0.07)]">
            <span class="w-2.5 h-2.5 rounded-full bg-[#0ea5e9] shrink-0"></span>
            <h3 class="font-bebas text-xl tracking-wide text-white m-0">SEA HUNT 27</h3>
          </div>
          <div class="px-6 py-5">
            <div class="text-base tracking-[.28em] uppercase text-[#22c55e] mb-3">✓ Pros</div>
            <ul class="flex flex-col gap-2 list-none p-0 m-0">
              <?php foreach ([
                '$25k more affordable at entry — strong value proposition',
                '14-seat capacity for bigger family groups',
                'Shallower 12" draft opens up more backcountry areas',
                'Versatile layout works equally well for fishing and cruising',
                'Lighter hull means better fuel economy in calm conditions',
              ] as $pro) : ?>
              <li class="flex gap-2.5 text-lg text-[#ddd] leading-snug">
                <span class="text-[#22c55e] text-xs mt-0.5 shrink-0">→</span><?php echo $pro; ?>
              </li>
              <?php endforeach; ?>
            </ul>
          </div>
          <div class="h-px bg-[rgba(255,255,255,0.06)] mx-6"></div>
          <div class="px-6 py-5">
            <div class="text-base tracking-[.28em] uppercase text-[#ef4444] mb-3">✗ Cons</div>
            <ul class="flex flex-col gap-2 list-none p-0 m-0">
              <?php foreach ([
                '18° deadrise delivers a rougher, wetter ride in chop',
                '130-gal tank meaningfully limits offshore range',
                'Smaller livewell if tournament fishing is a primary goal',
              ] as $con) : ?>
              <li class="flex gap-2.5 text-lg text-[#ddd] leading-snug">
                <span class="text-[#ef4444] text-xs mt-0.5 shrink-0">→</span><?php echo $con; ?>
              </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>

        <!-- Best For -->
        <div class="bg-gradient-to-br from-[rgba(255,145,1,0.06)] to-[#111111] border border-[rgba(255,145,1,0.22)] rounded-sm overflow-hidden">
          <div class="flex items-center gap-2.5 px-6 py-4 border-b border-[rgba(255,145,1,0.18)]">
            <span class="w-2.5 h-2.5 rounded-full bg-[#ff9101] shrink-0"></span>
            <h3 class="font-bebas text-xl tracking-wide text-white m-0">CHOOSE YOUR BOAT</h3>
          </div>
          <div class="px-6 py-5">
            <div class="font-mono-jb text-base tracking-[.18em] uppercase text-[#ff9101] mb-3">◈ Pick the Regulator 27 if...</div>
            <ul class="flex flex-col gap-2 list-none p-0 m-0">
              <?php foreach ([
                'You fish offshore 30+ miles regularly',
                'Bahamas or extended range trips are on the list',
                'Ride quality matters more than raw capacity',
                'Long-term resale value is part of your thinking',
              ] as $item) : ?>
              <li class="flex gap-2.5 text-lg text-[#ddd] leading-snug">
                <span class="text-[#ff9101] text-base mt-0.5 shrink-0">→</span><?php echo $item; ?>
              </li>
              <?php endforeach; ?>
            </ul>
          </div>
          <div class="h-px bg-[rgba(255,255,255,0.06)] mx-6"></div>
          <div class="px-6 py-5">
            <div class="font-mono-jb text-base tracking-[.18em] uppercase text-[#0ea5e9] mb-3">◈ Pick the Sea Hunt 27 if...</div>
            <ul class="flex flex-col gap-2 list-none p-0 m-0">
              <?php foreach ([
                'You mix fishing with family and sandbar days',
                'Inshore and nearshore is your primary zone',
                'Shallow water access matters frequently',
                'You want more boat per dollar spent',
              ] as $item) : ?>
              <li class="flex gap-2.5 text-lg text-[#ddd] leading-snug">
                <span class="text-[#0ea5e9] text-base mt-0.5 shrink-0">→</span><?php echo $item; ?>
              </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>

      </div>
    </div>

    <!-- ══════════════════════════════════
         3-YEAR OWNERSHIP COST
    ══════════════════════════════════ -->
    <div class="mb-12">
      <div class="flex items-center gap-4 mb-6">
        <h2 class="font-bebas text-white text-3xl tracking-widest whitespace-nowrap">3-YEAR OWNERSHIP COST</h2>
        <div class="flex-1 h-px bg-gradient-to-r from-[rgba(255,145,1,0.25)] to-transparent"></div>
        <span class="font-mono-jb text-base tracking-[.25em] text-[#ddd] uppercase hidden md:block">Estimated</span>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-[1fr_1fr_1fr_auto] gap-5 items-start">

        <!-- Boat A -->
        <div class="bg-[#111111] border-t-2 border-t-[#ff9101] border border-[rgba(255,255,255,0.07)] rounded-sm overflow-hidden">
          <div class="px-6 py-5">
            <div class="font-mono-jb text-base tracking-[.24em] uppercase text-[#ff9101] mb-4">Regulator 27</div>
            <?php foreach ([
              ['Fuel (150 hrs/yr)','$18,900/yr'],
              ['Annual Maintenance','$3,200/yr'],
              ['Insurance','$2,800/yr'],
              ['Storage (marina)','$4,200/yr'],
              ['Depreciation (3yr)','$28,000'],
            ] as $r) : ?>
            <div class="flex justify-between items-center py-2.5 border-b border-[rgba(255,255,255,0.05)] last:border-0 text-lg">
              <span class="text-[#ddd]"><?php echo $r[0]; ?></span>
              <span class="font-mono-jb text-base text-white"><?php echo $r[1]; ?></span>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="flex justify-between items-center px-6 py-4 bg-[rgba(255,145,1,0.05)] border-t-2 border-[rgba(255,145,1,0.2)]">
            <span class="font-mono-jb text-base tracking-[.22em] uppercase text-[#ff9101]">3-Year Total</span>
            <span class="font-bebas text-3xl text-[#ff9101] tracking-wide">$113,300</span>
          </div>
        </div>

        <!-- Boat B -->
        <div class="bg-[#111111] border-t-2 border-t-[#0ea5e9] border border-[rgba(255,255,255,0.07)] rounded-sm overflow-hidden">
          <div class="px-6 py-5">
            <div class="font-mono-jb text-base tracking-[.24em] uppercase text-[#0ea5e9] mb-4">Sea Hunt 27</div>
            <?php foreach ([
              ['Fuel (150 hrs/yr)','$16,200/yr'],
              ['Annual Maintenance','$2,600/yr'],
              ['Insurance','$2,200/yr'],
              ['Storage (marina)','$4,200/yr'],
              ['Depreciation (3yr)','$22,000'],
            ] as $r) : ?>
            <div class="flex justify-between items-center py-2.5 border-b border-[rgba(255,255,255,0.05)] last:border-0 text-lg">
              <span class="text-[#ddd]"><?php echo $r[0]; ?></span>
              <span class="font-mono-jb text-base text-white"><?php echo $r[1]; ?></span>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="flex justify-between items-center px-6 py-4 bg-[rgba(255,145,1,0.05)] border-t-2 border-[rgba(255,145,1,0.2)]">
            <span class="font-mono-jb text-base tracking-[.22em] uppercase text-[#ff9101]">3-Year Total</span>
            <span class="font-bebas text-3xl text-[#ff9101] tracking-wide">$95,000</span>
          </div>
        </div>

        <!-- Notes -->
        <div class="bg-[#111111] border-t-2 border-t-[#22c55e] border border-[rgba(255,255,255,0.07)] rounded-sm p-6">
          <div class="font-mono-jb text-base tracking-[.24em] uppercase text-[#22c55e] mb-4">Analysis Notes</div>
          <p class="text-lg text-[#ddd] leading-relaxed mb-3">Fuel estimates assume twin 300hp engines at 30 mph cruise. Fuel priced at $5.50/gal.</p>
          <p class="text-lg text-[#ddd] leading-relaxed mb-3">Maintenance covers bottom paint, annual service, impellers, filters. Excludes major repairs.</p>
          <p class="text-lg text-[#ddd] leading-relaxed">Depreciation modeled at 15% Year 1, 10% Years 2–3 for premium center consoles.</p>
        </div>

        <!-- Difference callout -->
        <div class="bg-[#111111] border border-[rgba(255,145,1,0.22)] rounded-sm p-7 text-center min-w-[200px]">
          <div class="font-mono-jb text-base tracking-[.28em] uppercase text-[#ddd] mb-3">3-Year Difference</div>
          <div class="font-bebas text-5xl text-[#ff9101] leading-none mb-2">$18,300</div>
          <p class="text-lg text-[#ddd] leading-relaxed">More to own<br>Regulator 27 over<br>three years</p>
        </div>

      </div>
    </div>

    <!-- ══════════════════════════════════
         AI CHAT
    ══════════════════════════════════ -->
    <div class="mb-12">
      <div class="flex items-center gap-4 mb-6">
        <h2 class="font-bebas text-white text-3xl tracking-widest whitespace-nowrap">ASK THE AI</h2>
        <div class="flex-1 h-px bg-gradient-to-r from-[rgba(255,145,1,0.25)] to-transparent"></div>
        <span class="font-mono-jb text-base tracking-[.25em] text-[#ddd] uppercase hidden md:block">Conversational</span>
      </div>
      <div class="bg-[#111111] border border-[rgba(255,255,255,0.07)] rounded-sm overflow-hidden">

        <!-- Header -->
        <div class="flex items-center gap-3 px-7 py-4 bg-[#161616] border-b border-[rgba(255,145,1,0.18)]">
          <span class="w-2 h-2 rounded-full bg-[#22c55e] status-pulse shrink-0"></span>
          <span class="font-mono-jb text-lg tracking-[.18em] uppercase text-white">Marine Intelligence</span>
          <span class="text-base text-[#bbb] ml-auto">Powered by structured boat data</span>
        </div>

        <!-- Messages -->
        <div class="flex flex-col gap-5 p-6 md:p-7" id="bcChatMessages" style="min-height:180px">

          <div class="flex gap-3 items-start">
            <div class="w-9 h-9 rounded-full bg-[rgba(255,145,1,0.10)] border border-[rgba(255,145,1,0.2)] flex items-center justify-center text-lg shrink-0">⚓</div>
            <div class="max-w-[75%] text-lg leading-relaxed bg-[#161616] border border-[rgba(255,255,255,0.06)] border-l-2 border-l-[#ff9101] text-[#ddd] px-5 py-3.5 rounded-sm">
              I've analyzed the Regulator 27 vs Sea Hunt 27. Ask me anything — how they handle Gulf chop, Bahamas capability, or what the fuel difference really means on a 60-mile offshore run.
            </div>
          </div>

          <div class="flex flex-row-reverse gap-3 items-start">
            <div class="w-9 h-9 rounded-full bg-[rgba(14,165,233,0.10)] border border-[rgba(14,165,233,0.18)] flex items-center justify-center text-lg shrink-0">👤</div>
            <div class="max-w-[75%] text-lg leading-relaxed bg-[rgba(14,165,233,0.07)] border border-[rgba(14,165,233,0.13)] text-[#ddd] px-5 py-3.5 rounded-sm">
              Which one is better for running to the Bahamas from Fort Lauderdale?
            </div>
          </div>

          <div class="flex gap-3 items-start">
            <div class="w-9 h-9 rounded-full bg-[rgba(255,145,1,0.10)] border border-[rgba(255,145,1,0.2)] flex items-center justify-center text-lg shrink-0">⚓</div>
            <div class="max-w-[75%] text-lg leading-relaxed bg-[#161616] border border-[rgba(255,255,255,0.06)] border-l-2 border-l-[#ff9101] text-[#ddd] px-5 py-3.5 rounded-sm">
              <strong class="text-white">Regulator 27 is the better Bahamas boat.</strong> The FLL → Bimini run is ~50 miles. The Regulator's 151-gal tank gives ~318mi range vs Sea Hunt's 263mi — you'll cross with meaningful reserve if the Stream pushes you off course. The 22° deadrise also makes a real difference when the Stream is running against wind. Less pounding, drier deck.
            </div>
          </div>

        </div>

        <!-- Input -->
        <div class="px-6 md:px-7 pb-6 md:pb-7">
          <div class="flex bg-black/40 border border-[rgba(255,255,255,0.07)] rounded-sm transition-colors focus-within:border-[rgba(255,145,1,0.25)]">
            <input type="text" id="bcChatInput"
              placeholder="Ask anything... e.g. 'Which handles better in 3-foot chop?'"
              class="flex-1 bg-transparent border-none outline-none text-white text-lg px-5 py-3.5 placeholder-[#444]"
              onkeypress="if(event.key==='Enter')bcSendChat()">
            <button onclick="bcSendChat()"
              class="bg-[#ff9101] text-black font-bebas text-lg tracking-[.1em] px-6 py-3 border-none cursor-pointer hover:bg-[#ffaa33] transition-colors rounded-sm">
              SEND
            </button>
          </div>
        </div>

      </div>
    </div>

    <!-- ══════════════════════════════════
         LEAD CAPTURE
    ══════════════════════════════════ -->
    <div class="relative overflow-hidden bg-gradient-to-br from-[rgba(255,145,1,0.07)] to-[#111111]
      border border-[rgba(255,145,1,0.22)] rounded-sm p-8 md:p-14">
      <!-- Glow orb -->
      <div class="absolute -top-16 -right-16 w-64 h-64 rounded-full pointer-events-none"
        style="background:radial-gradient(circle,rgba(255,145,1,0.09),transparent 70%)"></div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 items-center relative">

        <!-- Left -->
        <div>
          <div class="font-mono-jb text-base tracking-[.28em] uppercase text-[#ff9101] mb-3">High-Intent Buyers</div>
          <div class="font-bebas text-white leading-none mb-3" style="font-size:clamp(2.2rem,4.5vw,3.4rem)">READY TO PULL<br>THE TRIGGER?</div>
          <p class="text-lg text-[#ddd] font-light leading-relaxed mb-7">Talk to a real marine specialist who knows both boats. Get personalized guidance based on how and where you actually fish.</p>
          <div class="flex flex-wrap gap-6">
            <?php foreach (['No pressure sales','Sea trials available','Finance options'] as $f) : ?>
            <div class="flex items-center gap-2">
              <span class="text-[#22c55e] text-xl leading-none">✓</span>
              <span class="text-lg text-[#ddd]"><?php echo $f; ?></span>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Right: Form -->
        <div class="flex flex-col gap-3">
          <div class="grid grid-cols-2 gap-3">
            <input type="text" placeholder="First Name"
              class="bg-black/40 border border-[rgba(255,255,255,0.07)] text-white text-lg px-4 py-3.5 rounded-sm outline-none focus:border-[rgba(255,145,1,0.3)] transition-colors placeholder-[#444]">
            <input type="text" placeholder="Last Name"
              class="bg-black/40 border border-[rgba(255,255,255,0.07)] text-white text-lg px-4 py-3.5 rounded-sm outline-none focus:border-[rgba(255,145,1,0.3)] transition-colors placeholder-[#444]">
          </div>
          <div class="grid grid-cols-2 gap-3">
            <input type="email" placeholder="Email Address"
              class="bg-black/40 border border-[rgba(255,255,255,0.07)] text-white text-lg px-4 py-3.5 rounded-sm outline-none focus:border-[rgba(255,145,1,0.3)] transition-colors placeholder-[#444]">
            <input type="tel" placeholder="Phone Number"
              class="bg-black/40 border border-[rgba(255,255,255,0.07)] text-white text-lg px-4 py-3.5 rounded-sm outline-none focus:border-[rgba(255,145,1,0.3)] transition-colors placeholder-[#444]">
          </div>
          <div class="grid grid-cols-2 gap-3">
            <select class="bg-black/40 border border-[rgba(255,255,255,0.07)] text-[#ddd] text-lg px-4 py-3.5 rounded-sm outline-none focus:border-[rgba(255,145,1,0.3)] transition-colors cursor-pointer">
              <option value="">Budget Range</option>
              <option>Under $100k</option>
              <option>$100k – $150k</option>
              <option>$150k – $200k</option>
              <option>$200k+</option>
            </select>
            <select class="bg-black/40 border border-[rgba(255,255,255,0.07)] text-[#ddd] text-lg px-4 py-3.5 rounded-sm outline-none focus:border-[rgba(255,145,1,0.3)] transition-colors cursor-pointer">
              <option value="">Timeline</option>
              <option>Ready Now</option>
              <option>1–3 Months</option>
              <option>3–6 Months</option>
              <option>Just Researching</option>
            </select>
          </div>
          <input type="text" placeholder="Preferred Location / Marina"
            class="bg-black/40 border border-[rgba(255,255,255,0.07)] text-white text-lg px-4 py-3.5 rounded-sm outline-none focus:border-[rgba(255,145,1,0.3)] transition-colors placeholder-[#444]">
          <button class="shimmer-btn clip-angled-sm bg-[#ff9101] text-black font-bebas text-xl tracking-[.12em] py-4 w-full border-none cursor-pointer mt-1
            hover:shadow-[0_8px_32px_rgba(255,145,1,0.28)] hover:-translate-y-px transition-all duration-200">
            GET EXPERT GUIDANCE →
          </button>
          <p class="text-base text-[#bbb] text-center">We respond within 2 hours during business hours</p>
        </div>

      </div>
    </div>

  </div><!-- /max-w-[1400px] -->
</div><!-- /bg-[#0a0a0a] -->

<!-- ===== CHART.JS INIT ===== -->
<script>
(function () {
  const O  = '#ff9101';
  const B  = '#0ea5e9';
  const GR = 'rgba(255,255,255,0.05)';
  const LB = '#fff';

  Chart.defaults.color = LB;
  Chart.defaults.font.family = "'JetBrains Mono', monospace";
  Chart.defaults.font.size   = 11;

  /* ── Radar ── */
  new Chart(document.getElementById('bcRadarChart'), {
    type: 'radar',
    data: {
      labels: ['Offshore','Fishing','Range','Family','Sandbar','Value'],
      datasets: [
        { label:'Regulator 27', data:[88,92,85,62,58,68], borderColor:O, backgroundColor:'rgba(255,145,1,0.09)', pointBackgroundColor:O, pointRadius:4, borderWidth:2 },
        { label:'Sea Hunt 27',  data:[74,84,72,81,79,84], borderColor:B, backgroundColor:'rgba(14,165,233,0.07)', pointBackgroundColor:B, pointRadius:4, borderWidth:2 },
      ]
    },
    options: {
      scales: { r:{ min:0, max:100, ticks:{display:false}, grid:{color:GR}, pointLabels:{color:'#666', font:{size:11}}, angleLines:{color:GR} } },
      plugins: { legend:{ position:'bottom', labels:{padding:20} } }
    }
  });

  /* ── Bar ── */
  new Chart(document.getElementById('bcBarChart'), {
    type: 'bar',
    data: {
      labels: ['LOA (ft)','Beam (ft)','Fuel (gal)','Deadrise (°)','Livewell (gal)'],
      datasets: [
        { label:'Regulator 27', data:[27.3,9.83,151,22,40], backgroundColor:'rgba(255,145,1,0.72)', borderColor:O, borderWidth:1, borderRadius:2 },
        { label:'Sea Hunt 27',  data:[28.1,9.33,130,18,30], backgroundColor:'rgba(14,165,233,0.72)', borderColor:B, borderWidth:1, borderRadius:2 },
      ]
    },
    options: {
      scales: { x:{grid:{color:GR}}, y:{grid:{color:GR}} },
      plugins: { legend:{ position:'bottom', labels:{padding:20} } }
    }
  });

  /* ── Fuel line ── */
  new Chart(document.getElementById('bcFuelChart'), {
    type: 'line',
    data: {
      labels: ['15 mph','20 mph','25 mph','30 mph','35 mph','40 mph','45 mph'],
      datasets: [
        { label:'Regulator 27', data:[8,14,22,34,48,64,82], borderColor:O, backgroundColor:'rgba(255,145,1,0.07)', fill:true, tension:0.4, pointRadius:4, pointBackgroundColor:O },
        { label:'Sea Hunt 27',  data:[7,12,19,29,42,57,74], borderColor:B, backgroundColor:'rgba(14,165,233,0.05)', fill:true, tension:0.4, pointRadius:4, pointBackgroundColor:B },
      ]
    },
    options: {
      scales: {
        x:{ grid:{color:GR} },
        y:{ grid:{color:GR}, title:{ display:true, text:'Gallons / Hour', color:LB } }
      },
      plugins: { legend:{ position:'bottom', labels:{padding:20} } }
    }
  });

  /* ── Doughnut ── */
  new Chart(document.getElementById('bcDoughnutChart'), {
    type: 'doughnut',
    data: {
      labels: ['Offshore (88)','Fishing (92)','Family (62)','Sandbar (58)','Value (68)'],
      datasets: [{
        data: [88,92,62,58,68],
        backgroundColor: ['#ff9101','#ffb347','#ff6600','#cc5500','#ff9933'],
        borderColor: '#111',
        borderWidth: 2,
        hoverOffset: 6
      }]
    },
    options: {
      cutout: '65%',
      plugins: { legend:{ position:'right', labels:{padding:16} } }
    }
  });

  /* ── Stacked cost bar ── */
  new Chart(document.getElementById('bcCostChart'), {
    type: 'bar',
    data: {
      labels: ['Year 1','Year 2','Year 3'],
      datasets: [
        { label:'Reg 27 — Fuel',          data:[18900,18900,18900], backgroundColor:'rgba(255,145,1,0.82)', stack:'reg' },
        { label:'Reg 27 — Maintenance',   data:[3200,3200,3200],    backgroundColor:'rgba(255,145,1,0.50)', stack:'reg' },
        { label:'Reg 27 — Ins + Storage', data:[7000,7000,7000],    backgroundColor:'rgba(255,145,1,0.28)', stack:'reg' },
        { label:'SH 27 — Fuel',           data:[16200,16200,16200], backgroundColor:'rgba(14,165,233,0.82)', stack:'sea' },
        { label:'SH 27 — Maintenance',    data:[2600,2600,2600],    backgroundColor:'rgba(14,165,233,0.50)', stack:'sea' },
        { label:'SH 27 — Ins + Storage',  data:[6400,6400,6400],    backgroundColor:'rgba(14,165,233,0.28)', stack:'sea' },
      ]
    },
    options: {
      scales: {
        x:{ grid:{color:GR}, stacked:true },
        y:{ grid:{color:GR}, stacked:true, ticks:{ callback: v => '$'+(v/1000).toFixed(0)+'k' } }
      },
      plugins: {
        legend:{ position:'bottom', labels:{ padding:14, boxWidth:12 } },
        tooltip:{ callbacks:{ label: c => c.dataset.label + ': $' + c.raw.toLocaleString() } }
      }
    }
  });

  /* ── Lifestyle pill toggle ── */
  window.bcSetLifestyle = function (el) {
    document.querySelectorAll('.bc-pill').forEach(p => {
      p.classList.remove('border-[#ff9101]', 'bg-[rgba(255,145,1,0.10)]');
      p.classList.add('border-[rgba(255,255,255,0.07)]', 'bg-[#111111]');
    });
    el.classList.remove('border-[rgba(255,255,255,0.07)]', 'bg-[#111111]');
    el.classList.add('border-[#ff9101]', 'bg-[rgba(255,145,1,0.10)]');
  };

  /* ── Analyze button ── */
  window.bcRunComparison = function () {
    document.querySelector('.bg-gradient-to-br').scrollIntoView({ behavior:'smooth', block:'center' });
  };

  /* ── Chat ── */
  window.bcSendChat = function () {
    const input = document.getElementById('bcChatInput');
    const val   = input.value.trim();
    if (!val) return;

    const msgs = document.getElementById('bcChatMessages');

    const userDiv = document.createElement('div');
    userDiv.className = 'flex flex-row-reverse gap-3 items-start';
    userDiv.innerHTML = `
      <div class="w-9 h-9 rounded-full bg-[rgba(14,165,233,0.10)] border border-[rgba(14,165,233,0.18)] flex items-center justify-center text-lg shrink-0">👤</div>
      <div class="max-w-[75%] text-lg leading-relaxed bg-[rgba(14,165,233,0.07)] border border-[rgba(14,165,233,0.13)] text-[#ddd] px-5 py-3.5 rounded-sm">${val}</div>`;
    msgs.appendChild(userDiv);

    setTimeout(() => {
      const aiDiv = document.createElement('div');
      aiDiv.className = 'flex gap-3 items-start';
      aiDiv.innerHTML = `
        <div class="w-9 h-9 rounded-full bg-[rgba(255,145,1,0.10)] border border-[rgba(255,145,1,0.2)] flex items-center justify-center text-lg shrink-0">⚓</div>
        <div class="max-w-[75%] text-lg leading-relaxed bg-[#161616] border border-[rgba(255,255,255,0.06)] border-l-2 border-l-[#ff9101] text-[#ddd] px-5 py-3.5 rounded-sm">
          <em style="color:#444">AI response generated from your structured boat database. Connect your API endpoint here — the system sends pre-calculated specs and derived scores so the model explains, not guesses.</em>
        </div>`;
      msgs.appendChild(aiDiv);
      msgs.scrollTop = msgs.scrollHeight;
    }, 700);

    input.value = '';
    msgs.scrollTop = msgs.scrollHeight;
  };
})();
</script>

<?php
endwhile;
get_footer();
?>
