<?php
/**
 * Template Name: Location
 */
get_header();
?>

<!-- ===== PAGE HERO ===== -->
<div class="loc-hero relative min-h-[480px] flex items-end bg-cover bg-center overflow-hidden"
  <?php if (has_post_thumbnail()) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>

  <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Our Location</span>
    </div>
    <h1 class="text-white font-black leading-tight mb-4" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">
      <?php if ($post->loc_name) echo esc_html($post->loc_name).': '; ?><?php the_title(); ?>
    </h1>
    <?php if (get_the_content()) : ?>
      <div class="text-white/70 text-lg md:text-xl leading-relaxed max-w-2xl">
        <?php the_content(); ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== LOGO ===== -->
<?php if ($post->loc_logo) : ?>
<div class="bg-white py-10 border-b border-gray-100 flex justify-center px-6">
  <?php echo wp_get_attachment_image($post->loc_logo, 'full', '', array('class' => 'max-h-20 w-auto object-contain')); ?>
</div>
<?php endif; ?>


<!-- ===== HOURS + ADDRESS + MAP ===== -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">

      <!-- Hours -->
      <div class="lg:col-span-3">
        <div class="bg-white rounded-md shadow-sm overflow-hidden h-full">
          <div class="bg-[#111111] px-6 py-4 flex items-center gap-2">
            <svg class="w-4 h-4 text-[#ff9101] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Hours</h3>
          </div>
          <div class="p-6">
            <?php
            $loc_days = array(
              'Monday'    => $post->loc_mon,
              'Tuesday'   => $post->loc_tue,
              'Wednesday' => $post->loc_wed,
              'Thursday'  => $post->loc_thu,
              'Friday'    => $post->loc_fri,
              'Saturday'  => $post->loc_sat,
              'Sunday'    => $post->loc_sun,
            );
            foreach ($loc_days as $loc_day => $loc_hours) :
            ?>
            <div class="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
              <span class="text-gray-500 font-semibold text-sm"><?php echo $loc_day; ?></span>
              <span class="text-gray-900 font-black text-sm">
                <?php echo $loc_hours ? esc_html($loc_hours) : '<span class="text-gray-300">Closed</span>'; ?>
              </span>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Address + contact -->
      <div class="lg:col-span-3">
        <div class="bg-white rounded-md shadow-sm overflow-hidden h-full">
          <div class="bg-[#111111] px-6 py-4 flex items-center gap-2">
            <svg class="w-4 h-4 text-[#ff9101] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Contact & Address</h3>
          </div>
          <div class="p-6 flex flex-col gap-6">

            <?php
            $loc_addr_string = '';
            if ($post->loc_address || $post->loc_city || $post->loc_state || $post->loc_zip) :
              if ($post->loc_address)  $loc_addr_string .= $post->loc_address.' ';
              if ($post->loc_city)     $loc_addr_string .= $post->loc_city.' ';
              if ($post->loc_state)    $loc_addr_string .= $post->loc_state.' ';
              if ($post->loc_zip)      $loc_addr_string .= $post->loc_zip;
            ?>
            <div class="flex items-start gap-4">
              <span class="flex-shrink-0 w-9 h-9 bg-[#ff9101]/10 flex items-center justify-center rounded-sm mt-0.5">
                <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                </svg>
              </span>
              <div class="text-gray-700 font-semibold text-base leading-relaxed">
                <?php if ($post->loc_address) echo esc_html($post->loc_address).'<br>'; ?>
                <?php
                  $loc_citystatezip = '';
                  if ($post->loc_city)  $loc_citystatezip .= esc_html($post->loc_city);
                  if ($post->loc_city && $post->loc_state) $loc_citystatezip .= ', ';
                  if ($post->loc_state) $loc_citystatezip .= esc_html($post->loc_state);
                  if ($post->loc_zip)   $loc_citystatezip .= ' '.esc_html($post->loc_zip);
                  echo $loc_citystatezip;
                ?>
              </div>
            </div>
            <?php endif; ?>

            <!-- Main phone -->
            <div class="flex items-center gap-4">
              <span class="flex-shrink-0 w-9 h-9 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 8V5z"/>
                </svg>
              </span>
              <a href="tel:85569836337" class="text-gray-900 font-black text-lg hover:text-[#ff9101] transition-colors duration-150">
                (855) MYTENDER
              </a>
            </div>

            <?php if ($post->loc_phone) : ?>
            <div class="flex items-center gap-4">
              <span class="flex-shrink-0 w-9 h-9 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 8V5z"/>
                </svg>
              </span>
              <a href="tel:<?php echo preg_replace('/[^0-9]/', '', $post->loc_phone); ?>"
                class="text-gray-900 font-black text-lg hover:text-[#ff9101] transition-colors duration-150">
                <?php echo esc_html($post->loc_phone); ?>
              </a>
            </div>
            <?php endif; ?>

            <?php if ($loc_addr_string) : ?>
            <a href="https://maps.apple.com/?saddr=My+Location&daddr=<?php echo urlencode(trim($loc_addr_string)); ?>"
              target="_blank" rel="noopener"
              class="w-full text-center inline-flex items-center justify-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-black text-xs uppercase tracking-[0.2em] px-6 py-3.5 transition-all duration-200 mt-2">
              <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
              </svg>
              Get Directions
            </a>
            <?php endif; ?>

          </div>
        </div>
      </div>

      <!-- Map -->
      <div class="lg:col-span-6">
        <div class="bg-white rounded-md shadow-sm overflow-hidden h-full" style="min-height: 420px;">
          <?php
          $loc_map_name = ($post->loc_noname) ? '' : urlencode($post->loc_name).'+';
          $loc_map_addr = urlencode(trim($loc_addr_string));
          ?>
          <iframe
            scrolling="no" marginheight="0" marginwidth="0"
            src="https://maps.google.com/maps?width=100%25&height=600&hl=en&q=<?php echo $loc_map_name.$loc_map_addr; ?>&t=&z=12&ie=UTF8&iwloc=B&output=embed"
            width="100%" height="100%"
            style="min-height: 420px; display: block; border: 0;">
          </iframe>
        </div>
      </div>

    </div>
  </div>
</div>


<?php
wp_nav_menu(array('theme_location' => 'front-page-menu', 'container' => 'nav'));
get_footer();
?>