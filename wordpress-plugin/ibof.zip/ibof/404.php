<?php
get_header();

echo '<div id="page-header" style="background-image: url('.get_template_directory_uri().'/images/boat-placeholder.webp);">'."\n";
  echo "<h1>Page not found</h1>\n";
echo "</div> <!-- /#page-header -->\n";

echo '<div class="page-content">'."\n";
  echo "<h2>The page you requested could not be found.</h2>\n";
  echo 'Go to the <a href="'.home_url().'">home page</a> or select a page from the menu.'."\n";
echo "</div> <!-- /.page-content -->\n";

get_footer();
?>