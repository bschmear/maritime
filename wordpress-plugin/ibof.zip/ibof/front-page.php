<?php
get_header();
?>

<?php global $post; ?>



<?php
// echo '<pre>';
// var_dump( get_fields() );
// echo '</pre>';
?>

<section class="ibof-hero relative pt-24 flex flex-col justify-end bg-cover bg-center overflow-hidden "
  <?php if (has_post_thumbnail() && !isset($post->homepage_video)) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>

  <?php if (isset($post->homepage_video)) { ?>
    <video class="ibof-hero-video absolute inset-0 w-full h-full object-cover" playsinline autoplay muted loop>
      <source src="<?php echo $post->homepage_video; ?>">
    </video>
  <?php } ?>

  <!-- Gradient overlay -->
  <div class="ibof-hero-overlay absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/65 to-black/20"></div>

  <!-- Diagonal texture -->
  <div class="ibof-hero-texture absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <!-- Top accent bar -->
  <div class="ibof-hero-topbar absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>
  <?php
  $hero = get_field('hero');
  $preheadline   = $hero['preheadline'] ?? '';
  $headline_white  = $hero['headline']['headline_white'] ?? '';
  $headline_yellow = $hero['headline']['headline_yellow'] ?? '';
  $copy_intro    = $hero['copy_intro'] ?? '';
  $copy_block    = $hero['copy_block'] ?? '';
  ?>
  <!-- Main content -->
  <div class="ibof-hero-inner relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-0">

<!-- Eyebrow -->
<div class="ibof-eyebrow flex flex-col gap-3 mb-6">
  <span class="ibof-eyebrow-line block w-8 h-[2px] bg-[#ff9101] mb-3"></span>
  <?php if ($preheadline) : ?>
    <span class="ibof-eyebrow-text text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">
      <?php echo $preheadline; ?>
    </span>
  <?php endif; ?>
</div>

<!-- Headline -->
<h2 class="ibof-headline text-white font-black leading-[1.05] tracking-tight mb-5"
  style="font-size: clamp(3rem, 7.5vw, 5.75rem);">
  <?php if ($headline_white) : ?>
    <?php echo esc_html($headline_white); ?><br>
  <?php endif; ?>
  <?php if ($headline_yellow) : ?>
    <span class="ibof-headline-accent text-[#ff9101]"><?php echo esc_html($headline_yellow); ?></span>
  <?php endif; ?>
</h2>

<!-- Subheadline -->
<div class="ibof-subheadline text-white/75 text-xl leading-relaxed max-w-3xl mb-8">
  <?php if ($copy_intro) : ?>
    <h1 class="font-semibold text-white mb-2 text-3xl"><?php echo esc_html($copy_intro); ?></h1>
  <?php endif; ?>
  <?php if ($copy_block) : ?>
    <p class="text-2xl"><?php echo esc_html($copy_block); ?></p>
  <?php endif; ?>
</div>
    <!-- CTA buttons — was text-xs, now text-sm -->
    <div class="ibof-cta-row flex flex-wrap gap-3 mb-12">
      <a href="<?php echo home_url(); ?>/boats/"
        class="ibof-cta-primary inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold px-7 py-3.5 text-sm uppercase tracking-[0.2em] transition-all duration-200">
        View All Boats
        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
        </svg>
      </a>
      <a href="<?php echo home_url(); ?>/contact/"
        class="ibof-cta-secondary inline-flex items-center gap-2 border border-white/25 hover:border-[#ff9101] text-white/80 hover:text-[#ff9101] font-bold px-7 py-3.5 text-sm uppercase tracking-[0.2em] transition-all duration-200">
        Contact Us
      </a>
    </div>

  </div>

  <!-- Search form flush to hero bottom -->
  <form action="<?php echo home_url(); ?>/boats/" method="POST"
    class="ibof-search-form relative z-10 w-full shadow-2xl">

    <!-- <div class="max-w-screen-2xl mx-auto px-6 md:px-14"> -->

      <!-- Dark header bar — search title was text-xs, now text-sm; checkbox pills was text-[11px], now text-xs -->
      <div class="ibof-search-header bg-[#111111] px-6 md:px-14 py-4 ">
        <div class="max-w-screen-2xl mx-auto px-6 md:px-14 w-full flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 ">
        <h2 class="ibof-search-title text-white text-sm font-bold uppercase tracking-[0.25em] flex items-center gap-2 flex-shrink-0">
          <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"/>
            <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35"/>
          </svg>
          Search Inflatable Boats
        </h2>

        <!-- Type pill checkboxes -->
        <div class="ibof-type-checks flex flex-wrap gap-2">
          <?php
          $types = get_categories(array('taxonomy' => 'type', 'hide_empty' => false));
          foreach($types as $type) {
            $checked = ($type->slug == "new") ? "checked" : "";
            echo '
            <label class="ibof-type-label relative flex items-center gap-1.5 cursor-pointer
              text-xs font-bold uppercase tracking-widest px-4 py-1.5
              border border-white/20 text-white/60
              hover:border-[#ff9101] hover:text-[#ff9101]
              has-[:checked]:bg-[#ff9101] has-[:checked]:border-[#ff9101] has-[:checked]:text-white
              transition-all duration-150">
              <input type="checkbox" name="type[]" value="'.$type->slug.'" '.$checked.' class="sr-only">
              '.$type->name.'
            </label>';
          }
          ?>
        </div>
        </div>
      </div>

      <!-- Select fields — labels was text-[10px], now text-xs; selects was text-sm, now text-base -->
      <div class="bg-white">
      <div class="ibof-search-fields  px-6 md:px-14 py-6 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-x-6 gap-y-5 items-end max-w-screen-2xl mx-auto px-6 md:px-14">

        <?php
        $ibof_sel = "ibof-select w-full border-0 border-b-2 border-gray-200 focus:border-[#ff9101] bg-transparent px-0 py-2 text-base text-gray-800 font-semibold focus:outline-none focus:ring-0 transition-colors duration-150 appearance-none cursor-pointer";
        $ibof_lbl = "ibof-field-label block text-xs font-bold uppercase tracking-[0.2em] text-gray-400 mb-1";
        ?>

        <div class="ibof-field">
          <label class="<?php echo $ibof_lbl; ?>">Make</label>
          <select name="make" aria-label="Make" class="<?php echo $ibof_sel; ?>">
            <option value="">All Makes</option>
            <?php
            $makes = get_categories(array('taxonomy' => 'make'));
            foreach($makes as $make)
              echo '<option value="'.$make->slug.'">'.$make->name.'</option>';
            ?>
          </select>
        </div>

        <div class="ibof-field">
          <label class="<?php echo $ibof_lbl; ?>">Length</label>
          <select name="length" aria-label="Length" class="<?php echo $ibof_sel; ?>">
            <option value="">Any Length</option>
            <?php
            $boat_lengths = array();
            $bls = get_posts(array('post_type'=>'boats','meta_key'=>'boat_length','orderby'=>'meta_value_num','order'=>'ASC','posts_per_page'=>-1));
            foreach ($bls as $bl) $boat_lengths[] = get_post_meta($bl->ID, 'boat_length', true);
            $boat_lengths = array_unique($boat_lengths);
            foreach ($boat_lengths as $bl)
              echo '<option value="'.$bl.'">'.$bl.' Feet</option>';
            ?>
          </select>
        </div>

        <div class="ibof-field">
          <label class="<?php echo $ibof_lbl; ?>">Weight</label>
          <select name="weight" aria-label="Weight" class="<?php echo $ibof_sel; ?>">
            <option value="">Any Weight</option>
            <option value="0,301">Up to 300 lbs</option>
            <option value="299,501">300 – 500 lbs</option>
            <option value="499,801">500 – 800 lbs</option>
            <option value="799,1201">800 – 1200 lbs</option>
            <option value="1199,2001">1200 – 2000 lbs</option>
            <option value="1999,9999">2000+ lbs</option>
          </select>
        </div>

        <div class="ibof-field">
          <label class="<?php echo $ibof_lbl; ?>">Passengers</label>
          <select name="passengers" aria-label="Max Passengers" class="<?php echo $ibof_sel; ?>">
            <option value="">Any</option>
            <option value="0,8">Up to 7</option>
            <option value="7,99">8 or More</option>
          </select>
        </div>

        <div class="ibof-field">
          <label class="<?php echo $ibof_lbl; ?>">Max Power</label>
          <select name="hp" aria-label="Max Power" class="<?php echo $ibof_sel; ?>">
            <option value="">Any HP</option>
            <option value="0,101">Up to 100 HP</option>
            <option value="99,201">100 – 200 HP</option>
            <option value="199,999">200+ HP</option>
          </select>
        </div>

        <div class="ibof-field">
          <label class="<?php echo $ibof_lbl; ?> opacity-0 select-none">Search</label>
          <button type="submit"
            class="ibof-search-btn w-full bg-[#ff9101] hover:bg-[#e07f00] active:scale-95 text-white font-black text-sm uppercase tracking-[0.2em] py-3 px-4 flex items-center justify-center gap-2 transition-all duration-150">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8"/>
              <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35"/>
            </svg>
            Search
          </button>
        </div>

      </div>
    </div>

    <!-- Orange accent line -->
    <div class="ibof-search-foot h-[3px] bg-[#ff9101]"></div>

  </form>

</section>


<!-- =============================================
  SECTION 2: ABOUT / WHY CHOOSE US
============================================= -->


<?php
$wcu             = get_field('why_choose_us');
$wcu_preheadline = $wcu['preheadline']              ?? '';
$wcu_headline    = $wcu['headline']                 ?? '';
$wcu_copy        = trim($wcu['copy_block']          ?? '');
$wcu_btn_url     = $wcu['action_button']['page_link']   ?? home_url('/about/');
$wcu_btn_text    = $wcu['action_button']['button_text']  ?? 'Learn More About Us';
$wcu_stats       = $wcu['stat_cards']['stat']       ?? [];
?>

<section class="ibof-about py-24 bg-white">
  <div class="ibof-about-inner max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="ibof-about-grid grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

      <!-- Text block -->
      <div class="ibof-about-text">

        <?php if ($wcu_preheadline) : ?>
        <div class="ibof-about-eyebrow flex items-center gap-3 mb-5">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">
            <?php echo esc_html($wcu_preheadline); ?>
          </span>
        </div>
        <?php endif; ?>

        <?php if ($wcu_headline) : ?>
        <h2 class="ibof-about-title text-gray-900 font-black leading-tight mb-6"
          style="font-size: clamp(2rem, 4vw, 3rem);">
          <?php echo $wcu_headline; ?>
        </h2>
        <?php endif; ?>

        <?php if ($wcu_copy) :
          // Split on double newlines for paragraphs, fall back to single block
          $wcu_paragraphs = array_filter(preg_split('/\n{2,}/', $wcu_copy));
          foreach ($wcu_paragraphs as $wcu_p) : ?>
            <p class="ibof-about-p text-gray-600 text-2xl leading-relaxed mb-5">
              <?php echo $wcu_p; ?>
            </p>
          <?php endforeach;
        endif; ?>

        <?php if ($wcu_btn_url && $wcu_btn_text) : ?>
        <a href="<?php echo esc_url($wcu_btn_url); ?>"
          class="ibof-about-cta inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold px-7 py-3.5 text-sm uppercase tracking-[0.2em] transition-all duration-200 rounded-sm mt-3">
          <?php echo esc_html($wcu_btn_text); ?>
          <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
          </svg>
        </a>
        <?php endif; ?>

      </div>

      <!-- Stats / trust grid -->
      <?php if (!empty($wcu_stats)) : ?>
        <div class="ibof-about-stats grid grid-cols-2 gap-4">
          <?php foreach ($wcu_stats as $wcu_stat) :
            $wcu_num  = $wcu_stat['number']  ?? '';
            $wcu_lbl  = $wcu_stat['label']   ?? '';
            $wcu_icon = $wcu_stat['svg_icon'] ?? '';
          ?>
            <div class="ibof-stat-card bg-gray-50 border border-gray-100 rounded-md p-8 flex flex-col items-start gap-3">
              <?php if ($wcu_icon) : ?>
                <span class="material-icons text-[#ff9101] text-[28px]"><?php echo esc_html($wcu_icon); ?></span>
              <?php endif; ?>
              <?php if ($wcu_num) : ?>
                <span class="text-4xl font-black text-gray-900"><?php echo esc_html($wcu_num); ?></span>
              <?php endif; ?>
              <?php if ($wcu_lbl) : ?>
                <span class="text-sm font-bold uppercase tracking-widest text-gray-400"><?php echo esc_html($wcu_lbl); ?></span>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

    </div>
  </div>
</section>

<!-- =============================================
  SECTION 3: FEATURED INVENTORY
============================================= -->
<?php
$inventory = get_field('inventory');
if ($inventory) :
  $preheadline = $inventory['preheadline'];
  $headline = $inventory['headline'];
  $copy_block = $inventory['copy_block'];
  $action_button = $inventory['action_button'];
  $featured_boats = $inventory['featured_boats'];
?>
<section class="ibof-inventory py-24 bg-[#f7f7f7]">
  <div class="ibof-inventory-inner max-w-screen-2xl mx-auto px-6 md:px-14">

    <div class="ibof-inventory-head flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
      <div>
        <div class="ibof-inv-eyebrow flex items-center gap-3 mb-4">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]"><?php echo $preheadline; ?></span>
        </div>
        <h2 class="ibof-inv-title text-gray-900 font-black leading-tight"
          style="font-size: clamp(2rem, 4vw, 3rem);">
          <?php echo $headline; ?>
        </h2>
        <p class="ibof-inv-sub text-gray-500 text-xl mt-4 max-w-xl">
          <?php echo $copy_block; ?>
        </p>
      </div>
      <?php if ($action_button && $action_button['page_link'] && $action_button['button_text']) : ?>
      <a href="<?php echo esc_url($action_button['page_link']); ?>"
        class="ibof-inv-all flex-shrink-0 inline-flex items-center gap-2 border-2 border-[#ff9101] text-[#ff9101] hover:bg-[#ff9101] hover:text-white font-bold px-6 py-3 text-sm uppercase tracking-[0.2em] rounded-sm transition-all duration-200">
        <?php echo esc_html($action_button['button_text']); ?>
        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
        </svg>
      </a>
      <?php endif; ?>
    </div>

    <!-- Boat cards grid -->
    <div class="ibof-boats-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      <?php
      if (!empty($featured_boats)) :
        foreach ($featured_boats as $boat_post) :
          setup_postdata($boat_post);

          // Get type terms
          $ibof_types = get_the_terms($boat_post->ID, 'type');
          $ibof_type_label = (!empty($ibof_types) && !is_wp_error($ibof_types)) ? $ibof_types[0]->name : '';

          // Thumbnail
          $ibof_boat_images = get_post_meta($boat_post->ID, 'boat_images', true);
          $ibof_thumb = (!empty($ibof_boat_images['image'][0])) ? $ibof_boat_images['image'][0] : '';

          // Meta
          $ibof_len = get_post_meta($boat_post->ID, 'boat_length', true);
          $ibof_hp = get_post_meta($boat_post->ID, 'boat_hp', true);
          $ibof_pass = get_post_meta($boat_post->ID, 'boat_passengers', true);

          // Sold status
          $ibof_sold = get_post_meta($boat_post->ID, 'boat_sold', true);
          ?>

          <article class="ibof-boat-card group bg-white rounded-md overflow-hidden shadow-sm hover:shadow-lg transition-shadow duration-300 flex flex-col">

            <!-- Image -->
            <a href="<?php echo get_permalink($boat_post->ID); ?>" class="ibof-boat-img-wrap block relative overflow-hidden bg-gray-100" style="padding-top: 62%;">
              <?php if ($ibof_thumb) : ?>
                <img src="<?php echo esc_url($ibof_thumb); ?>" alt="<?php echo esc_attr($boat_post->post_title); ?>"
                  class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
              <?php else : ?>
                <div class="absolute inset-0 flex items-center justify-center bg-gray-100">
                  <svg class="w-16 h-16 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                  </svg>
                </div>
              <?php endif; ?>

              <?php if ($ibof_type_label) : ?>
                <span class="absolute top-3 left-3 bg-[#ff9101] text-white text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-sm">
                  <?php echo esc_html($ibof_type_label); ?>
                </span>
              <?php endif; ?>

              <!-- Sold badge -->
              <?php if ($ibof_sold) : ?>
                <span class="absolute top-3 right-3 bg-red-600 text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">
                  SOLD
                </span>
              <?php endif; ?>
            </a>

            <!-- Card body -->
            <div class="ibof-boat-body flex flex-col flex-1 p-6">
              <h3 class="ibof-boat-name text-gray-900 font-black text-xl mb-3 leading-tight">
                <a href="<?php echo get_permalink($boat_post->ID); ?>" class="hover:text-[#ff9101] transition-colors duration-150">
                  <?php echo esc_html($boat_post->post_title); ?>
                </a>
              </h3>

              <!-- Specs row -->
              <?php if ($ibof_len || $ibof_hp || $ibof_pass) : ?>
              <div class="ibof-boat-specs flex flex-wrap gap-4 mb-4 pb-4 border-b border-gray-100">
                <?php if ($ibof_len) : ?>
                <span class="ibof-spec flex items-center gap-1.5 text-sm text-gray-500 font-medium">
                  <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"/></svg>
                  <?php echo esc_html($ibof_len); ?> ft
                </span>
                <?php endif; ?>
                <?php if ($ibof_hp) : ?>
                <span class="ibof-spec flex items-center gap-1.5 text-sm text-gray-500 font-medium">
                  <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                  <?php echo esc_html($ibof_hp); ?> HP
                </span>
                <?php endif; ?>
                <?php if ($ibof_pass) : ?>
                <span class="ibof-spec flex items-center gap-1.5 text-sm text-gray-500 font-medium">
                  <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                  <?php echo esc_html($ibof_pass); ?> Passengers
                </span>
                <?php endif; ?>
              </div>
              <?php endif; ?>

              <p class="ibof-boat-excerpt text-gray-500 text-lg leading-relaxed mb-6 flex-1">
                <?php echo wp_trim_words($boat_post->post_content, 18, '...'); ?>
              </p>

              <a href="<?php echo get_permalink($boat_post->ID); ?>"
                class="ibof-boat-link mt-auto inline-flex items-center gap-2 bg-gray-900 hover:bg-[#ff9101] text-white font-bold px-5 py-3 text-sm uppercase tracking-[0.15em] rounded-sm transition-all duration-200 self-start">
                View Details
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
              </a>
            </div>

          </article>

        <?php
        endforeach;
        wp_reset_postdata();
      else :
        // Fallback if no featured boats are set
        echo '<p class="ibof-no-boats text-gray-400 col-span-3 text-center py-12 text-xl">No featured boats found. Add boats to the ACF inventory field.</p>';
      endif;
      ?>
    </div>

  </div>
</section>
<?php endif; // End inventory ACF check ?>

<!-- =============================================
  SECTION 4: FLORIDA BOATING GUIDE
============================================= -->
<?php
$local_knowledge = get_field('local_knowledge');
if ($local_knowledge) :
  $preheadline = $local_knowledge['preheadline'];
  $headline = $local_knowledge['headline'];
  $copy_block = $local_knowledge['copy_block'];
  $action_button = $local_knowledge['action_button'];
  $expert_tips = $local_knowledge['expert_tips'];
?>
<section class="ibof-guide py-24 bg-[#0d0d0d] relative overflow-hidden">

  <!-- Subtle bg pattern -->
  <div class="absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <div class="ibof-guide-inner relative z-10 max-w-screen-2xl mx-auto px-6 md:px-14">

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">

      <!-- Left: text -->
      <div>
        <div class="ibof-guide-eyebrow flex items-center gap-3 mb-5">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]"><?php echo esc_html($preheadline); ?></span>
        </div>

        <h2 class="ibof-guide-title text-white font-black leading-tight mb-6"
          style="font-size: clamp(2rem, 4vw, 3rem);">
          <?php echo $headline; ?>
        </h2>

        <div class="ibof-guide-p text-gray-200 text-2xl leading-relaxed mb-8">
          <?php echo $copy_block; ?>
        </div>

        <?php if ($action_button && $action_button['page_link'] && $action_button['button_text']) : ?>
        <a href="<?php echo esc_url($action_button['page_link']); ?>"
          class="ibof-guide-cta inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold px-7 py-3.5 text-sm uppercase tracking-[0.2em] rounded-sm transition-all duration-200">
          <?php echo esc_html($action_button['button_text']); ?>
          <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
          </svg>
        </a>
        <?php endif; ?>
      </div>

      <!-- Right: tips list -->
      <div class="ibof-tips-wrap">
        <?php if ($expert_tips && $expert_tips['tip_title']) : ?>
        <h3 class="ibof-tips-title text-white font-bold text-xl mb-6 uppercase tracking-widest"><?php echo esc_html($expert_tips['tip_title']); ?></h3>
        <?php endif; ?>

        <?php if ($expert_tips && $expert_tips['tips']) : ?>
        <ul class="ibof-tips-list space-y-4">
          <?php foreach($expert_tips['tips'] as $tip_data) :
            $tip = $tip_data['tip'];
            if ($tip && $tip['title'] && $tip['body']) :
          ?>
            <li class="ibof-tip flex gap-4 bg-white/5 border border-white/10 rounded-md p-5">
              <span class="ibof-tip-icon flex-shrink-0 w-8 h-8 bg-[#ff9101]/15 rounded-sm flex items-center justify-center mt-0.5">
                <svg class="w-4 h-4 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                </svg>
              </span>
              <div>
                <h4 class="ibof-tip-head text-white font-bold text-xl mb-1"><?php echo esc_html($tip['title']); ?></h4>
                <p class="ibof-tip-body text-gray-200 text-xl leading-relaxed"><?php echo esc_html($tip['body']); ?></p>
              </div>
            </li>
          <?php
            endif;
          endforeach; ?>
        </ul>
        <?php endif; ?>
      </div>

    </div>
  </div>
</section>
<?php endif; // End local_knowledge ACF check ?>


<?php
$action_banner = get_field('action_banner');
if ($action_banner) :
  $large_text = $action_banner['large_text'];
  $small_text = $action_banner['small_text'];
  $phone_number = $action_banner['phone_number'];
  $link = $action_banner['link'];
?>
<!-- =============================================
  SECTION 6: CTA CONVERSION BAND
============================================= -->
<section class="ibof-cta-band py-20 bg-[#4f7cb1] relative overflow-hidden">

  <!-- Subtle diagonal texture -->
  <div class="absolute inset-0 opacity-[0.06]"
    style="background-image: repeating-linear-gradient(45deg, #000 0, #000 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <div class="ibof-cta-band-inner relative z-10 max-w-screen-2xl mx-auto px-6 md:px-14 flex flex-col lg:flex-row items-center justify-between gap-8">

    <div>
      <h2 class="ibof-cta-band-title text-white font-black leading-tight mb-3"
        style="font-size: clamp(1.8rem, 3.5vw, 2.75rem);">
        <?php echo $large_text; ?>
      </h2>
      <p class="ibof-cta-band-sub text-white/80 text-2xl">
        <?php echo $small_text; ?>
      </p>
    </div>

    <div class="ibof-cta-band-btns flex flex-wrap gap-4 flex-shrink-0">
      <?php if ($phone_number) : ?>
      <a href="tel:<?php echo preg_replace('/[^0-9]/', '', $phone_number); ?>"
        class="inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-black px-8 py-4 text-sm uppercase tracking-[0.2em] transition-all duration-200">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 8V5z"/>
        </svg>
        <?php echo esc_html($phone_number); ?>
      </a>
      <?php endif; ?>

      <?php if ($link && $link['page'] && $link['link_text']) : ?>
      <a href="<?php echo esc_url($link['page']); ?>"
        class="inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-[#4f7cb1] font-black px-8 py-4 text-sm uppercase tracking-[0.2em] transition-all duration-200">
        <?php echo esc_html($link['link_text']); ?>
        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
        </svg>
      </a>
      <?php endif; ?>
    </div>

  </div>
</section>
<?php endif; // End action_banner ACF check ?>


<!-- =============================================
  SECTION 7: BLOG / GUIDES
============================================= -->
 <section class="ibof-blog py-24 bg-[#f7f7f7] pb-[300px] mb-[-200px]">
  <div class="ibof-blog-inner max-w-screen-2xl mx-auto px-6 md:px-14">

    <div class="ibof-blog-head flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
      <div>
        <div class="ibof-blog-eyebrow flex items-center gap-3 mb-4">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Boating Resources</span>
        </div>
        <h2 class="ibof-blog-title text-gray-900 font-black leading-tight"
          style="font-size: clamp(2rem, 4vw, 3rem);">
          Learn More About<br>Inflatable Boats
        </h2>
      </div>
      <a href="<?php echo home_url(); ?>/blog/"
        class="ibof-blog-all flex-shrink-0 inline-flex items-center gap-2 border-2 border-[#ff9101] text-[#ff9101] hover:bg-[#ff9101] hover:text-white font-bold px-6 py-3 text-sm uppercase tracking-[0.2em] rounded-sm transition-all duration-200">
        All Articles
        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
        </svg>
      </a>
    </div>

    <div class="ibof-blog-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 ">
<?php
$ibof_posts = new WP_Query(array(
  'post_type'      => 'post',
  'posts_per_page' => 4,
  'orderby'        => 'date',
  'order'          => 'DESC',
));

if ($ibof_posts->have_posts()) :
  while ($ibof_posts->have_posts()) : $ibof_posts->the_post();
    $ibof_post_thumb = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'medium_large') : '';
    $post_title = get_the_title();
    ?>
    <article class="ibof-blog-card group bg-white rounded-md overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300 flex flex-col">

      <a href="<?php the_permalink(); ?>"
         class="ibof-blog-img-wrap block relative overflow-hidden bg-gray-100"
         style="padding-top: 58%;"
         title="Read full article: <?php echo esc_attr($post_title); ?>">
        <?php if ($ibof_post_thumb) : ?>
          <img src="<?php echo esc_url($ibof_post_thumb); ?>"
               alt="<?php echo esc_attr($post_title); ?>"
               class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
        <?php else : ?>
          <div class="absolute inset-0 bg-[#ff9101]/10 flex items-center justify-center">
            <svg class="w-12 h-12 text-[#ff9101]/40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
          </div>
        <?php endif; ?>
      </a>

      <div class="ibof-blog-body p-6 flex flex-col flex-1">
        <p class="ibof-blog-date text-[#ff9101] text-xs font-bold uppercase tracking-widest mb-2">
          <?php echo get_the_date('M j, Y'); ?>
        </p>
        <h3 class="ibof-blog-name text-gray-900 font-black text-lg leading-snug mb-3 flex-1">
          <a href="<?php the_permalink(); ?>"
             class="hover:text-[#ff9101] transition-colors duration-150"
             title="Read full article: <?php echo esc_attr($post_title); ?>">
            <?php echo esc_html($post_title); ?>
          </a>
        </h3>
        <a href="<?php the_permalink(); ?>"
           class="ibof-blog-read mt-auto inline-flex items-center gap-1.5 text-[#ff9101] font-bold text-sm uppercase tracking-widest hover:gap-3 transition-all duration-150"
           title="Read full article: <?php echo esc_attr($post_title); ?>">
          Read More
          <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
          </svg>
        </a>
      </div>

    </article>
  <?php
  endwhile;
  wp_reset_postdata();
endif;
?>
    </div>

  </div>
</section>

<div class="home-scrolling-logos waves">

  <?php
  $logos = [
    ['file' => 'logo-walker-bay.webp', 'alt' => 'Walker Bay'],
    ['file' => 'logo-ab.webp', 'alt' => 'AB Inflatables'],
    ['file' => 'logo-zodiac.webp', 'alt' => 'Zodiac Nautic'],
    ['file' => 'logo-achilles.webp', 'alt' => 'Achilles Inflatable Boats Australia'],
    ['file' => 'logo-inmar.webp', 'alt' => 'INMAR Inflatable Boats'],
    ['file' => 'logo-ranieri.webp', 'alt' => 'Ranieri International'],
  ];
  ?>

  <!-- Row 1 -->
  <div class="logo-row">
    <div class="logo-track">
      <?php foreach ($logos as $logo): ?>
        <img
          src="<?php echo get_template_directory_uri(); ?>/images/<?php echo $logo['file']; ?>"
          alt="<?php echo esc_attr($logo['alt']); ?>"
          loading="lazy"
          width="200"
          height="75"
        >
      <?php endforeach; ?>

      <!-- duplicate for seamless loop -->
      <?php foreach ($logos as $logo): ?>
        <img
          src="<?php echo get_template_directory_uri(); ?>/images/<?php echo $logo['file']; ?>"
          alt="<?php echo esc_attr($logo['alt']); ?>"
          loading="lazy"
          width="200"
          height="75"
        >
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Row 2 (reverse direction) -->
  <div class="logo-row reverse">
    <div class="logo-track">
      <?php foreach ($logos as $logo): ?>
        <img
          src="<?php echo get_template_directory_uri(); ?>/images/<?php echo $logo['file']; ?>"
          alt="<?php echo esc_attr($logo['alt']); ?>"
          loading="lazy"
          width="200"
          height="75"
        >
      <?php endforeach; ?>

      <?php foreach ($logos as $logo): ?>
        <img
          src="<?php echo get_template_directory_uri(); ?>/images/<?php echo $logo['file']; ?>"
          alt="<?php echo esc_attr($logo['alt']); ?>"
          loading="lazy"
          width="200"
          height="75"
        >
      <?php endforeach; ?>
    </div>
  </div>

</div>

<?php // echo do_shortcode('[instagram-feed feed=2]'); ?>

<?php get_footer(); ?>
