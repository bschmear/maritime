<?php
/**
 * Template Name: Locations
 */
get_header();
while (have_posts()) : the_post();
?>

<!-- ===== PAGE HERO ===== -->
<div class="loc-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden <?php echo !has_post_thumbnail() ? 'bg-[#111111]' : ''; ?>"
  <?php if (has_post_thumbnail()) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>

  <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <?php if (!has_post_thumbnail()) : ?>
  <div class="absolute inset-0 opacity-[0.04]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <?php endif; ?>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">Our Locations</span>
    </div>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>

<!-- ===== LOCATIONS GRID ===== -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <?php if (have_rows('location')) : ?>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
      <?php while (have_rows('location')) : the_row();

        $locs_url = get_sub_field('location_page');
        if (!$locs_url) continue;

        $locs_id = url_to_postid($locs_url);
        if (!$locs_id) continue;

        $locs_post = get_post($locs_id);
        if (!$locs_post) continue;

        $locs_name    = get_post_meta($locs_id, 'loc_name',    true);
        $locs_address = get_post_meta($locs_id, 'loc_address', true);
        $locs_city    = get_post_meta($locs_id, 'loc_city',    true);
        $locs_state   = get_post_meta($locs_id, 'loc_state',   true);
        $locs_phone   = get_post_meta($locs_id, 'loc_phone',   true);

        // Build hours snippet — first open day
        $locs_days = array(
          'Mon' => get_post_meta($locs_id, 'loc_mon', true),
          'Tue' => get_post_meta($locs_id, 'loc_tue', true),
          'Wed' => get_post_meta($locs_id, 'loc_wed', true),
          'Thu' => get_post_meta($locs_id, 'loc_thu', true),
          'Fri' => get_post_meta($locs_id, 'loc_fri', true),
          'Sat' => get_post_meta($locs_id, 'loc_sat', true),
          'Sun' => get_post_meta($locs_id, 'loc_sun', true),
        );
        $locs_open_days = array_filter($locs_days);
      ?>

      <article class="group bg-white rounded-md shadow-sm overflow-hidden border border-gray-100 hover:border-[#ff9101] hover:shadow-xl transition-all duration-300 flex flex-col">

        <!-- Image -->
        <div class="relative overflow-hidden bg-gray-100 flex-shrink-0" style="padding-top: 58%;">
          <a href="<?php echo esc_url($locs_url); ?>" class="absolute inset-0 block">
            <?php if (has_post_thumbnail($locs_id)) : ?>
              <img src="<?php echo esc_url(get_the_post_thumbnail_url($locs_id, 'large')); ?>"
                alt="<?php echo esc_attr(get_the_title($locs_id)); ?>"
                class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
            <?php else : ?>
              <div class="absolute inset-0 bg-gray-50 flex items-center justify-center">
                <svg class="w-14 h-14 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
              </div>
            <?php endif; ?>
          </a>

          <!-- Location name badge -->
          <?php if ($locs_name) : ?>
            <span class="absolute top-3 left-3 bg-[#ff9101] text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">
              <?php echo esc_html($locs_name); ?>
            </span>
          <?php endif; ?>
        </div>

        <!-- Card body -->
        <div class="flex flex-col flex-1 p-6">

          <h2 class="text-gray-900 font-black text-xl md:text-2xl leading-tight mb-5">
            <a href="<?php echo esc_url($locs_url); ?>" class="hover:text-[#ff9101] transition-colors duration-150">
              <?php echo esc_html(get_the_title($locs_id)); ?>
            </a>
          </h2>

          <div class="flex flex-col gap-4 flex-1">

            <!-- Address -->
            <?php if ($locs_address || $locs_city || $locs_state) : ?>
            <div class="flex items-start gap-3">
              <span class="flex-shrink-0 w-8 h-8 bg-[#ff9101]/10 flex items-center justify-center rounded-sm mt-0.5">
                <svg class="w-3.5 h-3.5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                  <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
              </span>
              <div class="text-gray-500 text-base leading-relaxed">
                <?php if ($locs_address) echo esc_html($locs_address).'<br>'; ?>
                <?php
                $locs_csz = '';
                if ($locs_city)  $locs_csz .= esc_html($locs_city);
                if ($locs_city && $locs_state) $locs_csz .= ', ';
                if ($locs_state) $locs_csz .= esc_html($locs_state);
                echo $locs_csz;
                ?>
              </div>
            </div>
            <?php endif; ?>

            <!-- Phone -->
            <?php if ($locs_phone) : ?>
            <div class="flex items-center gap-3">
              <span class="flex-shrink-0 w-8 h-8 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                <svg class="w-3.5 h-3.5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 8V5z"/>
                </svg>
              </span>
              <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9]/', '', $locs_phone)); ?>"
                class="text-gray-500 text-base font-semibold hover:text-[#ff9101] transition-colors duration-150">
                <?php echo esc_html($locs_phone); ?>
              </a>
            </div>
            <?php endif; ?>

            <!-- Hours snippet -->
            <?php if (!empty($locs_open_days)) :
              $locs_first_day = array_key_first($locs_open_days);
              $locs_last_day  = array_key_last($locs_open_days);
              $locs_first_hrs = $locs_open_days[$locs_first_day];
            ?>
            <div class="flex items-center gap-3">
              <span class="flex-shrink-0 w-8 h-8 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                <svg class="w-3.5 h-3.5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
              </span>
              <span class="text-gray-500 text-base">
                <?php echo esc_html($locs_first_day); ?>–<?php echo esc_html($locs_last_day); ?>
                <span class="font-semibold text-gray-700"><?php echo esc_html($locs_first_hrs); ?></span>
              </span>
            </div>
            <?php endif; ?>

          </div>

          <!-- CTA -->
          <div class="flex flex-col sm:flex-row gap-3 mt-6 pt-6 border-t border-gray-100">
            <a href="<?php echo esc_url($locs_url); ?>"
              class="flex-1 text-center bg-gray-900 hover:bg-[#ff9101] text-white font-bold text-xs uppercase tracking-widest px-5 py-3 transition-all duration-200">
              View Location
            </a>
            <?php
            $locs_addr_enc = urlencode(trim($locs_address.' '.$locs_city.' '.$locs_state));
            if ($locs_addr_enc) :
            ?>
            <a href="https://maps.apple.com/?saddr=My+Location&daddr=<?php echo $locs_addr_enc; ?>"
              target="_blank" rel="noopener"
              class="flex-1 text-center inline-flex items-center justify-center gap-2 border-2 border-gray-200 hover:border-[#ff9101] text-gray-500 hover:text-[#ff9101] font-bold text-xs uppercase tracking-widest px-5 py-3 transition-all duration-200">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
              </svg>
              Directions
            </a>
            <?php endif; ?>
          </div>

        </div>
      </article>

      <?php endwhile; ?>
    </div>

    <?php else : ?>

    <div class="flex flex-col items-center justify-center py-24 text-center">
      <svg class="w-16 h-16 text-gray-200 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
        <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
      </svg>
      <h2 class="text-gray-900 font-black text-2xl mb-3">No Locations Found</h2>
      <p class="text-gray-400 text-lg">Check back later for location updates.</p>
    </div>

    <?php endif; ?>

  </div>
</div>

<?php
endwhile;
wp_nav_menu(array('theme_location' => 'front-page-menu', 'container' => 'nav'));
get_footer();
?>