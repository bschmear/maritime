<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require '../../../wp-includes/PHPMailer/Exception.php';
require '../../../wp-includes/PHPMailer/PHPMailer.php';
require '../../../wp-includes/PHPMailer/SMTP.php';

include_once "../../../wp-load.php";

error_log("[Contact] POST received: name=" . ($_POST['name'] ?? '') . ", email=" . ($_POST['email'] ?? '') . ", phone=" . ($_POST['phone'] ?? ''));

$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".get_theme_mod('fg_recaptcha_secret_key')."&response=".$_POST['g-recaptcha-response']);
$responsekeys = json_decode($response);
error_log("[Contact] reCAPTCHA result: " . ($responsekeys->success ? 'PASS' : 'FAIL'));

if ($responsekeys->success) {
  if ($_POST['name'] != "" && $_POST['email'] != "" && $_POST['phone'] != "") {
    if ($_POST['username'] == "") {
      $mail = new PHPMailer();

    //  $mail->isSMTP();
      $mail->SMTPAuth = true;
      $mail->Username = get_theme_mod('fg_smtp_user');
      $mail->Password = get_theme_mod('fg_smtp_pass');
      $mail->Host = get_theme_mod('fg_smtp_host');
      $mail->Port = get_theme_mod('fg_smtp_port');
      $mail->SMTPDebug = 3;
      $mail->Debugoutput = function($str, $level){ error_log("[Contact Form] $str"); };

      error_log("[Contact] SMTP config: host=" . $mail->Host . ", user=" . $mail->Username . ", port=" . $mail->Port);

      $mail->setFrom(get_theme_mod('fg_smtp_user'), get_post_meta($_POST['id'], 'form_from_name', true));
      $mail->addReplyTo($_POST['email']);

      $emails = [
        'info@inflatableboatsofflorida.com',
        'nathan.ibof@gmail.com'
      ];

      foreach ($emails as $email) {
        $mail->addAddress($email);
      }

      $mail->Subject = get_post_meta($_POST['id'], 'form_subject', true);
      error_log("[Contact] Subject: " . $mail->Subject . " | Recipients: " . implode(', ', array_column($mail->getToAddresses(), 0)));

      $mail->addBCC('bjschmear@gmail.com');

      $Message = $_POST['name']."\n";
      $Message .= $_POST['email']."\n";
      $Message .= $_POST['phone']."\n\n";
      $Message .= $_POST['message'] . "\n";
      $Message = stripslashes($Message);

      $mail->Body = $Message;

      $email_sent = false;
      try {
        $sent = $mail->send();
        $email_sent = $sent ? true : false;
        error_log("[Contact] mail->send() returned: " . ($sent ? 'true' : 'false'));
      } catch (Exception $e) {
        error_log("[Contact] PHPMailer exception: " . $e->getMessage() . " | ErrorInfo: " . $mail->ErrorInfo);
      }

      // Store in database as backup
      date_default_timezone_set('America/New_York');
      global $wpdb;
      $result = $wpdb->insert('contact_submissions',
        array(
          'name' => $_POST['name'],
          'email' => $_POST['email'],
          'phone' => $_POST['phone'],
          'message' => $_POST['message'],
          'date_submitted' => date("Y-m-d H:i:s"),
          'email_sent' => $email_sent ? 1 : 0
        )
      );
      error_log("[Contact] Database insert result: " . ($result ? 'SUCCESS' : 'FAILED - ' . $wpdb->last_error));

      // Add to MailChimp
      $mcdata = array(
        'email'  => $_POST['email'],
        'status' => 'subscribed',
        'firstname' => $_POST['name'],
        'phone' => $_POST['phone']
      );

      function syncMailchimp($mcdata) {
        $memberId = md5(strtolower($mcdata['email']));
        $dataCenter = substr(get_theme_mod('fg_mailchimp_api'),strpos(get_theme_mod('fg_mailchimp_api'),'-')+1);
        $url = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . get_theme_mod('fg_mailchimp_list_id') . '/members/' . $memberId;

        $json = json_encode(array(
          'email_address' => $mcdata['email'],
          'status'        => $mcdata['status'],
          'merge_fields'  => [
            'FNAME' => $mcdata['firstname'],
            'PHONE' => $mcdata['phone']
          ]
        ));

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_USERPWD, 'user:' . get_theme_mod('fg_mailchimp_api'));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $httpCode;
      }

      syncMailchimp($mcdata);
      
      $feedback = get_post_meta($_POST['id'], 'form_success', true);
      error_log("[Contact] Done. Feedback: " . $feedback);
    } // Honeypot
  } else {
    $feedback = "Some required information is missing! Please go back and make sure all required fields are filled.";
    error_log("[Contact] Required fields missing.");
  } // Required fields

  echo $feedback;
} else {
  error_log("[Contact] reCAPTCHA failed.");
} // reCAPTCHA
?>
