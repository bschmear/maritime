<?php
// Don't send emails when Wordpress updates happen
add_filter('auto_core_update_send_email', 'stop_auto_update_emails', 10, 4);
function stop_update_emails($send, $type, $core_update, $result) {
  if (!empty($type) && $type == 'success') return false;
  return true;
}
add_filter('auto_plugin_update_send_email', '__return_false');
add_filter('auto_theme_update_send_email', '__return_false');


// Order blog posts newest to oldest
add_action('pre_get_posts', 'order_blog_posts_newest_first');
function order_blog_posts_newest_first($query) {
  // Only modify the main query on the blog/index page
  if ($query->is_main_query() && (is_home() || is_archive())) {
    $query->set('orderby', 'date');
    $query->set('order', 'DESC');
  }
}


// Remove emojis (and other crud)
add_action('init', 'disable_wp_emojicons');
function disable_wp_emojicons() {
  remove_action('admin_print_styles', 'print_emoji_styles');
  remove_action('wp_head', 'print_emoji_detection_script', 7);
  remove_action('admin_print_scripts', 'print_emoji_detection_script');
  remove_action('wp_print_styles', 'print_emoji_styles');
  remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
  remove_filter('the_content_feed', 'wp_staticize_emoji');
  remove_filter('comment_text_rss', 'wp_staticize_emoji');
  add_filter('emoji_svg_url', '__return_false');
  add_filter('tiny_mce_plugins', 'disable_emojicons_tinymce');

  remove_action('wp_head', 'rsd_link');
  remove_action('wp_head', 'wlwmanifest_link');
  remove_action('wp_head', 'wp_generator');
  remove_action('wp_head', 'start_post_rel_link');
  remove_action('wp_head', 'index_rel_link');
  remove_action('wp_head', 'adjacent_posts_rel_link');
}

function disable_emojicons_tinymce($plugins) {
  if (is_array($plugins)) {
    return array_diff($plugins, array('wpemoji'));
  } else {
    return array();
  }
}


add_action('wp_head', 'meta_og', 5);
function meta_og() {
  global $post;

  $img_src = array(); // initialize variable

  if (is_singular() && isset($post) && has_post_thumbnail($post->ID)) {
      $img_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');
  }

  $ogimg = (!empty($img_src[0])) ? $img_src[0] : get_template_directory_uri() . "/images/logo.webp";

  $excerpt = (isset($post) && isset($post->post_content)) ? strip_tags($post->post_content) : '';
  $excerpt_more = '';
  if (strlen($excerpt ) > 155) {
    $excerpt = substr($excerpt,0,155);
    $excerpt_more = ' ...';
  }
  $excerpt = str_replace('"', '', $excerpt);
  $excerpt = str_replace("'", '', $excerpt);
  $excerptwords = preg_split('/[\n\r\t ]+/', $excerpt, -1, PREG_SPLIT_NO_EMPTY);
  array_pop($excerptwords);
  $excerpt = implode(' ', $excerptwords) . $excerpt_more;
  ?>

  <meta name="author" content="<?php bloginfo('name'); ?>">
  <meta name="description" content="<?php echo $excerpt; ?>">
  <meta property="og:title" content="<?php echo get_bloginfo('name'); if(!is_home() || !is_front_page()) wp_title('|', true, 'left'); ?>">
  <meta property="og:description" content="<?php echo $excerpt; ?>">
  <meta property="og:type" content="article">
  <meta property="og:url" content="<?php echo the_permalink(); ?>">
  <meta property="og:site_name" content="<?php bloginfo('name'); ?>">
  <meta property="og:image" content="<?php echo $ogimg; ?>">
  <?php
}


/* Disable WordPress Admin Bar for all users */
add_filter('show_admin_bar', '__return_false');


// Enqueue scripts and styles
add_action('wp_enqueue_scripts', 'my_styles');
function my_styles() {
  wp_enqueue_style('style', get_template_directory_uri() . '/style.css', array(), filemtime(get_template_directory() . '/style.css'));
}


// Define menus
add_action('init', 'register_my_menus');
function register_my_menus() {
  register_nav_menus(
    array(
      'top-menu' => __('Top Menu'),
      'main-menu' => __('Main Menu'),
      'location-menu' => __('Location Menu'),
      'footer-menu' => __('Footer Menu'),
      'front-page-menu' => __('Front Page Menu')
    )
  );
}


// Register Widgets
add_action('widgets_init', 'footer_logos');
function footer_logos() {
  register_sidebar(array(
    "name" => "Footer Locations",
    "id" => "footer-locations",
    "before_widget" => "",
    "after_widget" => "\n",
  ));
}

# remove automatically added empty paragraph from wp widget sidebar
remove_filter('widget_text_content', 'wpautop');


// We want Featured Images on Pages and Posts
add_theme_support('post-thumbnails');


// Don't resize Featured Images
add_action('after_setup_theme', 'my_thumbnail_size', 11);
function my_thumbnail_size() {
  set_post_thumbnail_size();
}


// Don't wrap images in P tags
add_filter('the_content', 'filter_ptags_on_images');
function filter_ptags_on_images($content){
  return preg_replace('/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(<\/a>)?\s*<\/p>/iU', '\1\2\3', $content);
}


// Wrap video embed code in DIV for responsive goodness
add_filter('embed_oembed_html', 'my_oembed_filter', 10, 4);
function my_oembed_filter($html, $url, $attr, $post_ID) {
  $return = '<div class="video">'.$html.'</div>';
  return $return;
}


// Custom excerpt
function fg_excerpt($limit, $more = '') {
  return wp_trim_words(strip_shortcodes(get_the_content()), $limit, $more);
}

function wp_first_paragraph_excerpt($id=null) {
  // Set $id to the current post by default
  if(!$id) {
    global $post;
    $id = get_the_id();
  }

  // Get the post content
  $content = get_post_field('post_content', $id);
  $content = apply_filters('the_content', strip_shortcodes($content));

  // Remove all tags, except paragraphs
  $excerpt = strip_tags($content, '<p></p>');

  // Remove empty paragraph tags
  $excerpt = force_balance_tags($excerpt);
  $excerpt = preg_replace('#<p>\s*+(<br\s*/*>)?\s*</p>#i', '', $excerpt);
  $excerpt = preg_replace('~\s?<p>(\s|&nbsp;)+</p>\s?~', '', $excerpt);

  // Get the first paragraph
  $excerpt = substr($excerpt, 0, strpos($excerpt, '</p>') + 4);

  // Remove remaining paragraph tags
  $excerpt = strip_tags($excerpt);

  return $excerpt;
}


/* Lowers the metabox priority to 'core' for Yoast SEO's metabox. */
add_filter('wpseo_metabox_prio', 'lower_yoast_metabox_priority');
function lower_yoast_metabox_priority($priority) {
  return 'low';
}


/* Customizer */
add_action('customize_register', 'fg_customize_register', 50);
remove_action('customize_register', 'shiftnav_register_customizers');
function fg_customize_register($wp_customize) {
  $wp_customize->remove_section('title_tagline');
  $wp_customize->remove_section('static_front_page');
  $wp_customize->remove_section('custom_css');
  $wp_customize->remove_panel('nav_menus'); // Put "50" in the add_action!
  $wp_customize->remove_panel('widgets');

  $wp_customize->add_section('fg_social_media', array(
    'title'    => __('Social Media', 'fg'),
    'priority' => 112
  ));

  $wp_customize->add_setting('fg_instagram', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_instagram', array(
    'label'   => __('Instagram', 'social'),
    'section' => 'fg_social_media',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('fg_facebook', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_facebook', array(
    'label'   => __('Facebook', 'social'),
    'section' => 'fg_social_media',
    'type'    => 'text'
  ));

  $wp_customize->add_section('fg_apis', array(
    'title'    => __('APIs', 'fg'),
    'priority' => 113
  ));

  $wp_customize->add_setting('fg_recaptcha_site_key', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_recaptcha_site_key', array(
    'label'   => __('reCAPTCHA Site Key', 'api'),
    'section' => 'fg_apis',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('fg_recaptcha_secret_key', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_recaptcha_secret_key', array(
    'label'   => __('reCAPTCHA Secret Key', 'api'),
    'section' => 'fg_apis',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('fg_mailchimp_api', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_mailchimp_api', array(
    'label'   => __('MailChimp API', 'api'),
    'section' => 'fg_apis',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('fg_mailchimp_list_id', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_mailchimp_list_id', array(
    'label'   => __('MailChimp List ID', 'api'),
    'section' => 'fg_apis',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('fg_api_notes');
  $wp_customize->add_control('fg_api_notes', array(
    'label'   => __('Notes', 'api'),
    'section' => 'fg_apis',
    'type'    => 'textarea'
  ));

  $wp_customize->add_section('fg_smtp', array(
    'title'    => __('SMTP', 'fg'),
    'description' => 'Settings for the forms to send emails. Don\'t change these unless you REALLY know what you\'re doing.',
    'priority' => 113
  ));

  $wp_customize->add_setting('fg_smtp_user', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_smtp_user', array(
    'label'   => __('Username', 'smtp'),
    'section' => 'fg_smtp',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('fg_smtp_pass', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_smtp_pass', array(
    'label'   => __('Password', 'smtp'),
    'section' => 'fg_smtp',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('fg_smtp_host', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_smtp_host', array(
    'label'   => __('Host', 'smtp'),
    'section' => 'fg_smtp',
    'type'    => 'text'
  ));

  $wp_customize->add_setting('fg_smtp_port', array('sanitize_callback' => 'sanitize_text_field'));
  $wp_customize->add_control('fg_smtp_port', array(
    'label'   => __('Port', 'smtp'),
    'section' => 'fg_smtp',
    'type'    => 'text'
  ));
}


// Page Slug Body Class
add_filter('body_class', 'add_slug_body_class');
function add_slug_body_class($classes) {
  global $post;
  if (isset($post)) $classes[] = $post->post_name;
  return $classes;
}


/*
*  HOME PAGE
*/
add_filter('user_can_richedit', 'disable_homepage_visual_editor');

function disable_homepage_visual_editor($can) {
    global $post;

    // Make sure $post exists and has an ID
    if (isset($post) && is_object($post) && isset($post->ID)) {
        if ($post->ID == get_option('page_on_front')) {
            return false;
        }
    }

    return $can;
}

add_action('add_meta_boxes_page', 'homepage_metaboxes');
function homepage_metaboxes($post) {
  if ($post->ID == get_option('page_on_front')) :
    add_meta_box('homepage_metabox_video',
      'Featured Video',
      'display_homepage_metabox_video',
      'page', 'normal'
    );
  endif;
}

function display_homepage_metabox_video($post) {
  ?>
  <style>
    .buttonfield { display: flex; align-items: flex-start; width: 100%; padding-bottom: 0.5em; }
    .buttonfield  INPUT[type="text"] { width: 100%; }
    .buttonfield .button { margin-left: 1em; }
  </style>

  <div class="buttonfield">
    <input type="text" name="homepage_video" value="<?php echo $post->homepage_video; ?>" placeholder="Video URL" id="homepage_video">
    <input type="button" id="homepage_video_button" class="button" value="Add/Edit Video">
  </div>

  If a video is set, it will display instead of the Featured Image.

  <script>
    function addFile($file_id) {
      var send_attachment_bkp = wp.media.editor.send.attachment;
      wp.media.editor.send.attachment = function(props, attachment) {
        jQuery($file_id).val(attachment.url);
        wp.media.editor.send.attachment = send_attachment_bkp;
      }
      wp.media.editor.open();
      return false;
    }

    jQuery('#homepage_video_button').click(function(){ addFile("#homepage_video");});
  </script>
  <?php
}

add_action('save_post', 'homepage_save');
function homepage_save($post_id) {
  if ($post_id != get_option('page_on_front')) return;

  if (!empty($_POST['homepage_video'])) {
    update_post_meta($post_id, 'homepage_video', $_POST['homepage_video']);
  } else {
    delete_post_meta($post_id, 'homepage_video');
  }
}


/*
*  Boats
*/
add_action('init', 'boats');
function boats() {
  register_post_type('boats', array(
      'labels' => array(
        'name' => 'Boats',
        'singular_name' => 'Boat',
        'add_new_item' => 'Add New Boat',
        'edit_item' => 'Edit Boat',
        'search_items' => 'Search Boats',
        'not_found' => 'No Boats found'
      ),
      'show_ui' => true,
      'menu_position' => 53,
      'menu_icon' => 'dashicons-palmtree',
      'supports' => array('title', 'editor'),
      'taxonomies' => array('type','make','location'),
      'has_archive' => 'boats',
      'public' => true,
      'exclude_from_search' => false,
      'publicly_queryable' => true,
      'show_in_nav_menus' => true
  ));
}


/*
*  Careers
*/
add_action('init', 'careers');
function careers() {
  register_post_type('careers', array(
      'labels' => array(
        'name' => 'Careers',
        'singular_name' => 'Career',
        'add_new_item' => 'Add New Career',
        'edit_item' => 'Edit Career',
        'new_item' => 'New Career',
        'view_item' => 'View Career',
        'view_items' => 'View Careers',
        'search_items' => 'Search Careers',
        'not_found' => 'No careers found',
        'not_found_in_trash' => 'No careers found in trash',
        'all_items' => 'All Careers',
        'archives' => 'Careers',
        'menu_name' => 'Careers',
      ),
      'description' => 'Job openings and career opportunities',
      'public' => true,
      'exclude_from_search' => false,
      'publicly_queryable' => true,
      'show_ui' => true,
      'show_in_nav_menus' => true,
      'show_in_admin_bar' => true,
      'show_in_rest' => true,
      'menu_position' => 54,
      'menu_icon' => 'dashicons-businessperson',
      'capability_type' => 'post',
      'map_meta_cap' => true,
      'hierarchical' => false,
      'supports' => array('title', 'editor', 'custom-fields'),
      'taxonomies' => array('career_location'),
      'has_archive' => false,
      'rewrite' => array(
        'slug' => 'careers',
        'with_front' => false,
      ),
      'query_var' => 'careers',
  ));
}

add_action('init', 'careers_create_taxonomy');
function careers_create_taxonomy() {
  register_taxonomy('career_location', 'careers', array(
    'labels' => array(
      'name' => 'Career Locations',
      'singular_name' => 'Career Location',
      'search_items' => 'Search Locations',
      'all_items' => 'All Locations',
      'edit_item' => 'Edit Location',
      'update_item' => 'Update Location',
      'add_new_item' => 'Add New Location',
      'new_item_name' => 'New Location Name',
      'menu_name' => 'Locations',
    ),
    'hierarchical' => true,
    'show_admin_column' => true,
    'show_in_nav_menus' => false,
    'show_in_rest' => true,
    'rewrite' => array(
      'slug' => 'career-location',
      'with_front' => false,
    ),
    'public' => true,
  ));
}

function ibof_get_career_title($post_id = null) {
  $post_id = $post_id ?: get_the_ID();
  return get_the_title($post_id);
}

function ibof_get_career_description($post_id = null) {
  $post_id = $post_id ?: get_the_ID();
  $description = function_exists('get_field') ? get_field('description', $post_id) : '';
  if ($description) {
    return apply_filters('the_content', $description);
  }
  return apply_filters('the_content', get_post_field('post_content', $post_id));
}

function ibof_get_career_location_names($post_id = null) {
  $post_id = $post_id ?: get_the_ID();
  $names = array();
  $seen = array();

  $add_term = function ($term) use (&$names, &$seen) {
    if ($term instanceof WP_Term && !is_wp_error($term)) {
      if (empty($seen[$term->term_id])) {
        $seen[$term->term_id] = true;
        $names[] = $term->name;
      }
      return;
    }

    if (is_numeric($term)) {
      $resolved = get_term((int) $term, 'location');
      if ($resolved && !is_wp_error($resolved) && empty($seen[$resolved->term_id])) {
        $seen[$resolved->term_id] = true;
        $names[] = $resolved->name;
      }
    }
  };

  $location = function_exists('get_field') ? get_field('location', $post_id) : null;

  if ($location instanceof WP_Term) {
    $add_term($location);
  } elseif (is_array($location)) {
    foreach ($location as $item) {
      $add_term($item);
    }
  } elseif (is_numeric($location)) {
    $add_term($location);
  }

  $terms = get_the_terms($post_id, 'career_location');
  if (!empty($terms) && !is_wp_error($terms)) {
    foreach ($terms as $term) {
      $add_term($term);
    }
  }

  return $names;
}

function ibof_get_career_location_name($post_id = null, $separator = ', ') {
  return implode($separator, ibof_get_career_location_names($post_id));
}

function ibof_acf_user_to_email($value) {
  if ($value instanceof WP_User) {
    return is_email($value->user_email) ? $value->user_email : '';
  }

  if (is_numeric($value)) {
    $user = get_userdata((int) $value);
    return ($user && is_email($user->user_email)) ? $user->user_email : '';
  }

  if (!is_array($value)) {
    return '';
  }

  if (!empty($value['user_email']) && is_email($value['user_email'])) {
    return $value['user_email'];
  }

  if (!empty($value['ID'])) {
    return ibof_acf_user_to_email((int) $value['ID']);
  }

  foreach ($value as $item) {
    $email = ibof_acf_user_to_email($item);
    if ($email !== '') {
      return $email;
    }
  }

  return '';
}

function ibof_normalize_email_value($value) {
  if (is_array($value)) {
    foreach ($value as $item) {
      $normalized = ibof_normalize_email_value($item);
      if ($normalized !== '') {
        return $normalized;
      }
    }
    return '';
  }

  if (!is_string($value)) {
    return '';
  }

  $value = trim($value);
  return is_email($value) ? $value : '';
}

function ibof_get_career_recipient_email($post_id = null) {
  $post_id = $post_id ?: get_the_ID();
  $recipient = function_exists('get_field') ? get_field('recipient_email', $post_id) : null;

  if ($recipient === '' || $recipient === null) {
    $recipient = get_post_meta($post_id, 'recipient_email', true);
  }

  $email = ibof_acf_user_to_email($recipient);
  if ($email !== '') {
    return $email;
  }

  return ibof_normalize_email_value($recipient);
}

function ibof_career_is_active($post_id = null) {
  $post_id = $post_id ?: get_the_ID();
  if (!function_exists('get_field')) {
    return true;
  }

  $active = get_field('active', $post_id);
  if ($active === null || $active === '') {
    return true;
  }

  return (bool) $active;
}

function ibof_get_careers_page_url() {
  $page = get_page_by_path('careers');
  if ($page && $page->post_status === 'publish' && get_page_template_slug($page->ID) === 'template-careers.php') {
    return get_permalink($page->ID);
  }

  $pages = get_pages(array(
    'meta_key'   => '_wp_page_template',
    'meta_value' => 'template-careers.php',
    'number'     => 1,
  ));

  if (!empty($pages)) {
    return get_permalink($pages[0]->ID);
  }

  return home_url('/careers/');
}

add_action('template_redirect', 'ibof_careers_archive_redirect');
function ibof_careers_archive_redirect() {
  if (!is_post_type_archive('careers')) {
    return;
  }

  wp_safe_redirect(ibof_get_careers_page_url(), 301);
  exit;
}

add_action('init', 'ibof_careers_check_rewrite_flush', 21);
function ibof_careers_check_rewrite_flush() {
  if (get_option('ibof_careers_rewrite_flushed') !== '2') {
    flush_rewrite_rules(false);
    update_option('ibof_careers_rewrite_flushed', '2');
  }
}

add_action('add_meta_boxes', 'ibof_careers_page_manage_box');
function ibof_careers_page_manage_box() {
  add_meta_box(
    'ibof_careers_manage',
    'Career Listings',
    'ibof_careers_page_manage_box_render',
    'page',
    'side',
    'high'
  );
}

function ibof_careers_page_manage_box_render($post) {
  $template = get_page_template_slug($post->ID);

  if ($template !== 'template-careers.php') {
    echo '<p class="description">Select the <strong>Careers</strong> template and update this page to manage job listings here.</p>';
    return;
  }

  $manage_url = admin_url('edit.php?post_type=careers');
  $add_url    = admin_url('post-new.php?post_type=careers');
  ?>
  <p>Job openings on this page are managed as <strong>Careers</strong> posts — not in the page editor.</p>
  <p>
    <a href="<?php echo esc_url($manage_url); ?>" class="button button-primary button-large" style="width:100%;text-align:center;margin-bottom:8px;">
      Careers are managed here
    </a>
  </p>
  <p>
    <a href="<?php echo esc_url($add_url); ?>" class="button button-large" style="width:100%;text-align:center;">
      Add New Career
    </a>
  </p>
  <?php
}

add_action('edit_form_after_title', 'ibof_careers_page_edit_notice');
function ibof_careers_page_edit_notice($post) {
  if (!$post || $post->post_type !== 'page') {
    return;
  }

  if (get_page_template_slug($post->ID) !== 'template-careers.php') {
    return;
  }

  $manage_url = admin_url('edit.php?post_type=careers');
  ?>
  <div class="notice notice-info" style="margin:12px 0 20px;padding:12px 16px;">
    <p style="margin:0;">
      <strong>Careers landing page:</strong>
      Openings are managed under
      <a href="<?php echo esc_url($manage_url); ?>">Careers &rarr; All Careers</a>
      in the admin menu.
      <a href="<?php echo esc_url(admin_url('post-new.php?post_type=careers')); ?>" class="button button-small" style="margin-left:8px;vertical-align:middle;">Add New Career</a>
    </p>
  </div>
  <?php
}

add_action('pre_get_posts', 'ibof_careers_archive_query');
function ibof_careers_archive_query($query) {
  if (is_admin() || !$query->is_main_query()) {
    return;
  }

  if (!$query->is_post_type_archive('careers') && !$query->is_tax('career_location')) {
    return;
  }

  $query->set('meta_query', array(
    'relation' => 'OR',
    array(
      'key' => 'active',
      'compare' => 'NOT EXISTS',
    ),
    array(
      'key' => 'active',
      'value' => '1',
      'compare' => '=',
    ),
    array(
      'key' => 'active',
      'value' => 1,
      'compare' => '=',
    ),
  ));
}

add_action('after_switch_theme', 'careers_flush_rewrite_rules');
function careers_flush_rewrite_rules() {
  careers();
  careers_create_taxonomy();
  flush_rewrite_rules();
}

/**
 * Locations Custom Post Type
 */
// Register Team Members Post Type
add_action('init', 'register_team_members_post_type');
function register_team_members_post_type() {
  register_post_type('teammember', array(
      'labels' => array(
        'name' => 'Team Members',
        'singular_name' => 'Team Member',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Team Member',
        'edit_item' => 'Edit Team Member',
        'new_item' => 'New Team Member',
        'view_item' => 'View Team Member',
        'view_items' => 'View Team Members',
        'search_items' => 'Search Team Members',
        'not_found' => 'No team members found',
        'not_found_in_trash' => 'No team members found in trash',
        'all_items' => 'All Team Members',
        'archives' => 'Team Member Archives',
        'attributes' => 'Team Member Attributes',
        'insert_into_item' => 'Insert into team member',
        'uploaded_to_this_item' => 'Uploaded to this team member',
        'featured_image' => 'Profile Photo',
        'set_featured_image' => 'Set profile photo',
        'remove_featured_image' => 'Remove profile photo',
        'use_featured_image' => 'Use as profile photo',
        'menu_name' => 'Team Members'
      ),
      'description' => 'Team members for the company',
      'public' => true,
      'exclude_from_search' => false,
      'publicly_queryable' => true,
      'show_ui' => true,
      'show_in_nav_menus' => true,
      'show_in_admin_bar' => true,
      'show_in_rest' => true,
      'menu_position' => 25,
      'menu_icon' => 'dashicons-groups',
      'capability_type' => 'post',
      'map_meta_cap' => true,
      'hierarchical' => false,
      'supports' => array(
        'title',
        'editor',
        'thumbnail',
        'excerpt',
        'custom-fields',
        'page-attributes'
      ),
      'has_archive' => 'team',
      'rewrite' => array(
        'slug' => 'team',
        'with_front' => false
      ),
      'query_var' => 'teammember'
  ));
}

// Set boats categories
add_action('init', 'boats_create_taxonomy');
function boats_create_taxonomy() {
  register_taxonomy('type', 'boats', array(
    'labels' => array('name' => 'Types', 'singular_name' => 'Type'),
    'hierarchical' => true,
    'show_admin_column' => true,
    'show_in_nav_menus' => false,
    'rewrite' => array('slug' => 'type'),
    'public' => true
  ));

  register_taxonomy('make', 'boats', array(
    'labels' => array('name' => 'Makes', 'singular_name' => 'Make'),
    'hierarchical' => true,
    'show_admin_column' => true,
    'show_in_nav_menus' => false,
    'rewrite' => array('slug' => 'make'),
    'public' => true
  ));

  register_taxonomy('location', 'boats', array(
    'labels' => array('name' => 'Locations', 'singular_name' => 'Location'),
    'hierarchical' => true,
    'show_admin_column' => true,
    'show_in_nav_menus' => false,
    'rewrite' => array('slug' => 'location'),
    'public' => true
  ));
}

// Load the correct template for taxonomy pages
add_filter('template_include', 'boats_make_template');
function boats_make_template($template) {
    // If viewing the 'make' taxonomy
    if (is_tax('make')) {
        $queried_object = get_queried_object();

        // If it's a specific term, load the individual make template
        if ($queried_object && $queried_object instanceof WP_Term) {
            $new_template = locate_template('template-boats-by-make.php');
        } else {
            // If it's the taxonomy archive, load the makes index template
            $new_template = locate_template('template-boats-makes.php');
        }

        if ($new_template) {
            return $new_template;
        }
    }

    return $template;
}

// Add custom rewrite rule for make taxonomy index
add_action('init', 'boats_make_rewrite_rule');
function boats_make_rewrite_rule() {
    add_rewrite_rule(
        '^make/?$',
        'index.php?make_index=1',
        'top'
    );
}

// Register custom query var
add_filter('query_vars', 'boats_make_query_vars');
function boats_make_query_vars($vars) {
    $vars[] = 'make_index';
    return $vars;
}

// Handle the make index page
add_action('template_redirect', 'boats_make_index_template');
function boats_make_index_template() {
    if (get_query_var('make_index')) {
        $template = locate_template('template-boats-makes.php');
        if ($template) {
            include($template);
            exit;
        }
    }
}

// Flush rewrite rules on theme activation
add_action('after_switch_theme', 'boats_flush_rewrite_rules');
function boats_flush_rewrite_rules() {
    flush_rewrite_rules();
}

// Flush rewrite rules when taxonomy is registered
add_action('init', 'boats_check_taxonomy_flush', 20);
function boats_check_taxonomy_flush() {
    if (get_option('boats_taxonomy_flushed') !== '1') {
        flush_rewrite_rules();
        update_option('boats_taxonomy_flushed', '1');
    }
}

// Enqueue Tailwind CSS
add_action('wp_enqueue_scripts', 'ibof_enqueue_styles');
function ibof_enqueue_styles() {
    // Enqueue compiled Tailwind CSS
    wp_enqueue_style('ibof-tailwind', get_template_directory_uri() . '/tailwind.css', array(), '1.0.0');

    // Enqueue theme styles (your custom styles)
    wp_enqueue_style('ibof-style', get_stylesheet_uri(), array('ibof-tailwind'), '1.0.0');
}


add_action('make_add_form_fields', 'add_term_images', 10, 2);
function add_term_images($taxonomy) {
  wp_enqueue_media();
  ?>
  <div class="form-field term-logo">
    <label for="">Category Logo</label>
    <input type="text" name="tax_logo" id="tax_logo" value="" style="width: 77%">
    <input type="button" id="tax_logo_btn" class="button" value="Add Image" />
  </div>

  <div class="form-field term-image">
    <label for="">Category Image</label>
    <input type="text" name="tax_image" id="tax_image" value="" style="width: 77%">
    <input type="button" id="tax_image_btn" class="button" value="Add Image" />
  </div>

  <script>
    jQuery(document).ready(function($){
      var meta_image_frame;
      var bid = "";

      $('#tax_logo_btn,#tax_image_btn').click(function(e){
        e.preventDefault();

        bid = $(this).attr("id").substring(0,$(this).attr("id").length -4);

        if (meta_image_frame) {
          meta_image_frame.open();
          return;
        }

        // Sets up the media library frame
        meta_image_frame = wp.media.frames.meta_image_frame = wp.media({
          title: "Upload an Image",
          button: { text:  "Use This Image" },
          library: { type: 'image' }
        });

        // Runs when an image is selected.
        meta_image_frame.on('select', function(){
          var media_attachment = meta_image_frame.state().get('selection').first().toJSON();
          $('#'+bid).val(media_attachment.url);
        });

        meta_image_frame.open();
      });

    });
  </script>
  <?php
}

add_action('make_edit_form_fields', 'edit_term_images', 10, 4);
function edit_term_images($term, $taxonomy) {
  wp_enqueue_media();
  ?>
  <tr class="form-field">
    <th scope="row">
      <label for="">Category Logo</label>
    </th>
    <td>
      <input type="text" name="tax_logo" id="tax_logo" value="<?php echo get_term_meta($term->term_id, 'tax_logo', true); ?>" style="width: 77%">
      <input type="button" id="tax_logo_btn" class="button" value="Add Image" />
    </td>
  </tr>

  <tr class="form-field">
    <th scope="row">
      <label for="">Category Image</label>
    </th>
    <td>
      <input type="text" name="tax_image" id="tax_image" value="<?php echo get_term_meta($term->term_id, 'tax_image', true); ?>" style="width: 77%">
      <input type="button" id="tax_image_btn" class="button" value="Add Image" />
    </td>
  </tr>

  <script>
    jQuery(document).ready(function($){
      var meta_image_frame;
      var bid = "";

      $('#tax_logo_btn,#tax_image_btn').click(function(e){
        e.preventDefault();

        bid = $(this).attr("id").substring(0,$(this).attr("id").length -4);

        if (meta_image_frame) {
          meta_image_frame.open();
          return;
        }

        // Sets up the media library frame
        meta_image_frame = wp.media.frames.meta_image_frame = wp.media({
          title: "Upload an Image",
          button: { text:  "Use This Image" },
          library: { type: 'image' }
        });

        // Runs when an image is selected.
        meta_image_frame.on('select', function(){
          var media_attachment = meta_image_frame.state().get('selection').first().toJSON();
          $('#'+bid).val(media_attachment.url);
        });

        meta_image_frame.open();
      });

    });
  </script>
  <?php
}

add_action('created_make', 'save_term_images', 10, 2);
add_action('edited_make', 'save_term_images', 10, 2);
function save_term_images($term_id, $tt_id) {
  if (!empty($_POST['tax_logo'])) {
    update_term_meta($term_id, 'tax_logo', $_POST['tax_logo']);
  } else {
    delete_term_meta($term_id, 'tax_logo');
  }

  if (!empty($_POST['tax_image'])) {
    update_term_meta($term_id, 'tax_image', $_POST['tax_image']);
  } else {
    delete_term_meta($term_id, 'tax_image');
  }
}

// Boats admin index page
add_action('admin_head', 'boats_remove_date_filter');
function boats_remove_date_filter() {
  if (get_post_type() == 'boats') add_filter('months_dropdown_results', '__return_empty_array');
}

// Add boats categories filter
add_action('restrict_manage_posts', 'boats_filter_by_type');
function boats_filter_by_type() {
  global $typenow;
  $post_type = 'boats'; // change to your post type
  $taxonomy  = 'type'; // change to your taxonomy
  if ($typenow == $post_type) {
    $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
    $info_taxonomy = get_taxonomy($taxonomy);
    wp_dropdown_categories(array(
      'show_option_all' => __("Show All {$info_taxonomy->label}"),
      'taxonomy'        => $taxonomy,
      'name'            => $taxonomy,
      'orderby'         => 'name',
      'selected'        => $selected,
      'show_count'      => true,
      'hide_empty'      => true,
    ));
  };
}

add_action('restrict_manage_posts', 'boats_filter_by_make');
function boats_filter_by_make() {
  global $typenow;
  $post_type = 'boats'; // change to your post type
  $taxonomy  = 'make'; // change to your taxonomy
  if ($typenow == $post_type) {
    $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
    $info_taxonomy = get_taxonomy($taxonomy);
    wp_dropdown_categories(array(
      'show_option_all' => __("Show All {$info_taxonomy->label}"),
      'taxonomy'        => $taxonomy,
      'name'            => $taxonomy,
      'orderby'         => 'name',
      'selected'        => $selected,
      'show_count'      => true,
      'hide_empty'      => true,
    ));
  };
}

add_action('restrict_manage_posts', 'boats_filter_by_location');
function boats_filter_by_location() {
  global $typenow;
  $post_type = 'boats'; // change to your post type
  $taxonomy  = 'location'; // change to your taxonomy
  if ($typenow == $post_type) {
    $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
    $info_taxonomy = get_taxonomy($taxonomy);
    wp_dropdown_categories(array(
      'show_option_all' => __("Show All {$info_taxonomy->label}"),
      'taxonomy'        => $taxonomy,
      'name'            => $taxonomy,
      'orderby'         => 'name',
      'selected'        => $selected,
      'show_count'      => true,
      'hide_empty'      => true,
    ));
  };
}

add_action('restrict_manage_posts', 'boats_filter_by_featured');
function boats_filter_by_featured() {
  global $typenow;
  if ($typenow == 'boats') {
    echo '<select name="featured" class="postform">'."\n";
      echo '<option value="all"';
      if (isset($_GET['featured']) && $_GET['featured'] == 'all') echo " selected";
      echo '>Show Featured and Not Featured</option>'."\n";
      echo '<option value="EXISTS"';
      if (isset($_GET['featured']) && $_GET['featured'] == 'EXISTS') echo " selected";
      echo '>Featured</option>'."\n";
      echo '<option value="NOT EXISTS"';
      if (isset($_GET['featured']) && $_GET['featured'] == 'NOT EXISTS') echo " selected";
      echo '>Not Featured</option>'."\n";
    echo "</select>\n";
  }
}

// Do the actual boats categories filtering
add_filter('parse_query', 'boats_filter_by_type_query');
function boats_filter_by_type_query($query) {
  global $pagenow;
  $post_type = 'boats'; // change to your post type
  $taxonomy  = 'type'; // change to your taxonomy
  $q_vars    = &$query->query_vars;
  if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
    $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
    $q_vars[$taxonomy] = $term->slug;
  }
}

add_filter('parse_query', 'boats_filter_by_make_query');
function boats_filter_by_make_query($query) {
  global $pagenow;
  $post_type = 'boats'; // change to your post type
  $taxonomy  = 'make'; // change to your taxonomy
  $q_vars    = &$query->query_vars;
  if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
    $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
    $q_vars[$taxonomy] = $term->slug;
  }
}

add_filter('parse_query', 'boats_filter_by_location_query');
function boats_filter_by_location_query($query) {
  global $pagenow;
  $post_type = 'boats'; // change to your post type
  $taxonomy  = 'location'; // change to your taxonomy
  $q_vars    = &$query->query_vars;
  if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
    $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
    $q_vars[$taxonomy] = $term->slug;
  }
}

add_filter('parse_query', 'boats_filter_by_feature_query');
function boats_filter_by_feature_query($query) {
  global $pagenow;
  $post_type = isset($_GET['post_type']) ? $_GET['post_type'] : '';
  if (is_admin() && $pagenow=='edit.php' && $post_type == 'boats' && isset($_GET['featured']) && $_GET['featured'] != 'all') {
    $query->query_vars['meta_key'] = 'boat_featured';
    $query->query_vars['meta_compare'] = $_GET['featured'];
  }
}

add_filter('manage_edit-boats_sortable_columns', 'set_custom_boats_sortable_columns');
function set_custom_boats_sortable_columns($columns) {
  unset($columns['title']);
  return $columns;
}

add_action('pre_get_posts', 'boats_orderby_columns', 1);
function boats_orderby_columns($query) {
  if($query->get('orderby') == '') $query->set('orderby', 'title');
  if($query->get('order') == '') $query->set('order', 'ASC');
}

add_filter('manage_boats_posts_columns', 'set_custom_edit_boats_columns');
function set_custom_edit_boats_columns($columns) {
  unset($columns['date']);
  $columns['title'] = "Boat";
  $columns['boat_featured'] = "Featured";
  return $columns;
}

add_action('manage_boats_posts_custom_column', 'boats_posts_custom_column', 10, 2);
function boats_posts_custom_column($column, $post_id) {
  switch ($column) {
    case 'boat_featured' :
      if (get_post_meta($post_id, $column, true)) echo "&starf;";
      break;
  }
}

// Boats post type add/edit page
add_filter('enter_title_here', 'boats_title');
function boats_title($input) {
  if (get_post_type() === 'boats') return "Enter boat name here";
  return $input;
}

add_filter('wp_insert_post_data', 'boats_custom_permalink');
function boats_custom_permalink($data) {
  if ($data['post_type'] == 'boats') {
    $data['post_name'] = sanitize_title($data['post_title']);
  }
  return $data;
}

add_action('add_meta_boxes', 'boats_mb');
function boats_mb() {
  add_meta_box('boats_metabox_filter', 'Filter Fields', 'boats_mb_filter', 'boats', 'side', 'low');
  add_meta_box('boats_metabox_featured', 'Featured', 'boats_mb_featured', 'boats', 'side', 'low');
  add_meta_box('boats_metabox_gallery', 'Gallery', 'boats_mb_gallery', 'boats', 'normal', 'core');
}

function boats_mb_filter($post) {
  ?>
  <style>
    #boats_metabox_filter LABEL { display: block; width: 100%; margin-top: 1em; font-weight: bold; }
    #boats_metabox_filter INPUT { width: 100%; font-weight: normal; }
  </style>

  These fields are used by the filter to search for boats with these particular aspect. Please enter only whole numbers. More detailed information can be entered in the Specifications area.

  <label>Length (feet) <input type="text" name="boat_length" value="<?php echo $post->boat_length; ?>" placeholder="Just numbers; no feet or inches marks"></label>
  <label>Weight (pounds) <input type="text" name="boat_weight" value="<?php echo $post->boat_weight; ?>"></label>
  <label>Max Passengers <input type="text" name="boat_passengers" value="<?php echo $post->boat_passengers; ?>"></label>
  <label>Max HP <input type="text" name="boat_hp" value="<?php echo $post->boat_hp; ?>"></label>
  <?php
}

function boats_mb_featured($post) {
  echo '<label><input type="checkbox" name="boat_featured"';
  if ($post->boat_featured) echo " checked";
  echo '> Show this boat in the home page carousel</label>'."\n";

  echo '<br><br><label><input type="checkbox" name="boat_sold"';
  if ($post->boat_sold) echo " checked";
  echo '> Mark this boat as sold</label>'."\n";
}

add_action('edit_form_after_editor', 'boats_edit_form_after_editor');
function boats_edit_form_after_editor($post) {
  if (get_post_type() != 'boats') return;

  echo '<h3 style="margin: 1.5em 0 0.2em;">Specifications</h3>'."\n";
  echo "This section will be displayed as a bulleted list. Each new line will be a bullet point.";
  wp_editor(html_entity_decode($post->boat_specifications, ENT_QUOTES), "boat_specifications", array('textarea_name' => 'boat_specifications', 'textarea_rows' => 14, 'tinymce' => false, 'media_buttons' => false));

  echo '<h3 style="margin: 1.5em 0 0.2em;">Standard Features</h3>'."\n";
  echo "This section will be displayed as a bulleted list. Each new line will be a bullet point.";
  wp_editor(html_entity_decode($post->boat_features, ENT_QUOTES), "boat_features", array('textarea_name' => 'boat_features', 'textarea_rows' => 14, 'tinymce' => false, 'media_buttons' => false));

  echo '<h3 style="margin: 1.5em 0 0.2em;">Accessories</h3>'."\n";
  echo "This section will be displayed as a bulleted list. Each new line will be a bullet point.";
  wp_editor(html_entity_decode($post->boat_accessories, ENT_QUOTES), "boat_accessories", array('textarea_name' => 'boat_accessories', 'textarea_rows' => 14, 'tinymce' => false, 'media_buttons' => false));

  echo '<h3 style="margin: 1.5em 0 0.2em;">Optional Equipment</h3>'."\n";
  wp_editor(html_entity_decode($post->boat_optequip, ENT_QUOTES), "boat_optequip", array('textarea_name' => 'boat_optequip', 'textarea_rows' => 14));
}

function boats_mb_gallery($post) {
  $boat_images = get_post_meta($post->ID, 'boat_images', true);
  ?>
  <div id="boat_images" class="rows">
    <?php
    if (isset($boat_images['image'])) {
      for($i = 0; $i < count($boat_images['image']); $i++) {
        ?>
        <div class="row">
          <div class="image" style="background-image: url(<?php esc_html_e($boat_images['image'][$i]); ?>);"></div>
          <input type="hidden" name="boat_images[image][]" value="<?php esc_html_e($boat_images['image'][$i]); ?>">
          <button onclick="remove_row(this)"></button>
        </div> <!-- /.row -->
        <?php
      }
    }
    ?>
  </div> <!-- /#boat_images -->

  <div onclick="add_row('boat_images')" class="button-primary">Add Image</div>

  <script type="text/javascript">
    jQuery(function() { jQuery(".rows").sortable(); });

    function remove_row(value) { jQuery(value).parent().remove(); }

    function add_row(value){
      media_uploader = wp.media({ frame: "post", state: "insert", multiple: true });

      media_uploader.on("insert", function() {
        var length = media_uploader.state().get("selection").length;
        var images = media_uploader.state().get("selection").models

        for(var iii = 0; iii < length; iii++) {
          var image_url = images[iii].changed.url;
          
          var row = '<div class="row">'+
            '<div class="image"></div>'+
            '<input type="hidden" name="'+value+'[image][]" value="">'+
            '<button onclick="remove_row(this)"></button>'+
          '</div>';
          
          jQuery(row).appendTo('#'+value);

          var element = jQuery('#'+value+' .row:last-child');
          var elementimg = jQuery('#'+value+' .row:last-child .image');
          elementimg.css('background-image', 'url('+image_url+')');
          element.find('INPUT[name^="'+value+'[image]"]').val(image_url);
        }
      });

      media_uploader.open();
    }
  </script>

  <style>
    .rows { display: flex; flex-wrap: wrap; }

    .row {
      width: 15%;
      outline: 1px solid #DCDCDE;
      margin: 1.5em 3% 1.5em 0; cursor: move; position: relative;
    }

    .row .image {
      width: 100%;
      background-repeat: no-repeat;
      background-position: center;
      background-size: cover;
    }

    .row .image:before { content: ""; display: block; padding-top: 100%; }

    .row BUTTON {
      position: absolute;
      z-index: 3;
      top: 0;
      right: 0;
      transform: translate(50%, -50%);
      width: 30px;
      height: 30px;
      border-radius: 50%;
      border: 2px solid #FFFFFF;
      background: #B32D2E;
      cursor: pointer;
    }

    .row BUTTON:after { content: "\2715"; color: #FFFFFF; font-weight: bold; }
  </style>
  <?php
}

add_action('save_post', 'boats_save');
function boats_save($post_id) {
  if (get_post_type() != 'boats') return;

  if (!empty($_POST['boat_length'])) {
    update_post_meta($post_id, 'boat_length', $_POST['boat_length']);
  } else {
    delete_post_meta($post_id, 'boat_length');
  }

  if (!empty($_POST['boat_weight'])) {
    update_post_meta($post_id, 'boat_weight', preg_replace("/[^0-9]/", "", $_POST['boat_weight']));
  } else {
    delete_post_meta($post_id, 'boat_weight');
  }

  if (!empty($_POST['boat_passengers'])) {
    update_post_meta($post_id, 'boat_passengers', $_POST['boat_passengers']);
  } else {
    delete_post_meta($post_id, 'boat_passengers');
  }

  if (!empty($_POST['boat_hp'])) {
    update_post_meta($post_id, 'boat_hp', $_POST['boat_hp']);
  } else {
    delete_post_meta($post_id, 'boat_hp');
  }

  if (!empty($_POST['boat_featured'])) {
    update_post_meta($post_id, 'boat_featured', $_POST['boat_featured']);
  } else {
    delete_post_meta($post_id, 'boat_featured');
  }

  if (!empty($_POST['boat_sold'])) {
    update_post_meta($post_id, 'boat_sold', $_POST['boat_sold']);
  } else {
    delete_post_meta($post_id, 'boat_sold');
  }

  if (!empty($_POST['boat_specifications'])) {
    update_post_meta($post_id, 'boat_specifications', $_POST['boat_specifications']);
  } else {
    delete_post_meta($post_id, 'boat_specifications');
  }

  if (!empty($_POST['boat_features'])) {
    update_post_meta($post_id, 'boat_features', $_POST['boat_features']);
  } else {
    delete_post_meta($post_id, 'boat_features');
  }

  if (!empty($_POST['boat_accessories'])) {
    update_post_meta($post_id, 'boat_accessories', $_POST['boat_accessories']);
  } else {
    delete_post_meta($post_id, 'boat_accessories');
  }

  if (!empty($_POST['boat_optequip'])) {
    update_post_meta($post_id, 'boat_optequip', $_POST['boat_optequip']);
  } else {
    delete_post_meta($post_id, 'boat_optequip');
  }

  if (!empty($_POST['boat_images'])) {
    update_post_meta($post_id, 'boat_images', $_POST['boat_images']);
  } else {
    delete_post_meta($post_id, 'boat_images');
  }
}


add_filter('pre_get_document_title', 'boats_archive_title', 9999);
function boats_archive_title($title) {
  if (is_post_type_archive('boats')) $title = "Boats - ".get_bloginfo('name');
  return $title;
}


/*
*  Forms Submissions
*/
if (!class_exists('WP_List_Table')) require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');

class Boat_Quotes_List_Table extends WP_List_Table {
  public function __construct() {
    parent::__construct( array(
      'singular' => 'boat_quotes',
      'plural'   => 'boat_quotes',
      'ajax'     => false
    ));
  }

  function column_default($item, $column_name){
    return $item[$column_name];
  }

  // Make name column clickable for detail view
  function column_name($item) {
    $actions = array(
      'view' => sprintf('<a href="?page=%s&action=view&id=%s">View Details</a>', $_REQUEST['page'], $item['id']),
    );
    return sprintf('%1$s %2$s', '<strong><a href="?page=' . $_REQUEST['page'] . '&action=view&id=' . $item['id'] . '">' . $item['name'] . '</a></strong>', $this->row_actions($actions));
  }

  // Required for bulk actions checkbox
  function column_cb($item){
    return '<input type="checkbox" name="bqb[]" value="'.$item['id'].'" />';
  }

  function get_columns(){
    return array(
      'cb' => '<input type="checkbox" />',
      'name' => 'Name',
      'email' => 'Email',
      'phone' => 'Phone',
      'boatlist' => 'Boats',
      'location' => 'Location',
      'interest' => 'Interested In',
      'seatrial' => 'Sea Trial',
      'callback' => 'Callback Time',
      'message' => 'Message',
      'date_submitted' => 'Date'
    );
  }

  function get_sortable_columns() {
    return array(
      'name' => array('name',false),
      'email' => array('email',false),
      'phone' => array('phone',false),
      'boatlist' => array('boatlist',false),
      'location' => array('location',false),
      'interest' => array('interest',false),
      'seatrial' => array('seatrial',false),
      'callback' => array('callback',false),
      'message' => array('message',false),
      'date_submitted' => array('date_submitted',false)
    );
  }

  function get_bulk_actions() {
    $actions = array(
      'delete' => 'Delete'
    );
    return $actions;
  }

  function process_bulk_action() {
    global $wpdb;

    //Detect when a bulk action is being triggered...
    if('delete'===$this->current_action()) {
      foreach ($_GET['bqb'] as $id) {
        $wpdb->delete("boat_quotes", ['id' => $id], ['%d']);
      }
    }
  }

  function prepare_items() {
    global $wpdb;

    // Define column headers and build an array
    $columns = $this->get_columns();
    $hidden = array();
    $sortable = $this->get_sortable_columns();

    $this->_column_headers = array($columns, $hidden, $sortable);
    
    // Handle bulk actions
    $this->process_bulk_action();
    
    // Get the data from the database
    $data = $wpdb->get_results("SELECT * FROM boat_quotes", ARRAY_A);

    // Sort columns
    function usort_reorder($a,$b){
      $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'date_submitted';
      $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'desc';
      $result = strcmp($a[$orderby], $b[$orderby]);
      return ($order==='asc') ? $result : -$result;
    }
    usort($data, 'usort_reorder');
    
    /*
    *  The remainder of this subfunction deals with pagination
    */
    // How many records per page to display
    $per_page = 100;

    $current_page = $this->get_pagenum();

    $total_items = count($data);

    $data = array_slice($data,(($current_page-1)*$per_page),$per_page);

    $this->items = $data;

    $this->set_pagination_args(array(
      'total_items' => $total_items,                //WE have to calculate the total number of items
      'per_page'    => $per_page,                   //WE have to determine how many items to show on a page
      'total_pages' => ceil($total_items/$per_page) //WE have to calculate the total number of pages
    ));
  }
}

// Boat quotes is now a submenu under Form Submissions
add_action('admin_menu', 'boat_quotes_add_menu_items');
function boat_quotes_add_menu_items(){
  // This will be a submenu now, handled by form_submissions_dashboard_menu
}

function boat_quotes_page(){
  date_default_timezone_set('America/New_York');

  // Check if viewing a single record
  if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['id'])) {
    boat_quotes_detail_view($_GET['id']);
    return;
  }

  //Create an instance of our package class...
  $BQListTable = new Boat_Quotes_List_Table();

  //Fetch, prepare, sort, and filter our data...
  $BQListTable->prepare_items();

  echo '<div class="wrap">';
    echo '<h2>Boat Quotes</h2>';

    $url = parse_url($_SERVER['REQUEST_URI']);
    parse_str($url['query'], $vars);
    $orderby = (isset($vars['orderby'])) ? $vars['orderby'] : 'date_submitted';
    $order = (isset($vars['order'])) ? $vars['order'] : 'desc';

    echo '<a href="'.admin_url('admin-ajax.php?action=bq_export&orderby='.$orderby.'&order='.$order).'" class="button">Export List to CSV</a>';

    echo '<form id="boat_quotes-filter" method="get">';
      echo '<input type="hidden" name="page" value="'. $_REQUEST['page'] . '" />';
      $BQListTable->display();
    echo '</form>';

    echo '<a href="'.admin_url('admin-ajax.php?action=bq_export&orderby='.$orderby.'&order='.$order).'" class="button">Export List to CSV</a>';
  echo '</div>';
}

function boat_quotes_detail_view($id) {
  global $wpdb;
  $record = $wpdb->get_row($wpdb->prepare("SELECT * FROM boat_quotes WHERE id = %d", $id), ARRAY_A);

  if (!$record) {
    echo '<div class="wrap"><h2>Record Not Found</h2><p><a href="?page=form_submissions_boat_quotes">← Back to Boat Quotes</a></p></div>';
    return;
  }

  echo '<div class="wrap">';
    echo '<h2>Boat Quote Details</h2>';
    echo '<p><a href="?page=form_submissions_boat_quotes" class="button">← Back to Boat Quotes</a></p>';

    echo '<div style="background: white; padding: 20px; border: 1px solid #ccc; border-radius: 4px; margin-top: 20px;">';
      echo '<table class="form-table" style="max-width: 600px;">';
        echo '<tr><th style="width: 150px;">ID:</th><td>' . $record['id'] . '</td></tr>';
        echo '<tr><th>Name:</th><td>' . esc_html($record['name']) . '</td></tr>';
        echo '<tr><th>Email:</th><td><a href="mailto:' . esc_attr($record['email']) . '">' . esc_html($record['email']) . '</a></td></tr>';
        echo '<tr><th>Phone:</th><td><a href="tel:' . esc_attr($record['phone']) . '">' . esc_html($record['phone']) . '</a></td></tr>';
        echo '<tr><th>Boats:</th><td>' . nl2br(esc_html($record['boatlist'])) . '</td></tr>';
        echo '<tr><th>Location:</th><td>' . esc_html($record['location']) . '</td></tr>';
        echo '<tr><th>Interested In:</th><td>' . esc_html($record['interest']) . '</td></tr>';
        echo '<tr><th>Sea Trial:</th><td>' . esc_html($record['seatrial']) . '</td></tr>';
        echo '<tr><th>Callback Time:</th><td>' . esc_html($record['callback']) . '</td></tr>';
        echo '<tr><th>Message:</th><td>' . nl2br(esc_html($record['message'])) . '</td></tr>';
        echo '<tr><th>Date Submitted:</th><td>' . date('F j, Y g:i A', strtotime($record['date_submitted'])) . '</td></tr>';
      echo '</table>';
    echo '</div>';

  echo '</div>';
}

add_action('wp_ajax_bq_export','export_form_submissions');
function export_form_submissions() {
  date_default_timezone_set('America/New_York');

  global $wpdb;

  $results = $wpdb->get_results("SELECT * FROM boat_quotes ORDER BY ".$_REQUEST['orderby']." ".$_REQUEST['order'], ARRAY_A );

  $headers = "Name, Email, Phone, Boats, Preferred Location, Also Interested In, Sea Trial, Callback Time, Message, Date";

  if (count($results) > 0) {
    $output = "";

    foreach($results as $result) {
      $output .= '"'.$result['name'].'",';
      $output .= '"'.$result['email'].'",';
      $output .= '"'.$result['phone'].'",';
      $output .= '"'.$result['boatlist'].'",';
      $output .= '"'.$result['location'].'",';
      $output .= '"'.$result['interest'].'",';
      $output .= '"'.$result['seatrial'].'",';
      $output .= '"'.$result['callback'].'",';
      $output .= '"'.$result['message'].'",';
      $output .= '"'.$result['date_submitted'].'"';
      $output .= "\n";
    }
  }

  header("Content-type: application/vnd.ms-excel");
  header("Content-disposition: filename=boat_quotes_".date("Y-m-d_H-i",time()).".csv");
  print $headers."\n".$output;
  exit;
}


/*
*  Contact Submissions
*/
if (!class_exists('WP_List_Table')) require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');

class Contact_Submissions_List_Table extends WP_List_Table {
  public function __construct() {
    parent::__construct( array(
      'singular' => 'contact_submission',
      'plural'   => 'contact_submissions',
      'ajax'     => false
    ));
  }

  function column_default($item, $column_name){
    return $item[$column_name];
  }

  // Required for bulk actions checkbox
  function column_cb($item){
    return '<input type="checkbox" name="csb[]" value="'.$item['id'].'" />';
  }

  // Add custom column for email status
  function column_email_sent($item) {
    return $item['email_sent'] ? '<span style="color: green;">✓ Sent</span>' : '<span style="color: red;">✗ Failed</span>';
  }

  // Make name column clickable for detail view
  function column_name($item) {
    $actions = array(
      'view' => sprintf('<a href="?page=%s&action=view&id=%s">View Details</a>', $_REQUEST['page'], $item['id']),
    );
    return sprintf('%1$s %2$s', '<strong><a href="?page=' . $_REQUEST['page'] . '&action=view&id=' . $item['id'] . '">' . $item['name'] . '</a></strong>', $this->row_actions($actions));
  }

  function get_columns(){
    return array(
      'cb' => '<input type="checkbox" />',
      'name' => 'Name',
      'email' => 'Email',
      'phone' => 'Phone',
      'message' => 'Message',
      'email_sent' => 'Email Status',
      'date_submitted' => 'Date'
    );
  }

  function get_sortable_columns() {
    return array(
      'name' => array('name',false),
      'email' => array('email',false),
      'phone' => array('phone',false),
      'email_sent' => array('email_sent',false),
      'date_submitted' => array('date_submitted',false)
    );
  }

  function get_bulk_actions() {
    $actions = array(
      'delete' => 'Delete'
    );
    return $actions;
  }

  function process_bulk_action() {
    global $wpdb;

    //Detect when a bulk action is being triggered...
    if('delete'===$this->current_action()) {
      foreach ($_GET['csb'] as $id) {
        $wpdb->delete("contact_submissions", ['id' => $id], ['%d']);
      }
    }
  }

  function prepare_items() {
    global $wpdb;

    // Define column headers and build an array
    $columns = $this->get_columns();
    $hidden = array();
    $sortable = $this->get_sortable_columns();

    $this->_column_headers = array($columns, $hidden, $sortable);

    // Handle bulk actions
    $this->process_bulk_action();

    // Get the data from the database
    $data = $wpdb->get_results("SELECT * FROM contact_submissions", ARRAY_A);

    // Sort columns
    function usort_reorder_contact($a,$b){
      $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'date_submitted';
      $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'desc';
      $result = strcmp($a[$orderby], $b[$orderby]);
      return ($order==='asc') ? $result : -$result;
    }
    usort($data, 'usort_reorder_contact');

    /*
    *  The remainder of this subfunction deals with pagination
    */
    // How many records per page to display
    $per_page = 100;

    $current_page = $this->get_pagenum();

    $total_items = count($data);

    $data = array_slice($data,(($current_page-1)*$per_page),$per_page);

    $this->items = $data;

    $this->set_pagination_args(array(
      'total_items' => $total_items,                //WE have to calculate the total number of items
      'per_page'    => $per_page,                   //WE have to determine how many items to show on a page
      'total_pages' => ceil($total_items/$per_page) //WE have to calculate the total number of pages
    ));
  }
}

// Combined Form Submissions Dashboard
add_action('admin_menu', 'form_submissions_dashboard_menu');
function form_submissions_dashboard_menu(){
  add_menu_page('Form Submissions', 'Form Submissions', 'activate_plugins', 'form_submissions', 'form_submissions_dashboard_page', 'dashicons-forms', 55);
  add_submenu_page('form_submissions', 'Boat Quotes', 'Boat Quotes', 'activate_plugins', 'form_submissions_boat_quotes', 'boat_quotes_page');
  add_submenu_page('form_submissions', 'Contact Submissions', 'Contact Submissions', 'activate_plugins', 'form_submissions_contacts', 'contact_submissions_page');
}

function form_submissions_dashboard_page(){
  date_default_timezone_set('America/New_York');

  // Get recent submissions counts
  global $wpdb;
  $boat_quotes_count = $wpdb->get_var("SELECT COUNT(*) FROM boat_quotes");
  $contact_count = $wpdb->get_var("SELECT COUNT(*) FROM contact_submissions");
  $failed_emails = $wpdb->get_var("SELECT COUNT(*) FROM contact_submissions WHERE email_sent = 0");

  // Get recent submissions
  $recent_boats = $wpdb->get_results("SELECT * FROM boat_quotes ORDER BY date_submitted DESC LIMIT 5", ARRAY_A);
  $recent_contacts = $wpdb->get_results("SELECT * FROM contact_submissions ORDER BY date_submitted DESC LIMIT 5", ARRAY_A);

  echo '<div class="wrap">';
    echo '<h1>Form Submissions Dashboard</h1>';

    // Overview stats
    echo '<div class="dashboard-widgets-wrap">';
      echo '<div id="dashboard-widgets" class="metabox-holder">';

        // Stats row
        echo '<div class="postbox-container" style="width:100%;">';
          echo '<div class="meta-box-sortables">';

            echo '<div class="postbox">';
              echo '<h3 class="hndle"><span>Submission Overview</span></h3>';
              echo '<div class="inside">';
                echo '<div style="display: flex; gap: 20px; margin-bottom: 20px;">';
                  echo '<div style="flex: 1; padding: 15px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px;">';
                    echo '<h4 style="margin: 0 0 10px 0; color: #007cba;">Boat Quotes</h4>';
                    echo '<div style="font-size: 24px; font-weight: bold; color: #007cba;">' . $boat_quotes_count . '</div>';
                  echo '</div>';
                  echo '<div style="flex: 1; padding: 15px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px;">';
                    echo '<h4 style="margin: 0 0 10px 0; color: #28a745;">Contact Forms</h4>';
                    echo '<div style="font-size: 24px; font-weight: bold; color: #28a745;">' . $contact_count . '</div>';
                  echo '</div>';
                  echo '<div style="flex: 1; padding: 15px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px;">';
                    echo '<h4 style="margin: 0 0 10px 0; color: #dc3545;">Failed Emails</h4>';
                    echo '<div style="font-size: 24px; font-weight: bold; color: #dc3545;">' . $failed_emails . '</div>';
                  echo '</div>';
                echo '</div>';
              echo '</div>';
            echo '</div>';

          echo '</div>';
        echo '</div>';

        // Recent submissions row
        echo '<div class="postbox-container" style="width:49%; margin-right: 2%;">';
          echo '<div class="meta-box-sortables">';

            echo '<div class="postbox">';
              echo '<h3 class="hndle"><span>Recent Boat Quotes</span></h3>';
              echo '<div class="inside">';
                if (empty($recent_boats)) {
                  echo '<p>No boat quotes yet.</p>';
                } else {
                  echo '<table class="widefat striped" style="margin: 0;">';
                    echo '<thead><tr><th>Name</th><th>Email</th><th>Date</th></tr></thead>';
                    echo '<tbody>';
                    foreach ($recent_boats as $quote) {
                      echo '<tr>';
                      echo '<td>' . esc_html($quote['name']) . '</td>';
                      echo '<td>' . esc_html($quote['email']) . '</td>';
                      echo '<td>' . date('M j, Y g:i A', strtotime($quote['date_submitted'])) . '</td>';
                      echo '</tr>';
                    }
                    echo '</tbody></table>';
                }
                echo '<p><a href="' . admin_url('admin.php?page=form_submissions_boat_quotes') . '" class="button">View All Boat Quotes</a></p>';
              echo '</div>';
            echo '</div>';

          echo '</div>';
        echo '</div>';

        echo '<div class="postbox-container" style="width:49%;">';
          echo '<div class="meta-box-sortables">';

            echo '<div class="postbox">';
              echo '<h3 class="hndle"><span>Recent Contact Submissions</span></h3>';
              echo '<div class="inside">';
                if (empty($recent_contacts)) {
                  echo '<p>No contact submissions yet.</p>';
                } else {
                  echo '<table class="widefat striped" style="margin: 0;">';
                    echo '<thead><tr><th>Name</th><th>Email</th><th>Status</th><th>Date</th></tr></thead>';
                    echo '<tbody>';
                    foreach ($recent_contacts as $contact) {
                      $status = $contact['email_sent'] ? '<span style="color: green;">✓ Sent</span>' : '<span style="color: red;">✗ Failed</span>';
                      echo '<tr>';
                      echo '<td>' . esc_html($contact['name']) . '</td>';
                      echo '<td>' . esc_html($contact['email']) . '</td>';
                      echo '<td>' . $status . '</td>';
                      echo '<td>' . date('M j, Y g:i A', strtotime($contact['date_submitted'])) . '</td>';
                      echo '</tr>';
                    }
                    echo '</tbody></table>';
                }
                echo '<p><a href="' . admin_url('admin.php?page=form_submissions_contacts') . '" class="button">View All Contact Submissions</a></p>';
              echo '</div>';
            echo '</div>';

          echo '</div>';
        echo '</div>';

      echo '</div>';
    echo '</div>';

  echo '</div>';
}

// Individual pages are now submenus under Form Submissions dashboard

function contact_submissions_page(){
  date_default_timezone_set('America/New_York');

  // Check if viewing a single record
  if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['id'])) {
    contact_submissions_detail_view($_GET['id']);
    return;
  }

  //Create an instance of our package class...
  $CSListTable = new Contact_Submissions_List_Table();

  //Fetch, prepare, sort, and filter our data...
  $CSListTable->prepare_items();

  echo '<div class="wrap">';
    echo '<h2>Contact Submissions</h2>';

    $url = parse_url($_SERVER['REQUEST_URI']);
    parse_str($url['query'], $vars);
    $orderby = (isset($vars['orderby'])) ? $vars['orderby'] : 'date_submitted';
    $order = (isset($vars['order'])) ? $vars['order'] : 'desc';

    echo '<a href="'.admin_url('admin-ajax.php?action=cs_export&orderby='.$orderby.'&order='.$order).'" class="button">Export List to CSV</a>';

    echo '<form id="contact_submissions-filter" method="get">';
      echo '<input type="hidden" name="page" value="'. $_REQUEST['page'] . '" />';
      $CSListTable->display();
    echo '</form>';

    echo '<a href="'.admin_url('admin-ajax.php?action=cs_export&orderby='.$orderby.'&order='.$order).'" class="button">Export List to CSV</a>';
  echo '</div>';
}

function contact_submissions_detail_view($id) {
  global $wpdb;
  $record = $wpdb->get_row($wpdb->prepare("SELECT * FROM contact_submissions WHERE id = %d", $id), ARRAY_A);

  if (!$record) {
    echo '<div class="wrap"><h2>Record Not Found</h2><p><a href="?page=form_submissions_contacts">← Back to Contact Submissions</a></p></div>';
    return;
  }

  $email_status = $record['email_sent'] ? '<span style="color: green;">✓ Email Sent Successfully</span>' : '<span style="color: red;">✗ Email Failed to Send</span>';

  echo '<div class="wrap">';
    echo '<h2>Contact Submission Details</h2>';
    echo '<p><a href="?page=form_submissions_contacts" class="button">← Back to Contact Submissions</a></p>';

    echo '<div style="background: white; padding: 20px; border: 1px solid #ccc; border-radius: 4px; margin-top: 20px;">';
      echo '<table class="form-table" style="max-width: 600px;">';
        echo '<tr><th style="width: 150px;">ID:</th><td>' . $record['id'] . '</td></tr>';
        echo '<tr><th>Name:</th><td>' . esc_html($record['name']) . '</td></tr>';
        echo '<tr><th>Email:</th><td><a href="mailto:' . esc_attr($record['email']) . '">' . esc_html($record['email']) . '</a></td></tr>';
        echo '<tr><th>Phone:</th><td><a href="tel:' . esc_attr($record['phone']) . '">' . esc_html($record['phone']) . '</a></td></tr>';
        echo '<tr><th>Message:</th><td>' . nl2br(esc_html($record['message'])) . '</td></tr>';
        echo '<tr><th>Email Status:</th><td>' . $email_status . '</td></tr>';
        echo '<tr><th>Date Submitted:</th><td>' . date('F j, Y g:i A', strtotime($record['date_submitted'])) . '</td></tr>';
      echo '</table>';
    echo '</div>';

  echo '</div>';
}

add_action('wp_ajax_cs_export','export_contact_submissions');
function export_contact_submissions() {
  date_default_timezone_set('America/New_York');

  global $wpdb;

  $results = $wpdb->get_results("SELECT * FROM contact_submissions ORDER BY ".$_REQUEST['orderby']." ".$_REQUEST['order'], ARRAY_A );

  $headers = "Name, Email, Phone, Message, Email Sent, Date";

  if (count($results) > 0) {
    $output = "";

    foreach($results as $result) {
      $output .= '"'.$result['name'].'",';
      $output .= '"'.$result['email'].'",';
      $output .= '"'.$result['phone'].'",';
      $output .= '"'.$result['message'].'",';
      $output .= '"'.($result['email_sent'] ? 'Yes' : 'No').'",';
      $output .= '"'.$result['date_submitted'].'"';
      $output .= "\n";
    }
  }

  header("Content-type: application/vnd.ms-excel");
  header("Content-disposition: filename=contact_submissions_".date("Y-m-d_H-i",time()).".csv");
  print $headers."\n".$output;
  exit;
}

/*
*  Forms
*/
add_action('add_meta_boxes_page', 'form_metaboxes');
function form_metaboxes() {
  global $post;
  $template = get_post_meta($post->ID, '_wp_page_template', true);

  if ($template == "template-my-boat-quotes.php" || $template == "template-contact.php") {
    add_meta_box('form_metabox_settings',
      'Form Settings',
      'display_form_metabox_settings',
      'page', 'normal'
    );
  }
}

function display_form_metabox_settings($post) {
  echo "<strong>Send To</strong><br>
  For multiple addresses, add one address per line.<br>\n";
  wp_editor(html_entity_decode($post->form_send_to, ENT_QUOTES), "form_send_to", array('textarea_name' => 'form_send_to', 'textarea_rows' => 6, 'tinymce' => false, 'media_buttons' => false, 'quicktags' => false));
  echo "<br>\n";

  echo "<strong>From Name</strong><br>\n";
  echo '<input type="text" name="form_from_name" value="'.$post->form_from_name.'" style="width: 100%;"><br>'."\n";
  echo "<br>\n";

  echo "<strong>Email Subject</strong><br>\n";
  echo '<input type="text" name="form_subject" value="'.$post->form_subject.'" style="width: 100%;"><br>'."\n";
  echo "<br>\n";

  echo "<strong>Success Message</strong><br>\n";
  wp_editor(html_entity_decode($post->form_success, ENT_QUOTES), "form_success", array('textarea_name' => 'form_success', 'textarea_rows' => 6, 'tinymce' => false, 'media_buttons' => false, 'quicktags' => false));
  echo "<br>\n";
}

add_action('save_post', 'form_save');
function form_save($post_id) {
  if (!empty($_POST['form_send_to'])) {
    update_post_meta($post_id, 'form_send_to', $_POST['form_send_to']);
  } else {
    delete_post_meta($post_id, 'form_send_to');
  }

  if (!empty($_POST['form_from_name'])) {
    update_post_meta($post_id, 'form_from_name', $_POST['form_from_name']);
  } else {
    delete_post_meta($post_id, 'form_from_name');
  }

  if (!empty($_POST['form_subject'])) {
    update_post_meta($post_id, 'form_subject', $_POST['form_subject']);
  } else {
    delete_post_meta($post_id, 'form_subject');
  }

  if (!empty($_POST['form_success'])) {
    update_post_meta($post_id, 'form_success', $_POST['form_success']);
  } else {
    delete_post_meta($post_id, 'form_success');
  }
}


/*
*  Locations
*/
add_action('add_meta_boxes_page', 'location_metaboxes');
function location_metaboxes() {
  global $post;
  $template = get_post_meta($post->ID, '_wp_page_template', true);

  if ($template == "template-location.php") {
    add_meta_box('location_metabox',
      'Location and Hours',
      'display_location_metabox',
      'page', 'normal'
    );

    add_meta_box('location_logo_metabox', 'Store Logo', 'display_location_logo_metabox', 'page', 'side', 'low');
  }
}

function display_location_metabox($post) {
  global $post;
  $template = get_post_meta($post->ID, '_wp_page_template', true);

  if ($template == "template-location.php") {
    ?>
    <style>
      .col2 { display: flex; justify-content: space-between; }
      .col2 > DIV { width: 48%; }
      .col2 LABEL { display: block; margin-bottom: 1em; }
    </style>

    <div class="col2">
      <div>
        <h3 style="margin: 0.25em 0;">Location</h3>
        <label>Name<br><input type="text" name="loc_name" value="<?php echo $post->loc_name; ?>"></label>
        <label><input type="checkbox" name="loc_noname" value="noname"<?php if ($post->loc_noname) echo " checked"; ?>> Don't use name for Google Map display</label>
        <label>Address<br><input type="text" name="loc_address" value="<?php echo $post->loc_address; ?>"></label>
        <label>City<br><input type="text" name="loc_city" value="<?php echo $post->loc_city; ?>"></label>
        <label>State<br><input type="text" name="loc_state" value="<?php echo $post->loc_state; ?>"></label>
        <label>Zip Code<br><input type="text" name="loc_zip" value="<?php echo $post->loc_zip; ?>"></label>
        <label>Phone<br><input type="tel" name="loc_phone" value="<?php echo $post->loc_phone; ?>"></label>
      </div>

      <div class="loc_hours">
        <h3 style="margin: 0.25em 0;">Hours</h3>
        <label>Monday<br><input type="text" name="loc_mon" value="<?php echo $post->loc_mon; ?>"></label>
        <label>Tuesday<br><input type="text" name="loc_tue" value="<?php echo $post->loc_tue; ?>"></label>
        <label>Wednesday<br><input type="text" name="loc_wed" value="<?php echo $post->loc_wed; ?>"></label>
        <label>Thursday<br><input type="text" name="loc_thu" value="<?php echo $post->loc_thu; ?>"></label>
        <label>Friday<br><input type="text" name="loc_fri" value="<?php echo $post->loc_fri; ?>"></label>
        <label>Saturday<br><input type="text" name="loc_sat" value="<?php echo $post->loc_sat; ?>"></label>
        <label>Sunday<br><input type="text" name="loc_sun" value="<?php echo $post->loc_sun; ?>"></label>
      </div>
    </div> <!-- /.col2 -->
    <?php
  }
}

function display_location_logo_metabox($post) {
  global $content_width, $_wp_additional_image_sizes;

  $image_id = get_post_meta($post->ID, 'loc_logo', true);

  $old_content_width = $content_width;
  $content_width = 254;

  if ($image_id && get_post($image_id)) {
    if (!isset($_wp_additional_image_sizes['post-thumbnail'])) {
      $thumbnail_html = wp_get_attachment_image($image_id, array($content_width, $content_width));
    } else {
      $thumbnail_html = wp_get_attachment_image($image_id, 'post-thumbnail');
    }

    if (!empty($thumbnail_html)) {
      $content = $thumbnail_html;
      $content .= '<p class="hide-if-no-js"><a href="javascript:;" id="remove_store_logo_button">Remove store logo</a></p>';
      $content .= '<input type="hidden" id="upload_store_logo" name="location_logo" value="' . esc_attr($image_id) . '" />';
    }

    $content_width = $old_content_width;
  } else {
    $content = '<img src="" style="width:' . esc_attr($content_width) . 'px;height:auto;border:0;display:none;" />';
    $content .= '<p class="hide-if-no-js"><a title="Set store logo" href="javascript:;" id="upload_store_logo_button" id="set-store-logo" data-uploader_title="Choose an image" data-uploader_button_text="Set listing image">Set store logo</a></p>';
    $content .= '<input type="hidden" id="upload_store_logo" name="location_logo" value="" />';
  }

  echo $content;

  ?>
  <style>
    #location_logo_metabox IMG { max-width: 100%; height: auto; }
  </style>

  <script>
    jQuery(document).ready(function($) {
      // Uploading files
      var file_frame;

      jQuery.fn.upload_store_logo = function (button) {
        var button_id = button.attr('id');
        var field_id = button_id.replace('_button', '');

        // If the media frame already exists, reopen it.
        if (file_frame) {
          file_frame.open();
          return;
        }

        // Create the media frame.
        file_frame = wp.media.frames.file_frame = wp.media({
          title: jQuery(this).data('uploader_title'),
          button: {
              text: jQuery(this).data('uploader_button_text'),
          },
          multiple: false
        });

        // When an image is selected, run a callback.
        file_frame.on('select', function () {
          var attachment = file_frame.state().get('selection').first().toJSON();
          jQuery("#" + field_id).val(attachment.id);
          jQuery("#location_logo_metabox img").attr('src', attachment.url);
          jQuery('#location_logo_metabox img').show();
          jQuery('#' + button_id).attr('id', 'remove_store_logo_button');
          jQuery('#remove_store_logo_button').text('Remove store logo');
        });

        // Finally, open the modal
        file_frame.open();
      };

      jQuery('#location_logo_metabox').on('click', '#upload_store_logo_button', function (event) {
        event.preventDefault();
        jQuery.fn.upload_store_logo(jQuery(this));
      });

      jQuery('#location_logo_metabox').on('click', '#remove_store_logo_button', function (event) {
        event.preventDefault();
        jQuery('#upload_store_logo').val('');
        jQuery('#location_logo_metabox img').attr('src', '');
        jQuery('#location_logo_metabox img').hide();
        jQuery(this).attr('id', 'upload_store_logo_button');
        jQuery('#upload_store_logo_button').text('Set store logo');
      });
    });
  </script>
  <?php
}

add_action('save_post', 'location_save');
function location_save($post_id) {
  if (!empty($_POST['loc_name'])) {
    update_post_meta($post_id, 'loc_name', $_POST['loc_name']);
  } else {
    delete_post_meta($post_id, 'loc_name');
  }

  if (!empty($_POST['loc_noname'])) {
    update_post_meta($post_id, 'loc_noname', $_POST['loc_noname']);
  } else {
    delete_post_meta($post_id, 'loc_noname');
  }

  if (!empty($_POST['loc_address'])) {
    update_post_meta($post_id, 'loc_address', $_POST['loc_address']);
  } else {
    delete_post_meta($post_id, 'loc_address');
  }

  if (!empty($_POST['loc_city'])) {
    update_post_meta($post_id, 'loc_city', $_POST['loc_city']);
  } else {
    delete_post_meta($post_id, 'loc_city');
  }

  if (!empty($_POST['loc_state'])) {
    update_post_meta($post_id, 'loc_state', $_POST['loc_state']);
  } else {
    delete_post_meta($post_id, 'loc_state');
  }

  if (!empty($_POST['loc_zip'])) {
    update_post_meta($post_id, 'loc_zip', $_POST['loc_zip']);
  } else {
    delete_post_meta($post_id, 'loc_zip');
  }

  if (!empty($_POST['loc_phone'])) {
    update_post_meta($post_id, 'loc_phone', $_POST['loc_phone']);
  } else {
    delete_post_meta($post_id, 'loc_phone');
  }

  if (!empty($_POST['loc_mon'])) {
    update_post_meta($post_id, 'loc_mon', $_POST['loc_mon']);
  } else {
    delete_post_meta($post_id, 'loc_mon');
  }

  if (!empty($_POST['loc_tue'])) {
    update_post_meta($post_id, 'loc_tue', $_POST['loc_tue']);
  } else {
    delete_post_meta($post_id, 'loc_tue');
  }

  if (!empty($_POST['loc_wed'])) {
    update_post_meta($post_id, 'loc_wed', $_POST['loc_wed']);
  } else {
    delete_post_meta($post_id, 'loc_wed');
  }

  if (!empty($_POST['loc_thu'])) {
    update_post_meta($post_id, 'loc_thu', $_POST['loc_thu']);
  } else {
    delete_post_meta($post_id, 'loc_thu');
  }

  if (!empty($_POST['loc_fri'])) {
    update_post_meta($post_id, 'loc_fri', $_POST['loc_fri']);
  } else {
    delete_post_meta($post_id, 'loc_fri');
  }

  if (!empty($_POST['loc_sat'])) {
    update_post_meta($post_id, 'loc_sat', $_POST['loc_sat']);
  } else {
    delete_post_meta($post_id, 'loc_sat');
  }

  if (!empty($_POST['loc_sun'])) {
    update_post_meta($post_id, 'loc_sun', $_POST['loc_sun']);
  } else {
    delete_post_meta($post_id, 'loc_sun');
  }

  if (!empty($_POST['location_logo'])) {
    update_post_meta($post_id, 'loc_logo', (int)$_POST['location_logo']);
  } else {
    delete_post_meta($post_id, 'loc_logo');
  }
}

add_shortcode('footer_location', 'shortcode_footer_location');
function shortcode_footer_location($atts) {
  $content = "";

  shortcode_atts(array('location' => ''), $atts);
  
  if ($atts['location'] != "") {
    $loc = new WP_Query(array('pagename' => $atts['location']));

    if ($loc->have_posts()) :
      while ($loc->have_posts()) : $loc->the_post();
        $the_addr = "";
        $addr_string = (metadata_exists('post', get_the_ID(), 'loc_noname')) ? "" : get_post_meta(get_the_ID(), 'loc_name', true)." ";
        
        if (metadata_exists('post', get_the_ID(), 'loc_address') || metadata_exists('post', get_the_ID(), 'loc_city') || metadata_exists('post', get_the_ID(), 'loc_state') || metadata_exists('post', get_the_ID(), 'loc_zip')) {
          if (metadata_exists('post', get_the_ID(), 'loc_address')) {
            $the_addr .= get_post_meta(get_the_ID(), 'loc_address', true);
            $addr_string .= get_post_meta(get_the_ID(), 'loc_address', true)." ";
          }

          if (metadata_exists('post', get_the_ID(), 'loc_address') && metadata_exists('post', get_the_ID(), 'loc_city') || metadata_exists('post', get_the_ID(), 'loc_state') || metadata_exists('post', get_the_ID(), 'loc_zip')) $the_addr .= "<br>\n";

          if (metadata_exists('post', get_the_ID(), 'loc_city')) {
            $the_addr .= get_post_meta(get_the_ID(), 'loc_city', true);
            $addr_string .= get_post_meta(get_the_ID(), 'loc_city', true)." ";
          }

          if (metadata_exists('post', get_the_ID(), 'loc_city') && metadata_exists('post', get_the_ID(), 'loc_state')) $the_addr .= ", ";

          if (metadata_exists('post', get_the_ID(), 'loc_state')) {
            $the_addr .= get_post_meta(get_the_ID(), 'loc_state', true);
            $addr_string .= get_post_meta(get_the_ID(), 'loc_state', true)." ";
          }

          if (metadata_exists('post', get_the_ID(), 'loc_city') || metadata_exists('post', get_the_ID(), 'loc_state') && metadata_exists('post', get_the_ID(), 'loc_zip')) $the_addr .= " ".get_post_meta(get_the_ID(), 'loc_zip', true);

          if (metadata_exists('post', get_the_ID(), 'loc_zip')) $addr_string .= get_post_meta(get_the_ID(), 'loc_zip', true);

          $addr_string = urlencode(trim($addr_string));
        }

        $content .= "<div>\n";
          $content .= "<h3>\n";
            $content .= get_the_title();

            $content .= ' <a href="https://maps.google.com/?q='.$addr_string.'" class="icon-loc" aria-label="Location"></a>'."\n";

            if (metadata_exists('post', get_the_ID(), 'loc_phone')) $content .= ' <a href="tel:'.preg_replace("/[^0-9]/", "", get_post_meta(get_the_ID(), 'loc_phone', true)).'" class="icon-phone" aria-label="Call"></a>'."\n";
          $content .= "</h3>\n";

          if (metadata_exists('post', get_the_ID(), 'loc_name')) $content .= "<h4>".get_post_meta(get_the_ID(), 'loc_name', true)."</h4>\n";

          $content .= $the_addr."\n";

          if (metadata_exists('post', get_the_ID(), 'loc_phone')) $content .= '<br><a href="tel:'.preg_replace("/[^0-9]/", "", get_post_meta(get_the_ID(), 'loc_phone', true)).'" class="text-phone" aria-label="Call">'.get_post_meta(get_the_ID(), 'loc_phone', true).'</a>'."\n";
        $content .= "</div>\n";
      endwhile;
    endif;

    wp_reset_postdata();
  }

  return $content;
}


/*
*  Trade Show Schedule
*/
add_action('init', 'schedule');
function schedule() {
  register_post_type('schedule', array(
    'labels' => array(
      'name' => 'Trade Show Schedule',
      'singular_name' => 'Event',
      'add_new_item' => 'Add New Event',
      'edit_item' => 'Edit Event',
      'search_items' => 'Search Events',
      'not_found' => 'No Events found'
    ),
    'show_ui' => true,
    'menu_position' => 56,
    'menu_icon' => 'dashicons-calendar-alt',
    'supports' => array('title', 'editor', 'thumbnail')
  ));
}

// Schedule admin index page
add_action('admin_head', 'schedule_remove_date_filter');
function schedule_remove_date_filter() {
  if (get_post_type() == 'schedule') add_filter('months_dropdown_results', '__return_empty_array');
}

add_filter('manage_edit-schedule_sortable_columns', 'set_custom_schedule_sortable_columns');
function set_custom_schedule_sortable_columns($columns) {
  unset($columns['title']);
  return $columns;
}

add_action('pre_get_posts', 'schedule_orderby_columns', 1);
function schedule_orderby_columns($query) {
  if (is_admin() && $query->get('post_type') == "schedule") {
    $query->set('meta_query', array(array('key' => 'event_end_date')));
    $query->set('orderby', 'meta_value');
    $query->set('order', 'DESC');
  }
}

add_filter('manage_schedule_posts_columns', 'set_custom_edit_schedule_columns');
function set_custom_edit_schedule_columns($columns) {
  unset($columns['date']);
  $columns['title'] = "Event";
  $columns['event_start_date'] = "Start Date";
  $columns['event_end_date'] = "End Date";
  return $columns;
}

add_action('manage_schedule_posts_custom_column', 'schedule_posts_custom_column', 10, 2);
function schedule_posts_custom_column($column, $post_id) {
  switch ($column) {
    case 'event_start_date' :
      echo get_post_meta($post_id, 'event_start_date', true);
      break;
    case 'event_end_date' :
      echo get_post_meta($post_id, 'event_end_date', true);
      break;
  }
}

// Schedule post type add/edit page
add_filter('enter_title_here', 'schedule_title');
function schedule_title($input) {
  if (get_post_type() === 'schedule') return "Add event name";
  return $input;
}

add_filter('wp_insert_post_data', 'schedule_custom_permalink');
function schedule_custom_permalink($data) {
  if ($data['post_type'] == 'schedule') {
    $data['post_name'] = sanitize_title($data['post_title']);
  }
  return $data;
}

add_action('edit_form_after_editor', 'schedule_edit_form_after_editor');
function schedule_edit_form_after_editor($post) {
  if (get_post_type() != 'schedule') return;

  echo '<h3 style="margin: 1.5em 0 0.2em;">Event URL</h3>'."\n";
  echo '<input type="text" name="event_url" value="'.$post->event_url.'" style="width: 100%;" placeholder="The website of the event"><br>'."\n";
  echo "This field can be left blank if it does not apply.<br>\n";

  echo '<h3 style="margin: 1.5em 0 0.2em;">IBOF Location</h3>'."\n";
  echo '<input type="text" name="event_location" value="'.$post->event_location.'" style="width: 100%;" placeholder="For example, &ldquo;West Coast Inflatables&rdquo;"><br>'."\n";
  echo "This field can be left blank if it does not apply.<br>\n";

  echo '<h3 style="margin: 1.5em 0 0.2em;">Booth Number</h3>'."\n";
  echo '<input type="text" name="event_booth" value="'.$post->event_booth.'" style="width: 100%;" placeholder="Just the number"><br>'."\n";
  echo "This field can be left blank if it does not apply.<br>\n";

  echo '<h3 style="margin: 1.5em 0 0.2em;">Directions</h3>'."\n";
  echo '<input type="text" name="event_directions" value="'.$post->event_directions.'" style="width: 100%;" placeholder="Enter the full address of the event"><br>'."\n";
  echo "This field can be left blank if it does not apply.<br>\n";
}

add_action('add_meta_boxes', 'schedule_mb');
function schedule_mb() {
  add_meta_box('schedule_metabox_dates', 'Event Dates', 'schedule_mb_dates', 'schedule', 'side', 'core');
  add_meta_box('schedule_metabox_caption', 'Image Caption', 'schedule_mb_caption', 'schedule', 'side', 'low');
}

function schedule_mb_dates($post) {
  echo "<strong>Event Start Date</strong><br>\n";
  echo '<input type="date" name="event_start_date" value="'.$post->event_start_date.'" style="width: 100%;"><br>'."\n";
  echo "<br>\n";
  echo "<strong>Event End Date</strong><br>\n";
  echo '<input type="date" name="event_end_date" value="'.$post->event_end_date.'" style="width: 100%;"><br>'."\n";
  echo "<br>\n";
  echo "If the event is only one day, enter the same date in the End Date field.\n";
}

function schedule_mb_caption($post) {
  echo '<input type="text" name="event_caption" value="'.$post->event_caption.'" style="width: 100%;">'."\n";
}

add_action('save_post', 'schedule_save');
function schedule_save($post_id) {
  if (get_post_type() != 'schedule') return;

  if (!empty($_POST['event_url'])) {
    update_post_meta($post_id, 'event_url', $_POST['event_url']);
  } else {
    delete_post_meta($post_id, 'event_url');
  }

  if (!empty($_POST['event_location'])) {
    update_post_meta($post_id, 'event_location', $_POST['event_location']);
  } else {
    delete_post_meta($post_id, 'event_location');
  }

  if (!empty($_POST['event_booth'])) {
    update_post_meta($post_id, 'event_booth', $_POST['event_booth']);
  } else {
    delete_post_meta($post_id, 'event_booth');
  }

  if (!empty($_POST['event_directions'])) {
    update_post_meta($post_id, 'event_directions', $_POST['event_directions']);
  } else {
    delete_post_meta($post_id, 'event_directions');
  }

  if (!empty($_POST['event_start_date'])) {
    update_post_meta($post_id, 'event_start_date', $_POST['event_start_date']);
  } else {
    delete_post_meta($post_id, 'event_start_date');
  }

  if (!empty($_POST['event_end_date'])) {
    update_post_meta($post_id, 'event_end_date', $_POST['event_end_date']);
  } else {
    delete_post_meta($post_id, 'event_end_date');
  }

  if (!empty($_POST['event_caption'])) {
    update_post_meta($post_id, 'event_caption', $_POST['event_caption']);
  } else {
    delete_post_meta($post_id, 'event_caption');
  }
}


/*
*  Green Footer
*/
add_action('edit_form_after_editor', 'green_footer_edit_form_after_editor');
function green_footer_edit_form_after_editor() {
  global $post;
  $template = get_post_meta($post->ID, '_wp_page_template', true);

  if ($template == "template-green-footer.php") {
    echo '<h3 style="margin: 1.5em 0 0.2em;">Green Footer Text</h3>'."\n";
    echo '<input type="text" name="green_footer_text" value="'.$post->green_footer_text.'" placeholder="Enter text here" style="width: 100%;">'."\n";
  }
}

add_action('save_post', 'green_footer_save');
function green_footer_save($post_id) {
  if (!empty($_POST['green_footer_text'])) {
    update_post_meta($post_id, 'green_footer_text', $_POST['green_footer_text']);
  } else {
    delete_post_meta($post_id, 'green_footer_text');
  }
}


// Method 1: Filter.
function my_acf_google_map_api( $api ){
    $api['key'] = 'xxx';
    return $api;
}
add_filter('acf/fields/google_map/api', 'my_acf_google_map_api');

// Method 2: Setting.
function my_acf_init() {
    acf_update_setting('google_api_key', 'xxx');
}
add_action('acf/init', 'my_acf_init');

?>