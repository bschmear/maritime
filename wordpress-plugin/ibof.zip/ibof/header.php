<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-RWWSQWX5BC">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-RWWSQWX5BC');
</script>
<!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=G-RWWSQWX5BC"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-RWWSQWX5BC'); </script> 
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />

  <title><?php if(!is_home() || !is_front_page()) wp_title('|', true, 'right'); //echo get_bloginfo('name'); ?></title>
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
<?php wp_head(); ?>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


  <!-- Google tag (gtag.js) -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-S1DDNVB5NZ"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-S1DDNVB5NZ');
  </script>
</head>

<body <?php body_class(); ?>>
  <div id="header-spacer"></div>

  <header>
    <?php wp_nav_menu(array('theme_location'=>'location-menu','container'=>'nav')); ?>

    <div class="site-width header-wrap">
      <a href="<?php echo home_url(); ?>" class="block " aria-label="Return to home page">
        <img src="<?php echo get_template_directory_uri(); ?>/images/logo.webp"
             alt="Logo"
             class="header-logo">
      </a>

      <div id="header-menus " class="flex items-center">
        <input type="checkbox" id="toggle-menu" role="button" class="hidden">
        <label for="toggle-menu" class="block w-8 h-8 sm:w-10 sm:h-10 cursor-pointer">
          <svg class="w-full h-full text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
          </svg>
        </label>
        <div id="header-top-main">
          <?php wp_nav_menu(array('theme_location'=>'top-menu','container'=>'nav')); ?>
          <?php wp_nav_menu(array('theme_location'=>'main-menu','container'=>'nav')); ?>
        </div> <!-- /#header-top-main -->
      </div> <!-- /#header-menus -->
    </div> <!-- /.site-width /.header-wrap -->
  </header>
