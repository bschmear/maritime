<?php
/**
 * Template Name: Contact
 */
get_header();
while (have_posts()) : the_post();
?>

<!-- ===== PAGE HERO ===== -->
<div class="contact-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden <?php echo !has_post_thumbnail() ? 'bg-[#111111]' : ''; ?>"
  <?php if (has_post_thumbnail()) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>

  <?php if (!has_post_thumbnail()) : ?>
  <div class="absolute inset-0 opacity-[0.04]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <?php endif; ?>

  <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">Get In Touch</span>
    </div>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== CONTACT BODY ===== -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-10">

      <!-- ===== LEFT: Info sidebar ===== -->
      <aside class="lg:col-span-4 flex flex-col gap-6">

        <!-- Intro content -->
        <?php $contact_content = get_the_content(); if ($contact_content) : ?>
        <div class="bg-white rounded-md shadow-sm border border-gray-100 overflow-hidden">
          <div class="bg-[#111111] px-6 py-4">
            <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">How Can We Help?</h3>
          </div>
          <div class="p-7 text-gray-500 text-lg leading-relaxed">
            <?php the_content(); ?>
          </div>
        </div>
        <?php endif; ?>

        <!-- Contact info cards -->
        <div class="bg-white rounded-md shadow-sm border border-gray-100 overflow-hidden">
          <div class="bg-[#111111] px-6 py-4">
            <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Contact Info</h3>
          </div>
          <div class="divide-y divide-gray-100">

            <div class="flex items-center gap-4 px-6 py-5">
              <span class="flex-shrink-0 w-10 h-10 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                <svg class="w-5 h-5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 8V5z"/>
                </svg>
              </span>
              <div>
                <p class="text-gray-400 text-xs font-bold uppercase tracking-widest mb-0.5">Phone</p>
                <a href="tel:85569836337" class="text-gray-900 font-black text-lg hover:text-[#ff9101] transition-colors duration-150">
                  (855) MYTENDER
                </a>
              </div>
            </div>

            <div class="flex items-center gap-4 px-6 py-5">
              <span class="flex-shrink-0 w-10 h-10 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                <svg class="w-5 h-5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                </svg>
              </span>
              <div>
                <p class="text-gray-400 text-xs font-bold uppercase tracking-widest mb-0.5">Email</p>
                <a href="mailto:info@inflatableboatsofflorida.com" class="text-gray-900 font-black text-base hover:text-[#ff9101] transition-colors duration-150 break-all">
                  info@inflatableboatsofflorida.com
                </a>
              </div>
            </div>

            <div class="flex items-center gap-4 px-6 py-5">
              <span class="flex-shrink-0 w-10 h-10 bg-[#ff9101]/10 flex items-center justify-center rounded-sm">
                <svg class="w-5 h-5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                  <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
              </span>
              <div>
                <p class="text-gray-400 text-xs font-bold uppercase tracking-widest mb-0.5">Locations</p>
                <a href="<?php echo home_url('/locations/'); ?>" class="text-gray-900 font-black text-base hover:text-[#ff9101] transition-colors duration-150">
                  View All Locations &rarr;
                </a>
              </div>
            </div>

          </div>
        </div>

        <!-- Quick links -->
        <div class="bg-white rounded-md shadow-sm border border-gray-100 overflow-hidden">
          <div class="bg-[#111111] px-6 py-4">
            <h3 class="text-white font-black text-sm uppercase tracking-[0.25em]">Quick Links</h3>
          </div>
          <div class="p-5 flex flex-col gap-3">
            <a href="<?php echo home_url('/boats/'); ?>"
              class="flex items-center justify-between gap-2 border-2 border-gray-100 hover:border-[#ff9101] text-gray-600 hover:text-[#ff9101] font-bold text-sm uppercase tracking-widest px-5 py-3 transition-all duration-150">
              Browse Boats
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
              </svg>
            </a>
            <a href="<?php echo home_url('/my-boat-quotes/'); ?>"
              class="flex items-center justify-between gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold text-sm uppercase tracking-widest px-5 py-3 transition-all duration-150">
              Request a Quote
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
              </svg>
            </a>
          </div>
        </div>

      </aside>


      <!-- ===== RIGHT: Form ===== -->
      <div class="lg:col-span-8">
        <div class="bg-white rounded-md shadow-sm border border-gray-100 overflow-hidden">

          <div class="bg-[#111111] px-8 py-5 flex items-center gap-3">
            <svg class="w-5 h-5 text-[#ff9101] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
            </svg>
            <h2 class="text-white font-black text-sm uppercase tracking-[0.25em]">Send Us a Message</h2>
          </div>

          <form action="<?php echo get_template_directory_uri(); ?>/form-contact.php"
            method="POST" id="form-contact" novalidate class="p-8 md:p-10">

            <!-- Honeypot -->
            <input type="text" name="username" tabindex="-1" aria-hidden="true" autocomplete="new-password" class="hidden">

            <?php
            $ct_input    = "w-full border-0 border-b-2 border-gray-200 focus:border-[#ff9101] bg-transparent px-0 py-2.5 text-base text-gray-800 font-semibold focus:outline-none focus:ring-0 transition-colors duration-150 placeholder:text-gray-300";
            $ct_label    = "block text-xs font-bold uppercase tracking-[0.2em] text-gray-400 mb-1";
            ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-8">
              <div>
                <label class="<?php echo $ct_label; ?>">Name <span class="text-[#ff9101]">*</span></label>
                <input type="text" name="name" placeholder="Your full name" required class="<?php echo $ct_input; ?>">
              </div>
              <div>
                <label class="<?php echo $ct_label; ?>">Email <span class="text-[#ff9101]">*</span></label>
                <input type="email" name="email" placeholder="your@email.com" required class="<?php echo $ct_input; ?>">
              </div>
              <div class="sm:col-span-2">
                <label class="<?php echo $ct_label; ?>">Phone <span class="text-[#ff9101]">*</span></label>
                <input type="tel" name="phone" placeholder="(000) 000-0000" required class="<?php echo $ct_input; ?>">
              </div>
            </div>

            <div class="mb-8">
              <label class="<?php echo $ct_label; ?>">Message <span class="text-[#ff9101]">*</span></label>
              <textarea name="message" required rows="6"
                placeholder="How can we help you?"
                class="w-full border-2 border-gray-200 focus:border-[#ff9101] bg-transparent px-4 py-3 text-base text-gray-800 font-semibold focus:outline-none focus:ring-0 transition-colors duration-150 resize-none rounded-sm placeholder:text-gray-300 mt-1"></textarea>
            </div>

            <input type="hidden" name="id" value="<?php echo $post->ID; ?>">

            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pt-6 border-t border-gray-100">
              <div class="g-recaptcha" data-sitekey="<?php echo get_theme_mod('fg_recaptcha_site_key'); ?>"></div>
              <button type="submit" id="submit"
                class="flex-shrink-0 w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] disabled:opacity-40 text-white font-black text-sm uppercase tracking-[0.2em] px-10 py-4 transition-all duration-200">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/>
                </svg>
                Send Message
              </button>
            </div>

          </form>
        </div>
      </div>

    </div>
  </div>
</div>


<!-- ===== SUCCESS MODAL ===== -->
<div id="ct-modal" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-6 hidden">
  <div class="bg-white rounded-md shadow-2xl w-full max-w-md overflow-hidden">
    <div class="bg-[#111111] px-6 py-4 flex items-center justify-between">
      <span class="text-white font-black text-sm uppercase tracking-[0.25em]">Message Sent</span>
      <button id="ct-modal-close" class="text-white/40 hover:text-white transition-colors">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
        </svg>
      </button>
    </div>
    <div class="p-8 text-center">
      <svg class="w-14 h-14 text-[#ff9101] mx-auto mb-4" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
      </svg>
      <div id="ct-modal-content" class="text-gray-600 text-lg leading-relaxed"></div>
    </div>
  </div>
</div>


<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<script>
(function () {
  const ctForm    = document.getElementById('form-contact');
  const ctModal   = document.getElementById('ct-modal');
  const ctClose   = document.getElementById('ct-modal-close');
  const ctContent = document.getElementById('ct-modal-content');
  const ctSubmit  = document.getElementById('submit');

  ctForm.addEventListener('submit', function (e) {
    e.preventDefault();

    let valid = true;

    ctForm.querySelectorAll('[required]').forEach(function (el) {
      if (!el.checkValidity()) {
        el.classList.add('border-red-400');
        valid = false;
      } else {
        el.classList.remove('border-red-400');
      }
    });

    if (!valid) return;

    ctSubmit.disabled = true;
    ctSubmit.innerHTML = '<svg class="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path></svg> Sending...';

    fetch(ctForm.action, { method: 'POST', body: new FormData(ctForm) })
      .then(r => r.text())
      .then(function (result) {
        ctContent.innerHTML = result;
        ctModal.classList.remove('hidden');
        ctForm.reset();
        ctForm.querySelectorAll('.border-red-400').forEach(el => el.classList.remove('border-red-400'));
        ctSubmit.disabled = false;
        ctSubmit.innerHTML = '<svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg> Sent!';
      });
  });

  ctClose.addEventListener('click', function () { ctModal.classList.add('hidden'); });
  ctModal.addEventListener('click', function (e) { if (e.target === ctModal) ctModal.classList.add('hidden'); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') ctModal.classList.add('hidden'); });
})();
</script>

<?php
endwhile;
get_footer();
?>
