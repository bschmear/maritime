<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../../../wp-includes/PHPMailer/Exception.php';
require '../../../wp-includes/PHPMailer/PHPMailer.php';
require '../../../wp-includes/PHPMailer/SMTP.php';

include_once '../../../wp-load.php';

$feedback = 'Unable to submit your application. Please try again or contact us directly.';

$recaptcha_response = isset($_POST['g-recaptcha-response']) ? sanitize_text_field(wp_unslash($_POST['g-recaptcha-response'])) : '';
$verify = wp_remote_get('https://www.google.com/recaptcha/api/siteverify?secret=' . rawurlencode(get_theme_mod('fg_recaptcha_secret_key')) . '&response=' . rawurlencode($recaptcha_response));
$responsekeys = json_decode(wp_remote_retrieve_body($verify));

if (empty($responsekeys->success)) {
  echo 'reCAPTCHA verification failed. Please try again.';
  exit;
}

$career_id = isset($_POST['career_id']) ? (int) $_POST['career_id'] : 0;
$career = $career_id ? get_post($career_id) : null;

if (!$career || $career->post_type !== 'careers' || !ibof_career_is_active($career_id)) {
  echo 'This position is no longer available.';
  exit;
}

$name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
$email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
$phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
$message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
$honeypot = isset($_POST['username']) ? sanitize_text_field(wp_unslash($_POST['username'])) : '';

if ($name === '' || $email === '' || $phone === '' || $message === '') {
  echo 'Some required information is missing. Please go back and complete all fields.';
  exit;
}

if ($honeypot !== '') {
  echo 'Thank you for your application. We will be in touch soon.';
  exit;
}

$recipient = ibof_get_career_recipient_email($career_id);
if (!$recipient) {
  echo 'This position is not accepting applications at the moment. Please contact us directly.';
  exit;
}

$job_title = ibof_get_career_title($career_id);
$job_location = ibof_get_career_location_name($career_id);

$mail = new PHPMailer();
$mail->SMTPAuth = true;
$mail->Username = get_theme_mod('fg_smtp_user');
$mail->Password = get_theme_mod('fg_smtp_pass');
$mail->Host = get_theme_mod('fg_smtp_host');
$mail->Port = get_theme_mod('fg_smtp_port');

$mail->setFrom(get_theme_mod('fg_smtp_user'), 'Career Application');
$mail->addReplyTo($email, $name);
$mail->addAddress($recipient);
$mail->Subject = 'Career Application: ' . $job_title;

$body = "Position: {$job_title}\n";
if ($job_location) {
  $body .= "Location: {$job_location}\n";
}
$body .= "Applicant: {$name}\n";
$body .= "Email: {$email}\n";
$body .= "Phone: {$phone}\n\n";
$body .= "Message:\n{$message}\n";
$body .= "\nSubmitted from: " . get_permalink($career_id) . "\n";

$mail->Body = $body;

try {
  if ($mail->send()) {
    echo 'Thank you for your application. We will review your information and be in touch soon.';
  } else {
    echo $feedback;
  }
} catch (Exception $e) {
  echo $feedback;
}
