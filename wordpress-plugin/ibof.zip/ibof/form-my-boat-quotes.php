<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require '../../../wp-includes/PHPMailer/Exception.php';
require '../../../wp-includes/PHPMailer/PHPMailer.php';
require '../../../wp-includes/PHPMailer/SMTP.php';

include_once "../../../wp-load.php";

$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".get_theme_mod('fg_recaptcha_secret_key')."&response=".$_POST['g-recaptcha-response']);
$responsekeys = json_decode($response);

if ($responsekeys->success) {



  if ($_POST['name'] != "" && $_POST['email'] != "" && $_POST['phone'] != "") {
    if ($_POST['username'] == "") {

        if (empty($_POST['boatlist']) || !is_array($_POST['boatlist'])) {
          echo "Please select at least one boat before submitting.";
          exit;
        }

      // Sanitize all inputs up front
      $name     = sanitize_text_field($_POST['name']);
      $email    = sanitize_email($_POST['email']);
      $phone    = sanitize_text_field($_POST['phone']);
      $message  = sanitize_textarea_field($_POST['message'] ?? '');
      $callback = sanitize_text_field($_POST['callback'] ?? '');
      $timeline = sanitize_text_field($_POST['timeline'] ?? '');
      $budget   = sanitize_text_field($_POST['budget'] ?? '');
      $seatrial = sanitize_text_field($_POST['seatrial'] ?? '');

      $mail = new PHPMailer();
      $mail->CharSet = 'UTF-8';

      $mail->setFrom(get_theme_mod('fg_smtp_user'), get_post_meta($_POST['id'], 'form_from_name', true));
      $mail->addReplyTo($email);

      $emails = explode(PHP_EOL, get_post_meta($_POST['id'], 'form_send_to', true));
      foreach ($emails as $email_addr) {
        $mail->addAddress(trim($email_addr));
      }

      if (isset($_POST['location'])) {
        foreach ($_POST['location'] as $key => $value) {
          $value = sanitize_text_field($value);
          if ($value == "Cape Canaveral") $mail->addAddress("Sales@spacecoastinflatables.com");
          if ($value == "Ft. Lauderdale")  $mail->addAddress("Sales@lauderdaleinflatables.com");
          if ($value == "Naples")          $mail->addAddress("Sales@gulfcoastinflatables.com");
          if ($value == "Sarasota")        $mail->addAddress("Sales@westcoastinflatables.com");
        }
      }

      $mail->Subject = get_post_meta($_POST['id'], 'form_subject', true);
 

      $Message = $name . "\n";
      $Message .= $email . "\n";
      $Message .= $phone . "\n\n";

      $boatlist = "";
      if (isset($_POST['boatlist'])) {
        $Message .= "My Boats:\n";
        foreach ($_POST['boatlist'] as $key => $boat_title) {
          $boat_title = sanitize_text_field($boat_title);
          $Message .= $boat_title . "\n";

          if (isset($_POST['boat_make'][$key]) && !empty($_POST['boat_make'][$key])) {
            $Message .= "  Make: " . sanitize_text_field($_POST['boat_make'][$key]) . "\n";
          }
          if (isset($_POST['boat_length'][$key]) && !empty($_POST['boat_length'][$key])) {
            $Message .= "  Length: " . sanitize_text_field($_POST['boat_length'][$key]) . "'\n";
          }
          if (isset($_POST['boat_weight'][$key]) && !empty($_POST['boat_weight'][$key])) {
            $Message .= "  Weight: " . sanitize_text_field($_POST['boat_weight'][$key]) . " lbs\n";
          }
          if (isset($_POST['boat_capacity'][$key]) && !empty($_POST['boat_capacity'][$key])) {
            $Message .= "  Capacity: " . sanitize_text_field($_POST['boat_capacity'][$key]) . " pax\n";
          }
          if (isset($_POST['boat_hp'][$key]) && !empty($_POST['boat_hp'][$key])) {
            $Message .= "  Max HP: " . sanitize_text_field($_POST['boat_hp'][$key]) . " HP\n";
          }
          $Message .= "\n";

          $boatlist .= $boat_title . ", ";
        }
        $Message .= "\n";
        $boatlist = rtrim($boatlist, ', ');
      }

      $location = "";
      if (isset($_POST['location'])) {
        $location_parts = array_map('sanitize_text_field', $_POST['location']);
        $location = implode(", ", $location_parts);
        $Message .= "Preferred or nearest IBOF location: " . $location . "\n\n";
      }

      $interest = "";
      if (isset($_POST['interest'])) {
        $interest_parts = array_map('sanitize_text_field', $_POST['interest']);
        $interest = implode(", ", $interest_parts);
        $Message .= "I am also interested in: " . $interest . "\n\n";
      }

      if (!empty($seatrial)) {
        $Message .= $seatrial . "\n\n";
      }

      if (!empty($timeline)) $Message .= "Purchase Timeline: " . $timeline . "\n\n";
      if (!empty($budget))   $Message .= "Budget Range: " . $budget . "\n\n";
      if (!empty($callback)) $Message .= "Best time for call back is " . $callback . "\n\n";

      $Message .= $message . "\n";

      $mail->Body = $Message;
      $mail->send();

      // Add to MailChimp
      $mcdata = array(
        'email'     => $email,
        'status'    => 'subscribed',
        'firstname' => $name,
        'phone'     => $phone
      );

      function syncMailchimp($mcdata) {
        $memberId   = md5(strtolower($mcdata['email']));
        $dataCenter = substr(get_theme_mod('fg_mailchimp_api'), strpos(get_theme_mod('fg_mailchimp_api'), '-') + 1);
        $url        = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . get_theme_mod('fg_mailchimp_list_id') . '/members/' . $memberId;

        $json = json_encode(array(
          'email_address' => $mcdata['email'],
          'status'        => $mcdata['status'],
          'merge_fields'  => [
            'FNAME' => $mcdata['firstname'],
            'PHONE' => $mcdata['phone']
          ]
        ));

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_USERPWD,        'user:' . get_theme_mod('fg_mailchimp_api'));
        curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT,        10);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST,  'PUT');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS,     $json);

        $result   = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $httpCode;
      }

      syncMailchimp($mcdata);

      // Add to local database
      date_default_timezone_set('America/New_York');
      global $wpdb;
      $wpdb->insert('boat_quotes',
        array(
          'name'           => $name,
          'email'          => $email,
          'phone'          => $phone,
          'boatlist'       => $boatlist,
          'location'       => $location,
          'interest'       => $interest,
          'seatrial'       => $seatrial,
          'callback'       => $callback,
          'timeline'       => $timeline,
          'budget'         => $budget,
          'message'        => $message,
          'date_submitted' => date("Y-m-d H:i:s")
        )
      );

      $feedback = get_post_meta($_POST['id'], 'form_success', true);

    } // Honeypot
  } else {
    $feedback = "Some required information is missing! Please go back and make sure all required fields are filled.";
  } // Required fields

  echo $feedback;
} // reCAPTCHA
?>
