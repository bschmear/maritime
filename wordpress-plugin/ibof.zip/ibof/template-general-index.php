<?php
/**
 * Template Name: General Index
 */
get_header();
while (have_posts()) : the_post();

$hero_eyebrow  = get_field('hero_eyebrow');
$hero_subtitle = get_field('hero_subtitle');
$hero_image    = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
$page_id       = get_the_ID();
$ancestors     = array_reverse(get_post_ancestors($page_id));
?>

<!-- ===== PAGE HERO ===== -->
<div class="boats-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden <?php echo !$hero_image ? 'bg-[#111111]' : ''; ?>"
  <?php if ($hero_image) echo 'style="background-image: url('.esc_url($hero_image).');"'; ?>>

  <?php if (!$hero_image) : ?>
    <div class="absolute inset-0 opacity-[0.04]"
      style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <?php endif; ?>

  <div class="absolute inset-0 bg-gradient-to-t <?php echo $hero_image ? 'from-[#0d0d0d] via-[#0d0d0d]/80 to-black/30' : 'from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20'; ?>"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <?php if ($hero_eyebrow) : ?>
      <div class="flex items-center gap-3 mb-4">
        <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
        <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">
          <?php echo esc_html($hero_eyebrow); ?>
        </span>
      </div>
    <?php endif; ?>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
    <?php if ($hero_subtitle) : ?>
      <div class="text-white/80 text-lg md:text-xl leading-relaxed max-w-2xl mt-4">
        <?php echo esc_html($hero_subtitle); ?>
      </div>
    <?php endif; ?>
    <?php if (!is_front_page()) : ?>
      <!-- Breadcrumb -->
      <div class="flex items-center gap-2 text-white/60 text-sm mt-6">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="hover:text-white transition-colors">Home</a>
        <?php foreach ($ancestors as $ancestor_id) : ?>
          <span>/</span>
          <a href="<?php echo esc_url(get_permalink($ancestor_id)); ?>" class="hover:text-white transition-colors">
            <?php echo esc_html(get_the_title($ancestor_id)); ?>
          </a>
        <?php endforeach; ?>
        <span>/</span>
        <span class="text-white"><?php echo esc_html(get_the_title()); ?></span>
      </div>
    <?php endif; ?>
  </div>
</div>


<div class="h-[3px] bg-[#ff9101]"></div>

<!-- ===== LOCATIONS GRID ===== -->
<div class="bg-[#f7f7f7] py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

      <div class="">
        <?php the_content(); ?>
      </div>

  </div>
</div>

<?php
endwhile;

get_footer();
?>