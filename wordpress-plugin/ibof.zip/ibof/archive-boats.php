<?php
get_header();


// Get URL parameters
$boats_view = get_query_var('boats_view');
$boats_make = get_query_var('boats_make');

// Set query vars for content template
set_query_var('boats_view', $boats_view);
set_query_var('boats_make', $boats_make);

// Determine page title and description
$page_title = 'Our Boats';
$page_subtitle = 'Find the perfect boat for your needs';
$hero_image = '';

if ($boats_make) {
  $make_term = get_term_by('slug', $boats_make, 'make');
  if ($make_term) {
    $page_title = $make_term->name . ' Boats';
    $page_subtitle = 'Explore our ' . $make_term->name . ' inflatable boats';
    $hero_image = get_term_meta($make_term->term_id, 'tax_image', true);
  }
} elseif ($boats_view === 'makes') {
  $page_title = 'Boat Brands';
  $page_subtitle = 'Browse boats by manufacturer';
}
?>

<!-- ===== PAGE HERO ===== -->
<div class="boats-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden <?php echo !$hero_image ? 'bg-[#111111]' : ''; ?>"
  <?php if ($hero_image) echo 'style="background-image: url('.esc_url($hero_image).');"'; ?>>

  <?php if (!$hero_image) : ?>
    <div class="absolute inset-0 opacity-[0.04]"
      style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <?php endif; ?>

  <div class="absolute inset-0 bg-gradient-to-t <?php echo $hero_image ? 'from-[#0d0d0d] via-[#0d0d0d]/80 to-black/30' : 'from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20'; ?>"></div>
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">
        <?php echo $boats_make ? 'Boat Brand' : 'Our Fleet'; ?>
      </span>
    </div>
    <h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">
      <?php echo esc_html($page_title); ?>
    </h1>
    <?php if ($page_subtitle) : ?>
      <div class="text-white/80 text-lg md:text-xl leading-relaxed max-w-2xl mt-4">
        <?php echo esc_html($page_subtitle); ?>
      </div>
    <?php endif; ?>
    <!-- Breadcrumb -->
    <div class="flex items-center gap-2 text-white/60 text-sm mt-6">
      <a href="<?php echo home_url(); ?>" class="hover:text-white transition-colors">Home</a>
      <span>/</span>
      <a href="<?php echo home_url('/boats/'); ?>" class="hover:text-white transition-colors">Boats</a>
      <?php if ($boats_view === 'makes') : ?>
        <span>/</span>
        <span class="text-white">Makes</span>
      <?php elseif ($boats_make) : ?>
        <span>/</span>
        <a href="<?php echo home_url('/boats/make/'); ?>" class="hover:text-white transition-colors">Makes</a>
        <span>/</span>
        <span class="text-white"><?php echo esc_html($make_term->name); ?></span>
      <?php endif; ?>
    </div>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>

<?php get_template_part('content', 'boats'); ?>

<div class="waves boats-contact">
  <div class="site-width">
    Need help finding the boat just right for you?
    <a href="<?php echo home_url(); ?>/contact/">Contact Us</a>
  </div> <!-- /.site-width -->
</div> <!-- /.boats-contact -->

<?php get_footer(); ?>
