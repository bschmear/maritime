<?php
global $wp;

$location_arg = "none";
if (!empty($args['location'])) $location_arg = $args['location'];
if (isset($_REQUEST['location'])) $location_arg = $_REQUEST['location'];

// Check for URL-based make filtering
$boats_view = get_query_var('boats_view');
$boats_make = get_query_var('boats_make');

$args = array('post_type' => 'boats', 'order' => 'ASC', 'posts_per_page' => 50);

// Handle pagination
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args['paged'] = $paged;

$url_type = array();
if (isset($_REQUEST['type'])) {
  $raw_type = $_REQUEST['type'];
  $url_type = is_array($raw_type) ? $raw_type : array($raw_type);
  $url_type = array_values(array_filter(array_map('sanitize_text_field', $url_type)));
} elseif (trim((string) ($_SERVER['QUERY_STRING'] ?? '')) === '' && !$boats_make) {
  // Clean /boats/ URL only: default to "new" inventory
  $url_type = array('new');
}

$make_filter = isset($_REQUEST['make']) ? sanitize_text_field(wp_unslash($_REQUEST['make'])) : $boats_make;

$length_min = isset($_REQUEST['length_min']) ? sanitize_text_field(wp_unslash($_REQUEST['length_min'])) : '';
$length_max = isset($_REQUEST['length_max']) ? sanitize_text_field(wp_unslash($_REQUEST['length_max'])) : '';
$length_min = $length_min !== '' && is_numeric($length_min) ? (float) $length_min : null;
$length_max = $length_max !== '' && is_numeric($length_max) ? (float) $length_max : null;
if ($length_min !== null && $length_max !== null && $length_min > $length_max) {
  $tmp = $length_min;
  $length_min = $length_max;
  $length_max = $tmp;
}

$length_arr = '';
if ($length_min !== null && $length_max !== null) {
  $length_arr = array('key' => 'boat_length', 'value' => array($length_min, $length_max), 'type' => 'numeric', 'compare' => 'BETWEEN');
} elseif ($length_min !== null) {
  $length_arr = array('key' => 'boat_length', 'value' => $length_min, 'type' => 'numeric', 'compare' => '>=');
} elseif ($length_max !== null) {
  $length_arr = array('key' => 'boat_length', 'value' => $length_max, 'type' => 'numeric', 'compare' => '<=');
}

$weight_select  = (isset($_REQUEST['weight'])     && $_REQUEST['weight']     != "") ? explode(',', $_REQUEST['weight']) : array();
$weight_arr     = !empty($weight_select)  ? array('key' => 'boat_weight',     'value' => $weight_select,  'type' => 'numeric', 'compare' => 'BETWEEN') : "";
$pass_select    = (isset($_REQUEST['passengers']) && $_REQUEST['passengers'] != "") ? explode(',', $_REQUEST['passengers']) : array();
$passengers_arr = !empty($pass_select)    ? array('key' => 'boat_passengers', 'value' => $pass_select,    'type' => 'numeric', 'compare' => 'BETWEEN') : "";
$hp_select      = (isset($_REQUEST['hp'])         && $_REQUEST['hp']         != "") ? explode(',', $_REQUEST['hp']) : array();
$hp_arr         = !empty($hp_select)      ? array('key' => 'boat_hp',         'value' => $hp_select,      'type' => 'numeric', 'compare' => 'BETWEEN') : "";
$location_arr   = ($location_arg != "none") ? array('taxonomy' => 'location', 'field' => 'slug', 'terms' => $location_arg) : "";

$tax_query = array('relation' => 'AND');
if (!empty($url_type)) {
  $tax_query[] = array('taxonomy' => 'type', 'field' => 'slug', 'terms' => $url_type);
}
if ($make_filter != '') {
  $tax_query[] = array('taxonomy' => 'make', 'field' => 'slug', 'terms' => $make_filter);
}
if ($location_arr !== '') {
  $tax_query[] = $location_arr;
}
if (count($tax_query) > 1) {
  $args['tax_query'] = $tax_query;
}

// Exclude sold boats by default unless show_sold is checked
if (!isset($_GET['show_sold']) || !$_GET['show_sold']) {
    $sold_arr = array(
        'key' => 'boat_sold',
        'compare' => 'NOT EXISTS' // Exclude boats that have the boat_sold meta key (which means they're sold)
    );
} else {
    $sold_arr = "";
}

$meta_query = array('relation' => 'AND');
if ($length_arr !== '') {
  $meta_query[] = $length_arr;
}
if ($weight_arr !== '') {
  $meta_query[] = $weight_arr;
}
if ($passengers_arr !== '') {
  $meta_query[] = $passengers_arr;
}
if ($hp_arr !== '') {
  $meta_query[] = $hp_arr;
}
if ($sold_arr !== '') {
  $meta_query[] = $sold_arr;
}
if (count($meta_query) > 1) {
  $args['meta_query'] = $meta_query;
}

$boats = ($boats_view !== 'makes') ? new WP_Query($args) : "";

$request_make       = $make_filter;
$request_length_min = isset($_REQUEST['length_min']) ? sanitize_text_field(wp_unslash($_REQUEST['length_min'])) : '';
$request_length_max = isset($_REQUEST['length_max']) ? sanitize_text_field(wp_unslash($_REQUEST['length_max'])) : '';
$request_weight     = isset($_REQUEST['weight']) ? sanitize_text_field(wp_unslash($_REQUEST['weight'])) : '';
$request_passengers = isset($_REQUEST['passengers']) ? sanitize_text_field(wp_unslash($_REQUEST['passengers'])) : '';
$request_hp         = isset($_REQUEST['hp']) ? sanitize_text_field(wp_unslash($_REQUEST['hp'])) : '';

// Get current make term for display
$make_term = null;
if ($boats_make) {
  $make_term = get_term_by('slug', $boats_make, 'make');
}

// Pre-fetch makes for brand view
$makes = get_categories(array('taxonomy' => 'make'));

// Distinct boat lengths (feet) for range dropdowns
$bfl_lengths = array();
if ($boats_view !== 'makes') {
  $bfl_lposts = get_posts(array(
    'post_type'      => 'boats',
    'meta_key'       => 'boat_length',
    'orderby'        => 'meta_value_num',
    'order'          => 'ASC',
    'posts_per_page' => -1,
  ));
  foreach ($bfl_lposts as $bfl_lp) {
    $lv = get_post_meta($bfl_lp->ID, 'boat_length', true);
    if ($lv !== '' && $lv !== null && is_numeric($lv)) {
      $bfl_lengths[] = (float) $lv;
    }
  }
  $bfl_lengths = array_values(array_unique($bfl_lengths, SORT_NUMERIC));
  sort($bfl_lengths, SORT_NUMERIC);
}
?>

<?php if ($boats_view !== 'makes') : ?>
<?php
$form_action = home_url('/boats/');
if ($boats_make) {
  $form_action = home_url('/boats/make/' . $boats_make . '/');
}
?>
<form id="boats-filter-form" action="<?php echo esc_url($form_action); ?>" method="get" name="filter">
<?php endif; ?>

  <!-- ===== STICKY FILTER BAR ===== -->
  <?php if ($boats_view !== 'makes' && $boats_view !== 'makes') : ?>

  <div class="sticky lg:top-[52px] z-30 shadow-lg">

    <!-- Dark top row: title + type checkboxes -->
    <div class="bg-[#111111]">
      <div class="max-w-screen-2xl mx-auto px-6 md:px-14 py-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">

        <span class="text-white text-md font-bold uppercase tracking-[0.25em] flex items-center gap-2 flex-shrink-0">
          <svg class="w-5 h-5 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"/>
            <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35"/>
          </svg>
          <?php echo $boats_make && $make_term ? 'Filter ' . esc_html($make_term->name) . ' Boats' : 'Filter Boats'; ?>
        </span>

        <!-- Type checkboxes — auto-submit on change like original -->
        <div class="flex flex-wrap gap-2">
          <?php
          $filter_types = get_categories(array('taxonomy' => 'type', 'hide_empty' => false));
          foreach ($filter_types as $ft) {
            $ft_checked = in_array($ft->slug, $url_type) ? 'checked' : '';
            echo '
            <label class="relative flex items-center gap-1.5 cursor-pointer
              text-md font-bold uppercase tracking-widest px-4 py-1.5
              border border-white/20 text-white/50
              hover:border-[#ff9101] hover:text-[#ff9101]
              has-[:checked]:bg-[#ff9101] has-[:checked]:border-[#ff9101] has-[:checked]:text-white
              transition-all duration-150">
              <input type="checkbox" name="type[]" value="'.$ft->slug.'" '.$ft_checked.'
                onchange="var f=this.closest(\'form\');if(f)f.submit();" class="sr-only">
              '.$ft->name.'
            </label>';
          }
          ?>
        </div>

      </div>
    </div>

    <!-- White bottom row: selects -->
    <div class="bg-white border-b border-gray-200">
      <div class="max-w-screen-2xl mx-auto px-6 md:px-14 py-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 xl:grid-cols-8 gap-x-6 gap-y-3 items-end">

        <?php
        $bfl_sel = "w-full border-0 border-b-2 border-gray-200 focus:border-[#ff9101] bg-transparent px-0 py-2 text-md text-gray-800 font-semibold focus:outline-none focus:ring-0 transition-colors duration-150 appearance-none cursor-pointer";
        $bfl_lbl = "block text-[12px] font-bold uppercase tracking-[0.2em] text-gray-400 mb-1";
        ?>

        <!-- Make -->
        <div>
          <label class="<?php echo $bfl_lbl; ?>">Make</label>
          <select name="make" onchange="var f=this.closest('form');if(f)f.submit();" class="<?php echo $bfl_sel; ?>">
            <option value="">All Makes</option>
            <?php
            foreach ($makes as $make)
              echo '<option value="'.$make->slug.'"'.($make->slug == $request_make ? ' selected' : '').'>'.$make->name.'</option>';
            ?>
          </select>
        </div>

        <!-- Length range (ft) -->
        <div class="col-span-2 sm:col-span-3 lg:col-span-2 xl:col-span-2">
          <span class="<?php echo $bfl_lbl; ?>">Length (ft)</span>
          <div class="flex flex-wrap items-end gap-2 sm:gap-3">
            <div class="flex-1 min-w-[100px]">
              <label class="block text-[11px] font-semibold text-gray-400 mb-0.5">From</label>
              <select name="length_min" onchange="var f=this.closest('form');if(f)f.submit();" class="<?php echo $bfl_sel; ?>">
                <option value="">Min</option>
                <?php
                foreach ($bfl_lengths as $bfl_l) {
                  $bfl_l = (float) $bfl_l;
                  $opt   = (floor($bfl_l) == $bfl_l) ? (string) (int) $bfl_l : (string) $bfl_l;
                  $min_sel = ($request_length_min !== '' && is_numeric($request_length_min) && (float) $request_length_min === $bfl_l);
                  echo '<option value="' . esc_attr($opt) . '"' . ($min_sel ? ' selected="selected"' : '') . '>' . esc_html($opt) . '′</option>';
                }
                ?>
              </select>
            </div>
            <span class="hidden sm:inline text-gray-300 font-bold pb-2 shrink-0">—</span>
            <div class="flex-1 min-w-[100px]">
              <label class="block text-[11px] font-semibold text-gray-400 mb-0.5">To</label>
              <select name="length_max" onchange="var f=this.closest('form');if(f)f.submit();" class="<?php echo $bfl_sel; ?>">
                <option value="">Max</option>
                <?php
                foreach ($bfl_lengths as $bfl_l) {
                  $bfl_l = (float) $bfl_l;
                  $opt   = (floor($bfl_l) == $bfl_l) ? (string) (int) $bfl_l : (string) $bfl_l;
                  $max_sel = ($request_length_max !== '' && is_numeric($request_length_max) && (float) $request_length_max === $bfl_l);
                  echo '<option value="' . esc_attr($opt) . '"' . ($max_sel ? ' selected="selected"' : '') . '>' . esc_html($opt) . '′</option>';
                }
                ?>
              </select>
            </div>
          </div>
        </div>

        <!-- Weight -->
        <div>
          <label class="<?php echo $bfl_lbl; ?>">Weight</label>
          <select name="weight" onchange="var f=this.closest('form');if(f)f.submit();" class="<?php echo $bfl_sel; ?>">
            <option value="">Any Weight</option>
            <?php
            foreach (['0,301'=>'Up to 300 lbs','299,501'=>'300–500 lbs','499,801'=>'500–800 lbs','799,1201'=>'800–1200 lbs','1199,2001'=>'1200–2000 lbs','1999,9999'=>'2000+ lbs'] as $bv => $bl)
              echo '<option value="'.$bv.'"'.($request_weight == $bv ? ' selected' : '').'>'.$bl.'</option>';
            ?>
          </select>
        </div>

        <!-- Passengers -->
        <div>
          <label class="<?php echo $bfl_lbl; ?>">Passengers</label>
          <select name="passengers" onchange="var f=this.closest('form');if(f)f.submit();" class="<?php echo $bfl_sel; ?>">
            <option value="">Any</option>
            <option value="0,8"  <?php echo $request_passengers == "0,8"  ? 'selected' : ''; ?>>Up to 7</option>
            <option value="7,99" <?php echo $request_passengers == "7,99" ? 'selected' : ''; ?>>8 or More</option>
          </select>
        </div>

        <!-- HP -->
        <div>
          <label class="<?php echo $bfl_lbl; ?>">Max Power</label>
          <select name="hp" onchange="var f=this.closest('form');if(f)f.submit();" class="<?php echo $bfl_sel; ?>">
            <option value="">Any HP</option>
            <option value="0,101"   <?php echo $request_hp == "0,101"   ? 'selected' : ''; ?>>Up to 100 HP</option>
            <option value="99,201"  <?php echo $request_hp == "99,201"  ? 'selected' : ''; ?>>100–200 HP</option>
            <option value="199,999" <?php echo $request_hp == "199,999" ? 'selected' : ''; ?>>200+ HP</option>
          </select>
        </div>

        <!-- Show Sold toggle -->
        <?php
        $show_sold = isset($_GET['show_sold']) && $_GET['show_sold'];
        $toggle_url = $show_sold ? remove_query_arg('show_sold') : add_query_arg('show_sold', '1');
        ?>
        <div>
          <label class="<?php echo $bfl_lbl; ?> opacity-0 select-none">Sold</label>
          <a href="<?php echo esc_url($toggle_url); ?>"
            class="w-full flex items-center justify-center gap-2 border-2 <?php echo $show_sold ? 'border-[#ff9101] bg-[#ff9101]/5' : 'border-gray-200 hover:border-[#ff9101]'; ?> text-gray-400 hover:text-[#ff9101] font-bold text-[11px] uppercase tracking-widest py-[7px] px-3 transition-all duration-150">
            <div class="relative flex-shrink-0 w-4 h-3">
              <div class="w-4 h-3 <?php echo $show_sold ? 'bg-[#ff9101]' : 'bg-gray-200'; ?> transition-colors duration-200"></div>
              <div class="absolute top-0.5 left-0.5 w-1 h-1 bg-white shadow-sm transition-transform duration-200 <?php echo $show_sold ? 'translate-x-1.5' : ''; ?>"></div>
            </div>
            <span class="transition-colors duration-150 <?php echo $show_sold ? 'text-[#ff9101]' : 'text-gray-400'; ?>">
              <?php echo $show_sold ? 'Showing Sold' : 'Show Sold'; ?>
            </span>
          </a>
        </div>

        <!-- Clear filters -->
        <div>
          <label class="<?php echo $bfl_lbl; ?> opacity-0 select-none">Clear</label>
          <a href="<?php echo home_url('/boats/'); ?>"
            class="w-full flex items-center justify-center gap-1.5 border-2 border-gray-200 hover:border-[#ff9101] text-gray-400 hover:text-[#ff9101] font-bold text-[11px] uppercase tracking-widest py-[7px] px-3 transition-all duration-150">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
            </svg>
            Clear
          </a>
        </div>

      </div>
    </div>

    <!-- Orange accent line -->
    <div class="h-[3px] bg-[#ff9101]"></div>

  </div>
  <?php endif; ?>
  <!-- ===== END FILTER BAR ===== -->


  <!-- ===== RESULTS AREA ===== -->
  <div class="bg-[#f7f7f7] min-h-screen pb-[200px] mb-[-200px]">
    <div class="max-w-screen-2xl mx-auto px-6 md:px-14 py-12">

      <?php if ($boats_view !== 'makes') : ?>


        <?php if ($boats->have_posts()) : ?>

          <!-- Result count bar -->
          <div class="flex items-center gap-4 mb-8">
            <p class="text-gray-500 text-lg font-medium flex-shrink-0">
              <span class="text-gray-900 font-black text-lg"><?php echo $boats->found_posts; ?></span>
              <?php echo $boats->found_posts === 1 ? 'boat' : 'boats'; ?> found
            </p>
            <div class="h-px flex-1 bg-gray-200"></div>
            <span class="flex-shrink-0 text-[#ff9101] text-lg font-bold uppercase tracking-widest">
              <?php
              if (!empty($url_type)) {
                echo esc_html(implode(' & ', array_map('ucfirst', $url_type)));
              } else {
                echo 'All types';
              }
              ?>
            </span>
          </div>

          <!-- Boats grid -->
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" id="bfl-boats-grid">
            <?php while ($boats->have_posts()) : $boats->the_post(); ?>

              <?php
              $bfl_make_terms = has_term('', 'make') ? get_the_terms($post->ID, 'make') : array();
              $bfl_make_name  = (!empty($bfl_make_terms) && !is_wp_error($bfl_make_terms)) ? $bfl_make_terms[0]->name : '';
              $bfl_type_terms = get_the_terms($post->ID, 'type');
              $bfl_type_name  = (!empty($bfl_type_terms) && !is_wp_error($bfl_type_terms)) ? $bfl_type_terms[0]->name : '';
              $bfl_img        = (!empty($post->boat_images['image'][0])) ? $post->boat_images['image'][0] : '';
              ?>

              <article class="bfl-boat group bg-white rounded-md overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col">

                <!-- Image -->
                <a href="<?php the_permalink(); ?>"
                  class="block relative overflow-hidden bg-gray-100 flex-shrink-0"
                  style="padding-top: 62%;">
                  <?php if ($bfl_img) : ?>
                    <img src="<?php echo esc_url($bfl_img); ?>"
                      alt="<?php the_title_attribute(); ?>"
                      class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 lazy">
                  <?php else : ?>
                    <div class="absolute inset-0 flex items-center justify-center bg-gray-50">
                      <svg class="w-14 h-14 text-gray-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                          d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                      </svg>
                    </div>
                  <?php endif; ?>

              <!-- Type badge -->
              <?php if ($bfl_type_name) : ?>
                <span class="absolute top-3 left-3 bg-[#ff9101] text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">
                  <?php echo esc_html($bfl_type_name); ?>
                </span>
              <?php endif; ?>

              <!-- Sold badge -->
              <?php if ($post->boat_sold) : ?>
                <span class="absolute top-3 right-3 bg-red-600 text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">
                  SOLD
                </span>
              <?php endif; ?>
                </a>

                <!-- Card body -->
                <div class="flex flex-col flex-1 p-6">

                  <?php if ($bfl_make_name) : ?>
                    <p class="text-[#ff9101] text-md font-bold uppercase tracking-widest mb-1">
                      <?php echo esc_html($bfl_make_name); ?>
                    </p>
                  <?php endif; ?>

                  <h2 class="text-gray-900 font-black text-2xl leading-tight mb-4">
                    <a href="<?php the_permalink(); ?>" class="hover:text-[#ff9101] transition-colors duration-150">
                      <?php the_title(); ?>
                    </a>
                  </h2>

                  <!-- Specs -->
                  <?php if ($post->boat_length || $post->boat_weight || $post->boat_passengers || $post->boat_hp) : ?>
                  <div class="grid grid-cols-2 gap-2 mb-5 pb-5 border-b border-gray-100">
                    <?php if ($post->boat_length) : ?>
                    <div class="flex flex-col">
                      <span class="text-[12px] font-bold uppercase tracking-widest text-gray-400">Length</span>
                      <span class="text-gray-900 font-black text-md"><?php echo esc_html($post->boat_length); ?>'</span>
                    </div>
                    <?php endif; ?>
                    <?php if ($post->boat_weight) : ?>
                    <div class="flex flex-col">
                      <span class="text-[12px] font-bold uppercase tracking-widest text-gray-400">Weight</span>
                      <span class="text-gray-900 font-black text-md"><?php echo esc_html($post->boat_weight); ?> lbs</span>
                    </div>
                    <?php endif; ?>
                    <?php if ($post->boat_passengers) : ?>
                    <div class="flex flex-col">
                      <span class="text-[12px] font-bold uppercase tracking-widest text-gray-400">Max Capacity</span>
                      <span class="text-gray-900 font-black text-md"><?php echo esc_html($post->boat_passengers); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($post->boat_hp) : ?>
                    <div class="flex flex-col">
                      <span class="text-[12px] font-bold uppercase tracking-widest text-gray-400">Max HP</span>
                      <span class="text-gray-900 font-black text-md"><?php echo esc_html($post->boat_hp); ?></span>
                    </div>
                    <?php endif; ?>
                  </div>
                  <?php endif; ?>

                  <!-- Actions -->
<div class="mt-auto flex flex-col sm:flex-row gap-2 sm:gap-3">
  <a href="<?php echo home_url(); ?>/my-boat-quotes/"
    data-postid="<?php the_id(); ?>"
    class="mbq-link w-full text-center bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-4 py-3 text-xs uppercase tracking-widest transition-all duration-150">
    Request Quote
  </a>
  <a href="<?php the_permalink(); ?>"
    class="w-full text-center bg-gray-900 hover:bg-[#ff9101] text-white font-bold px-4 py-3 text-xs uppercase tracking-widest transition-all duration-200">
    View Details
  </a>
</div>

                </div>
              </article>

            <?php endwhile; ?>
          </div>

          <!-- Pagination -->
          <div class="flex justify-center mt-12">
            <?php
            $pagination_args = array(
              'total' => $boats->max_num_pages,
              'current' => max(1, $paged),
              'prev_text' => '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg> Previous',
              'next_text' => 'Next <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>',
              'base' => home_url('/boats/') . '%_%',
              'format' => 'page/%#%'
            );

            // Adjust base URL for make pages
            if ($boats_make) {
              $pagination_args['base'] = home_url('/boats/make/' . $boats_make . '/') . '%_%';
            }

            echo paginate_links($pagination_args);
            ?>
          </div>

          <!-- Load More -->
          <!-- <div class="flex justify-center mt-12" id="bfl-load-more-wrap"> -->
<!--             <button id="bfl-load-more"
              class="inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-black px-10 py-4 text-sm uppercase tracking-[0.2em] transition-all duration-200">
              Load More
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
              </svg>
            </button> -->
          <!-- </div> -->

        <?php else : ?>

          <!-- No results -->
          <div class="flex flex-col items-center justify-center py-24 text-center">
            <svg class="w-16 h-16 text-gray-200 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <h3 class="text-gray-900 font-black text-2xl mb-3">No Boats Found</h3>
            <p class="text-gray-400 text-lg mb-8 max-w-sm">No boats match your current filters. Try adjusting your search.</p>
            <a href="<?php echo home_url('/boats/'); ?>"
              class="inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold px-7 py-3.5 text-md uppercase tracking-[0.2em] transition-all duration-200">
              Clear Filters
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </a>
          </div>

        <?php endif; ?>

      <?php elseif ($boats_view === 'makes') : ?>

        <!-- ===== MAKES INDEX ===== -->
        <div class="text-center mb-12">
          <h2 class="text-gray-900 font-black text-3xl md:text-4xl mb-4">
            Choose Your Brand
          </h2>
          <p class="text-gray-600 text-lg max-w-2xl mx-auto">
            Browse our collection of premium inflatable boat brands. Each manufacturer offers unique features and quality craftsmanship.
          </p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <?php
          foreach ($makes as $make) {
            $br_args = array('post_type' => 'boats', 'tax_query' => array('relation' => 'AND',
              array('taxonomy' => 'make', 'field' => 'slug', 'terms' => $make->slug),
              array('taxonomy' => 'type', 'field' => 'slug', 'terms' => 'new')
            ));
            $brands = new WP_Query($br_args);
            if ($brands->found_posts > 0) :
              $make_image = get_term_meta($make->term_id, 'tax_image', true);
              $make_logo  = get_term_meta($make->term_id, 'tax_logo',  true);
          ?>

            <a href="<?php echo home_url('/boats/make/' . $make->slug . '/'); ?>"
              class="group block bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-200 hover:border-[#ff9101]">

              <!-- Brand image/logo area -->
              <div class="aspect-square bg-gray-50 flex items-center justify-center p-8 relative overflow-hidden">
                <?php if ($make_logo) : ?>
                  <img src="<?php echo esc_url($make_logo); ?>"
                    alt="<?php echo esc_attr($make->name); ?>"
                    class="max-w-full max-h-full w-auto h-auto object-contain transition-transform duration-300 group-hover:scale-105">
                <?php elseif ($make_image) : ?>
                  <div class="absolute inset-0 bg-cover bg-center"
                    style="background-image: url(<?php echo esc_url($make_image); ?>);"></div>
                  <div class="absolute inset-0 bg-black/10 group-hover:bg-black/20 transition-colors duration-300"></div>
                <?php else : ?>
                  <div class="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                        d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                    </svg>
                  </div>
                <?php endif; ?>

                <!-- Subtle hover indicator -->
                <div class="absolute inset-0 bg-[#ff9101]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              <!-- Brand name -->
              <div class="p-6 text-center bg-white">
                <h3 class="text-gray-900 font-bold text-lg mb-2 group-hover:text-[#ff9101] transition-colors duration-200">
                  <?php echo esc_html($make->name); ?>
                </h3>
                <p class="text-gray-500 text-sm">
                  <?php echo $brands->found_posts; ?> <?php echo $brands->found_posts === 1 ? 'boat' : 'boats'; ?> available
                </p>

                <!-- View boats link -->
                <div class="mt-4 inline-flex items-center gap-2 text-[#ff9101] font-semibold text-sm group-hover:text-[#e07f00] transition-colors duration-200">
                  View Collection
                  <svg class="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                  </svg>
                </div>
              </div>

            </a>

          <?php
            endif;
            wp_reset_postdata();
          }
          ?>
        </div>

      <?php endif; ?>

    </div>
  </div>

<?php if ($boats_view !== 'makes') : ?>
</form>
<?php endif; ?>

<?php wp_reset_postdata(); ?>

<script>
// (function() {
//   const boats   = document.querySelectorAll('.bfl-boat');
//   const loadBtn = document.getElementById('bfl-load-more');
//   const wrap    = document.getElementById('bfl-load-more-wrap');
//   const perPage = 10;

//   if (!boats.length) return;

//   // Hide all beyond first page
//   boats.forEach((el, i) => {
//     if (i >= perPage) el.style.display = 'none';
//   });

//   // Hide button if not needed
//   if (boats.length <= perPage) wrap.style.display = 'none';

//   loadBtn && loadBtn.addEventListener('click', function () {
//     const hidden = [...document.querySelectorAll('.bfl-boat[style*="display: none"]')];
//     hidden.slice(0, perPage).forEach(el => el.style.display = '');
//     if (document.querySelectorAll('.bfl-boat[style*="display: none"]').length === 0) {
//       wrap.style.display = 'none';
//     }
//   });
// })();
</script>
