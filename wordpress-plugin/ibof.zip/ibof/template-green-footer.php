<?php
/**
 * Template Name: Green Footer
 */
get_header();

while (have_posts()) : the_post();
  echo '<div id="page-header"';
  if (has_post_thumbnail()) echo '  style="background-image: url('.get_the_post_thumbnail_url().');"';
  echo ">\n";
    the_title('<h1>', '</h1>');
  echo "</div> <!-- /#page-header -->\n";


  echo '<div class="page-content">'."\n";
    the_content();
  echo "</div> <!-- /.page-content -->\n";
endwhile;

if ($post->green_footer_text) {
  echo '<div class="waves boats-contact">'."\n";
    echo '<div class="site-width">'."\n";
      echo $post->green_footer_text;
      echo '<a href="'.home_url().'/contact/">Contact Us</a>'."\n";
    echo "</div> <!-- /.site-width -->\n";
  echo "</div> <!-- /.boats-contact -->\n";
}

get_footer();
?>
