<?php
/**
 * Template Name: About Us
 */
get_header();
while (have_posts()) : the_post();
?>

<!-- ===== PAGE HERO ===== -->
<div class="about-hero relative overflow-hidden bg-white">

  <!-- Top orange line -->
  <div class="absolute top-0 left-0 right-0 h-[4px] bg-[#ff9101] z-10"></div>

  <!-- Dot grid — left side only -->
<!--   <div class="absolute inset-0 opacity-[0.035]"
    style="background-image: radial-gradient(circle, #4f7cb1 1px, transparent 1px); background-size: 28px 28px;"></div> -->

  <div class="relative z-10 max-w-screen-2xl mx-auto px-6 md:px-14 py-24 md:py-32">
    <div class="xl:grid xl:grid-cols-12 gap-12 items-center">

      <!-- Content: 7 cols -->
      <div class="xl:col-span-7">

        <!-- Eyebrow -->
        <div class="flex items-center gap-3 mb-7">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">Who We Are</span>
        </div>

        <!-- Headline -->
        <h1 class="font-black leading-[1.05] text-gray-900 mb-6"
          style="font-size: clamp(2.75rem, 6vw, 5.5rem);">
          About Inflatable<br>
          <span class="text-[#4f7cb1]">Boats of Florida</span>
        </h1>

        <p class="text-gray-500 text-xl md:text-2xl leading-relaxed max-w-2xl mb-12">
          Florida's trusted inflatable boat dealer — specializing in RIBs, yacht tenders, and outboard repower solutions for Southwest Florida and beyond.
        </p>

        <!-- Two feature columns — like the Flowbite reference -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-10 sm:gap-16">

          <div class="text-gray-500">
            <svg class="mb-4 w-8 h-8 text-[#4f7cb1]" fill="none" stroke="currentColor" stroke-width="1.75" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            <h2 class="mb-3 text-xl font-black text-gray-900">Southwest Florida</h2>
            <p class="text-lg leading-relaxed mb-5">
              Serving boaters across Naples, Fort Myers, Cape Coral, and throughout Florida's Gulf Coast with expert guidance and top-brand inventory.
            </p>
            <a href="<?php echo home_url('/locations/'); ?>"
              class="inline-flex items-center gap-2 bg-[#4f7cb1] hover:bg-[#3d6a9e] text-white font-black text-sm uppercase tracking-[0.2em] px-6 py-3 transition-all duration-200">
              Our Locations
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
              </svg>
            </a>
          </div>

          <div class="text-gray-500">
            <svg class="mb-4 w-8 h-8 text-[#ff9101]" fill="none" stroke="currentColor" stroke-width="1.75" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/>
            </svg>
            <h2 class="mb-3 text-xl font-black text-gray-900">RIBs & Outboards</h2>
            <p class="text-lg leading-relaxed mb-5">
              From inflatable tenders to rigid inflatable boats and modern outboard repower solutions — we match every boater to the right vessel and engine.
            </p>
            <a href="<?php echo home_url('/boats/'); ?>"
              class="inline-flex items-center gap-2 border-2 border-gray-200 hover:border-[#ff9101] hover:text-[#ff9101] text-gray-600 font-black text-sm uppercase tracking-[0.2em] px-6 py-3 transition-all duration-200">
              Browse Inventory
              <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
              </svg>
            </a>
          </div>

        </div>

      </div>

    </div>
  </div>

  <!-- Right image — pinned to edge, bleeds off screen, xl only -->
  <?php if (has_post_thumbnail()) : ?>
  <div class="hidden xl:block absolute top-0 right-0 w-5/12 h-full">
    <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>"
      alt="<?php the_title_attribute(); ?>"
      class="w-full h-full object-cover object-center">
    <!-- Fade into white on the left edge -->
    <div class="absolute inset-y-0 left-0 w-12"
      style="background: linear-gradient(to right, #ffffff, transparent);"></div>
  </div>
  <?php endif; ?>

</div>
<div class="h-[3px] bg-[#ff9101]"></div>

<!-- ===== INTRO STRIP ===== -->
<div class="bg-white py-12 border-b border-gray-100">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <p class="text-gray-600 text-xl md:text-2xl leading-relaxed max-w-5xl">
      From coastal cruising to shallow water access and sandbar weekends, we help customers choose the right inflatable boat and outboard configuration for long-term reliability and performance.
    </p>
  </div>
</div>


<!-- ===== FLORIDA RIB SPECIALISTS ===== -->
<div class="bg-[#f7f7f7] py-24">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

      <div>
        <div class="flex items-center gap-3 mb-5">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">Our Specialty</span>
        </div>
        <h2 class="text-gray-900 font-black leading-tight mb-6" style="font-size: clamp(2rem, 4vw, 3rem);">
          Florida's Inflatable Boat and RIB Specialists
        </h2>
        <p class="text-gray-500 text-xl leading-relaxed mb-5">
          We focus exclusively on inflatable boats and rigid inflatable boats because they offer unmatched versatility in Florida's unique marine environment.
        </p>
        <p class="text-gray-500 text-xl leading-relaxed mb-8">
          Whether you are buying your first inflatable boat or upgrading to a larger RIB, we provide guidance based on real world Florida boating conditions.
        </p>
        <a href="<?php echo home_url('/boats/'); ?>"
          class="inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold text-sm uppercase tracking-[0.2em] px-8 py-4 transition-all duration-200">
          Browse Our Inventory
          <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
          </svg>
        </a>
      </div>

      <div class="grid grid-cols-2 gap-4">
        <?php
        $about_rib_reasons = array(
          array('icon' => 'M5 3l14 9-14 9V3z',                                                                                                                                                                                                          'label' => 'Shallow Draft Performance'),
          array('icon' => 'M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z',                                                                                                                                   'label' => 'Coastal Water Stability'),
          array('icon' => 'M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4',                                                                                                                                        'label' => 'Lightweight Storage'),
          array('icon' => 'M13 10V3L4 14h7v7l9-11h-7z',                                                                                                                                                                                                'label' => 'Fuel Efficiency'),
          array('icon' => 'M12 19l9 2-9-18-9 18 9-2zm0 0v-8',                                                                                                                                                                                          'label' => 'Yacht Tender Use'),
          array('icon' => 'M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064', 'label' => 'Island & Sandbar Access'),
        );
        foreach ($about_rib_reasons as $about_r) :
        ?>
        <div class="group bg-white rounded-md p-6 border border-gray-100 hover:border-[#ff9101] hover:shadow-md transition-all duration-200">
          <span class="flex w-11 h-11 bg-[#ff9101]/10 group-hover:bg-[#ff9101] rounded-sm items-center justify-center mb-4 transition-colors duration-200">
            <svg class="w-5 h-5 text-[#ff9101] group-hover:text-white transition-colors duration-200" fill="none" stroke="currentColor" stroke-width="1.75" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="<?php echo $about_r['icon']; ?>"/>
            </svg>
          </span>
          <p class="text-gray-900 font-black text-base leading-tight"><?php echo $about_r['label']; ?></p>
        </div>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</div>


<!-- ===== OUTBOARD REPOWER ===== -->
<div class="bg-[#0d0d0d] py-24 relative overflow-hidden">
  <div class="absolute inset-0 opacity-[0.03]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>

  <div class="relative z-10 max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

      <div class="order-2 lg:order-1">
        <div class="grid grid-cols-1 gap-4">
          <?php
          $about_repower = array(
            array('label' => 'Improved Fuel Efficiency',        'desc' => 'Modern outboards deliver significantly better fuel economy than older motors.'),
            array('label' => 'Quieter Operation',               'desc' => 'Advanced engine technology reduces noise and vibration on the water.'),
            array('label' => 'Advanced Corrosion Protection',   'desc' => 'Built specifically for Florida saltwater environments.'),
            array('label' => 'Better Throttle Response',        'desc' => 'Precise power delivery for coastal and inshore conditions.'),
            array('label' => 'Increased Saltwater Reliability', 'desc' => 'Purpose-built components for demanding Florida marine use.'),
          );
          foreach ($about_repower as $about_ri => $about_rv) :
          ?>
          <div class="flex items-start gap-5 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#ff9101]/40 rounded-sm px-6 py-5 transition-all duration-200">
            <span class="flex-shrink-0 text-[#ff9101] font-black text-base mt-0.5">
              <?php echo str_pad($about_ri + 1, 2, '0', STR_PAD_LEFT); ?>
            </span>
            <div>
              <p class="text-white font-black text-2xl mb-1"><?php echo $about_rv['label']; ?></p>
              <p class="text-white/80 text-xl leading-relaxed"><?php echo $about_rv['desc']; ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="order-1 lg:order-2">
        <div class="flex items-center gap-3 mb-5">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">Outboard Experts</span>
        </div>
        <h2 class="text-white font-black leading-tight mb-6" style="font-size: clamp(2rem, 4vw, 3rem);">
          Outboard Motor Sales and Repower Experts
        </h2>
        <p class="text-white/80 text-xl leading-relaxed mb-5">
          In addition to new and pre-owned inflatable boats, we specialize in outboard motor sales and repower services.
        </p>
        <p class="text-white/80 text-xl leading-relaxed mb-8">
          Repowering an existing boat is often the most cost-effective way to improve performance, reliability, and fuel economy. If your current motor is aging or unreliable, we help you select the correct horsepower and engine configuration for your hull and usage.
        </p>
        <a href="<?php echo home_url('/contact/'); ?>"
          class="inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold text-sm uppercase tracking-[0.2em] px-8 py-4 transition-all duration-200">
          Ask About Repower
          <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
          </svg>
        </a>
      </div>

    </div>
  </div>
</div>


<!-- ===== SERVICE AREA + WHY INFLATABLE ===== -->
<div class="bg-white py-24">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">

      <div>
        <div class="flex items-center gap-3 mb-5">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">Where We Serve</span>
        </div>
        <h2 class="text-gray-900 font-black leading-tight mb-6" style="font-size: clamp(2rem, 4vw, 3rem);">
          Serving Southwest Florida and Beyond
        </h2>
        <p class="text-gray-500 text-xl leading-relaxed mb-8">
          Florida waters demand boats and engines that can handle heat, salt exposure, shallow flats, and changing weather patterns. Our experience in the Florida marine market allows us to recommend equipment that performs reliably in these conditions.
        </p>
        <div class="grid grid-cols-2 gap-3">
          <?php
          $about_areas = array(
            'Southwest Florida', 'The Gulf Coast',
            'Coastal Florida Communities', 'Inland Florida Boaters',
            'Naples & Marco Island', 'Fort Myers & Cape Coral',
            'Sarasota & Charlotte County', 'Florida Keys & Beyond',
          );
          foreach ($about_areas as $about_area) :
          ?>
          <div class="flex items-center gap-3 bg-[#f7f7f7] rounded-sm px-4 py-3">
            <span class="w-2 h-2 bg-[#ff9101] rounded-full flex-shrink-0"></span>
            <span class="text-gray-700 font-semibold text-base"><?php echo $about_area; ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div>
        <div class="flex items-center gap-3 mb-5">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">Why Inflatable</span>
        </div>
        <h2 class="text-gray-900 font-black leading-tight mb-6" style="font-size: clamp(2rem, 4vw, 3rem);">
          Why Choose Inflatable Boats in Florida
        </h2>
        <p class="text-gray-500 text-xl leading-relaxed mb-8">
          Rigid inflatable boats and inflatable tenders are increasingly popular across Florida due to their versatility and ease of use. They offer a practical solution for Florida boaters who want performance without the weight and fuel costs of larger fiberglass vessels.
        </p>
        <div class="flex flex-col gap-4">
          <?php
          $about_ideal = array(
            'Coastal Cruising',
            'Fishing in Shallow Water',
            'Yacht Tender Transport',
            'Waterfront Property Access',
            'Sandbar and Island Hopping',
          );
          foreach ($about_ideal as $about_use) :
          ?>
          <div class="flex items-center gap-4 border-b border-gray-100 pb-4 last:border-0 last:pb-0">
            <svg class="w-5 h-5 text-[#ff9101] flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
            </svg>
            <span class="text-gray-700 font-semibold text-lg"><?php echo $about_use; ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

    </div>
  </div>
</div>


<!-- ===== COMMITMENT ===== -->
<div class="bg-[#f7f7f7] py-24">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <div class="text-center mb-16">
      <div class="flex items-center justify-center gap-3 mb-5">
        <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
        <span class="text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">Our Promise</span>
        <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      </div>
      <h2 class="text-gray-900 font-black leading-tight mb-5" style="font-size: clamp(2rem, 4vw, 3rem);">
        Our Commitment to Florida Boaters
      </h2>
      <p class="text-gray-500 text-xl leading-relaxed max-w-3xl mx-auto">
        We believe buying or repowering a boat should be straightforward and informed. Our goal is to build long-term relationships with Florida boaters by delivering equipment that performs reliably season after season.
      </p>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      <?php
      $about_commitments = array(
        array(
          'icon'  => 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z',
          'label' => 'Understanding Your Needs',
          'desc'  => 'We start by understanding how you use your boat before making any recommendation.',
        ),
        array(
          'icon'  => 'M13 10V3L4 14h7v7l9-11h-7z',
          'label' => 'Engine-to-Hull Matching',
          'desc'  => 'We match the correct engine configuration and horsepower to your specific hull.',
        ),
        array(
          'icon'  => 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
          'label' => 'Transparent Recommendations',
          'desc'  => 'No upsells. We recommend what works best for your usage and budget.',
        ),
        array(
          'icon'  => 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z',
          'label' => 'After-Sale Support',
          'desc'  => 'Our relationship with you does not end at the sale.',
        ),
      );
      foreach ($about_commitments as $about_c) :
      ?>
      <div class="group bg-white rounded-md shadow-sm hover:shadow-lg border border-gray-100 hover:border-[#ff9101] transition-all duration-300 overflow-hidden">
        <div class="h-1 bg-gray-100 group-hover:bg-[#ff9101] transition-colors duration-300"></div>
        <div class="p-8">
          <span class="flex w-12 h-12 bg-[#ff9101]/10 group-hover:bg-[#ff9101] rounded-sm items-center justify-center mb-6 transition-colors duration-300">
            <svg class="w-6 h-6 text-[#ff9101] group-hover:text-white transition-colors duration-300" fill="none" stroke="currentColor" stroke-width="1.75" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="<?php echo $about_c['icon']; ?>"/>
            </svg>
          </span>
          <h3 class="text-gray-900 font-black text-xl leading-tight mb-3"><?php echo $about_c['label']; ?></h3>
          <p class="text-gray-500 text-lg leading-relaxed"><?php echo $about_c['desc']; ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

  </div>
</div>


<!-- ===== LOCAL SEO SECTION ===== -->
<div class="bg-white py-24 border-t border-gray-100">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

      <div>
        <div class="flex items-center gap-3 mb-5">
          <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
          <span class="text-[#ff9101] text-base font-bold uppercase tracking-[0.3em]">Find Us</span>
        </div>
        <h2 class="text-gray-900 font-black leading-tight mb-6" style="font-size: clamp(2rem, 4vw, 3rem);">
          Inflatable Boat Dealer in Southwest Florida
        </h2>
        <p class="text-gray-500 text-xl leading-relaxed mb-5">
          If you are searching for <strong class="text-gray-700">inflatable boats for sale in Southwest Florida</strong>, <strong class="text-gray-700">rigid inflatable boats near me</strong>, or <strong class="text-gray-700">outboard motor repower services in Florida</strong>, Inflatable Boats of Florida is ready to help.
        </p>
        <p class="text-gray-500 text-xl leading-relaxed mb-8">
          We work with boaters who want dependable marine equipment built for Florida's coastal and inland waterways.
        </p>
        <div class="flex flex-col sm:flex-row gap-4">
          <a href="<?php echo home_url('/boats/'); ?>"
            class="flex-1 text-center inline-flex items-center justify-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-bold text-sm uppercase tracking-[0.2em] px-8 py-4 transition-all duration-200">
            View Inventory
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
            </svg>
          </a>
          <a href="<?php echo home_url('/contact/'); ?>"
            class="flex-1 text-center inline-flex items-center justify-center gap-2 border-2 border-gray-200 hover:border-[#ff9101] text-gray-600 hover:text-[#ff9101] font-bold text-sm uppercase tracking-[0.2em] px-8 py-4 transition-all duration-200">
            Contact Us
          </a>
        </div>
      </div>

      <div class="bg-[#f7f7f7] rounded-md p-10">
        <p class="text-gray-400 text-xs font-bold uppercase tracking-[0.3em] mb-6">We Specialize In</p>
        <div class="flex flex-wrap gap-3">
          <?php
          $about_keywords = array(
            'Inflatable Boats Florida',
            'Rigid Inflatable Boats Florida',
            'RIB Boats Florida',
            'Inflatable Boat Dealer Florida',
            'Outboard Motor Sales Florida',
            'Boat Repower Florida',
            'Southwest Florida Boating',
            'Yacht Tender Florida',
            'Shallow Draft Boats Florida',
            'Naples Boat Dealer',
            'Fort Myers Marine',
            'Cape Coral Boats',
          );
          foreach ($about_keywords as $about_kw) :
          ?>
          <span class="bg-white border border-gray-200 text-gray-600 text-sm font-semibold px-4 py-2 rounded-sm">
            <?php echo $about_kw; ?>
          </span>
          <?php endforeach; ?>
        </div>
      </div>

    </div>
  </div>
</div>


<!-- ===== CTA BAND ===== -->
<section class="py-20 bg-[#4f7cb1] relative overflow-hidden">
  <div class="absolute inset-0 opacity-[0.08]"
    style="background-image: repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%); background-size: 14px 14px;"></div>
  <div class="relative z-10 max-w-screen-2xl mx-auto px-6 md:px-14 flex flex-col lg:flex-row items-center justify-between gap-8">
    <div>
      <h2 class="text-white font-black leading-tight mb-3" style="font-size: clamp(1.8rem, 3.5vw, 2.75rem);">
        Ready to Find Your Perfect<br>Inflatable Boat?
      </h2>
      <p class="text-white/80 text-xl">Our experts are standing by to help you get on the water.</p>
    </div>
    <div class="flex flex-wrap gap-4 flex-shrink-0">
      <a href="<?php echo home_url('/boats/'); ?>"
        class="inline-flex items-center gap-2 bg-[#ff9101] hover:bg-[#e07f00] text-white font-black px-8 py-4 text-sm uppercase tracking-[0.2em] transition-all duration-200">
        Browse Inventory
        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
        </svg>
      </a>
      <a href="<?php echo home_url('/contact/'); ?>"
        class="inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-[#4f7cb1] font-black px-8 py-4 text-sm uppercase tracking-[0.2em] transition-all duration-200">
        Contact Us
        <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
        </svg>
      </a>
    </div>
  </div>
</section>

<?php
endwhile;
get_footer();
?>
