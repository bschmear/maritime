<?php
/**
 * Template Name: Services
 */
get_header();
while (have_posts()) : the_post();
?>

<!-- ===== PAGE HERO ===== -->
<div class="svc-hero relative min-h-[420px] flex items-end bg-cover bg-center overflow-hidden"
  <?php if (has_post_thumbnail()) echo 'style="background-image: url('.get_the_post_thumbnail_url().');"'; ?>>

  <!-- Gradient overlay -->
  <div class="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-[#0d0d0d]/60 to-black/20"></div>

  <!-- Top orange bar -->
  <div class="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#ff9101] to-transparent"></div>

  <div class="relative z-10 w-full max-w-screen-2xl mx-auto px-6 md:px-14 pb-14">
    <div class="flex items-center gap-3 mb-4">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <span class="text-[#ff9101] text-sm font-bold uppercase tracking-[0.3em]">What We Offer</span>
    </div>
    <?php the_title('<h1 class="text-white font-black leading-tight" style="font-size: clamp(2.5rem, 6vw, 4.5rem);">', '</h1>'); ?>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== SERVICES CONTENT ===== -->
<div class="bg-[#f7f7f7] py-20">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">
    <?php if (have_rows('services')) : ?>

      <!-- Optional intro -->
      <?php $svc_intro = get_field('intro'); if ($svc_intro) : ?>
        <p class="text-gray-500 text-xl md:text-2xl lg:text-3xl leading-relaxed max-w-5xl mb-16">
          <?php echo esc_html($svc_intro); ?>
        </p>
      <?php endif; ?>

      <!-- Services grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <?php
        $svc_index = 0;
        while (have_rows('services')) : the_row();
          $svc_item  = get_sub_field('service');
          if (!$svc_item) continue;
          $svc_label = $svc_item['label'];
          $svc_body  = $svc_item['body'];
          $svc_index++;
        ?>

        <div class="svc-card group bg-white rounded-md shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col overflow-hidden">

          <!-- Orange top accent -->
          <div class="h-1 bg-gray-100 group-hover:bg-[#ff9101] transition-colors duration-300"></div>

          <div class="flex flex-col flex-1 p-6 md:p-8">

            <!-- Number + label -->
            <div class="flex items-start gap-4 mb-5">
              <span class="flex-shrink-0 w-9 h-9 md:w-10 md:h-10 rounded-sm bg-[#ff9101]/10 group-hover:bg-[#ff9101] flex items-center justify-center transition-colors duration-300">
                <span class="text-[#ff9101] group-hover:text-white font-black text-base md:text-lg transition-colors duration-300">
                  <?php echo str_pad($svc_index, 2, '0', STR_PAD_LEFT); ?>
                </span>
              </span>
              <h3 class="text-gray-900 font-black text-xl md:text-2xl lg:text-3xl leading-tight pt-1">
                <?php echo esc_html($svc_label); ?>
              </h3>
            </div>

            <!-- Divider -->
            <div class="h-px bg-gray-100 mb-5"></div>

            <!-- Body content -->
            <div class="svc-body text-gray-500 text-lg md:text-xl lg:text-2xl leading-relaxed flex-1">
              <?php echo wp_kses_post($svc_body); ?>
            </div>

          </div>
        </div>

        <?php endwhile; ?>
      </div>

    <?php endif; ?>
  </div>
</div>


<?php
endwhile;
get_footer();
?>
