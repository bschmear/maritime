<?php get_header(); ?>

<?php while (have_posts()) : the_post(); ?>

<?php
$bsp_make_terms = has_term('', 'make') ? get_the_terms($post->ID, 'make') : array();
$bsp_make_name  = (!empty($bsp_make_terms) && !is_wp_error($bsp_make_terms)) ? $bsp_make_terms[0]->name : '';
$bsp_type_terms = get_the_terms($post->ID, 'type');
$bsp_type_name  = (!empty($bsp_type_terms) && !is_wp_error($bsp_type_terms)) ? $bsp_type_terms[0]->name : '';

$bsp_tabs = array();
if ($post->boat_specifications) $bsp_tabs[] = array('id' => 'bsp-tab-specs',    'label' => 'Specifications',     'content' => $post->boat_specifications);
if ($post->boat_features)       $bsp_tabs[] = array('id' => 'bsp-tab-features', 'label' => 'Standard Features',  'content' => $post->boat_features);
if ($post->boat_accessories)    $bsp_tabs[] = array('id' => 'bsp-tab-access',   'label' => 'Accessories',        'content' => $post->boat_accessories);
?>

<!-- ===== HERO BAND ===== -->
<div class="bg-[#111111] border-b border-white/10">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14 py-4 flex flex-wrap items-center gap-2 text-sm font-bold uppercase tracking-widest">
    <a href="<?php echo home_url(); ?>" class="text-white/40 hover:text-[#ff9101] transition-colors">Home</a>
    <span class="text-white/20">/</span>
    <a href="<?php echo home_url(); ?>/boats/" class="text-white/40 hover:text-[#ff9101] transition-colors">Boats</a>
    <span class="text-white/20">/</span>
    <span class="text-[#ff9101]"><?php the_title(); ?></span>
  </div>
</div>
<div class="h-[3px] bg-[#ff9101]"></div>


<!-- ===== MAIN CONTENT ===== -->
<div class="bg-[#f7f7f7]">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14 py-12">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">

      <!-- LEFT: Image gallery -->
      <div class="bsp-gallery sticky top-[140px] relative">
          <!-- Load Flickity + GLightbox -->
          <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/inc/flickity.min.css" media="screen">
          <script src="<?php echo get_template_directory_uri(); ?>/inc/flickity.pkgd.min.js"></script>
          <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/inc/glightbox.min.css" media="screen">
          <script src="<?php echo get_template_directory_uri(); ?>/inc/glightbox.min.js"></script>

        <?php if ($post->boat_images) : ?>


          <!-- Main carousel -->
          <div class="bsp-carousel-main rounded-md overflow-hidden mb-3 relative">



            <?php foreach ($post->boat_images['image'] as $bsp_i => $bsp_img) : ?>
              <div class="bsp-slide" style="width:100%;">
                <a href="<?php echo esc_url($bsp_img); ?>" class="glightbox block w-full" style="padding-top:66%; position:relative; display:block;">
                  <img src="<?php echo esc_url($bsp_img); ?>"
                    alt="<?php the_title_attribute(); ?> - Image <?php echo $bsp_i + 1; ?>"
                    class="absolute inset-0 w-full h-full object-cover">
                </a>
              </div>
            <?php endforeach; ?>
          </div>

      <?php if (!empty($post->boat_video)) : ?>
      <button
      onclick="bspOpenVideo('<?php echo esc_js($post->boat_video); ?>')"
      class=" mt-4 mb-4 w-full text-center z-20 flex items-center justify-center gap-2 bg-black/70 hover:bg-[#ff9101] text-white text-xs font-bold uppercase tracking-widest px-4 py-2.5 rounded transition-all duration-200 backdrop-blur-sm">
      <svg class="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 24 24">
        <path d="M8 5v14l11-7z"/>
      </svg>
      Watch Video
    </button>
    <?php endif; ?>

  <!-- Thumbnail nav -->
  <div class="bsp-carousel-nav flex gap-2 flex-wrap mt-2">
    <?php foreach ($post->boat_images['image'] as $bsp_j => $bsp_nimg) : ?>
      <div id="bsp-link<?php echo $bsp_j; ?>"
        class="bsp-slide-link cursor-pointer overflow-hidden flex-shrink-0 rounded transition-all duration-150 <?php echo $bsp_j === 0 ? 'ring-2 ring-[#ff9101]' : 'ring-1 ring-gray-200 opacity-60 hover:opacity-100'; ?>"
        style="width:72px; height:54px; background-image:url(<?php echo esc_url($bsp_nimg); ?>); background-size:cover; background-position:center;">
      </div>
    <?php endforeach; ?>
  </div>



  <script>
  document.addEventListener('DOMContentLoaded', function () {
    var flkty = new Flickity('.bsp-carousel-main', {
      pageDots: false,
      prevNextButtons: false,
      draggable: true,
      wrapAround: true,
      imagesLoaded: true
    });

    // Thumbnail click
    var bspThumbs = Array.from(document.querySelectorAll('.bsp-slide-link'));
    document.querySelector('.bsp-carousel-nav').addEventListener('click', function (e) {
      var thumb = e.target.closest('.bsp-slide-link');
      if (!thumb) return;

      bspThumbs.forEach(function (t) {
        t.classList.remove('ring-2', 'ring-[#ff9101]');
        t.classList.add('ring-1', 'ring-gray-200', 'opacity-60');
      });
      thumb.classList.add('ring-2', 'ring-[#ff9101]');
      thumb.classList.remove('ring-1', 'ring-gray-200', 'opacity-60');

      flkty.select(bspThumbs.indexOf(thumb), false, true);
    });

    // Keep thumbnail in sync when swiping
    flkty.on('change', function (index) {
      bspThumbs.forEach(function (t) {
        t.classList.remove('ring-2', 'ring-[#ff9101]');
        t.classList.add('ring-1', 'ring-gray-200', 'opacity-60');
      });
      if (bspThumbs[index]) {
        bspThumbs[index].classList.add('ring-2', 'ring-[#ff9101]');
        bspThumbs[index].classList.remove('ring-1', 'ring-gray-200', 'opacity-60');
      }
    });

    // Init lightbox
    GLightbox({ selector: '.glightbox' });
  });
  </script>

<?php else : ?>
  <div class="rounded-md bg-gray-200 flex items-center justify-center" style="padding-top:66%; position:relative;">
    <div class="absolute inset-0 flex items-center justify-center">
      <svg class="w-16 h-16 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
          d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
      </svg>
    </div>

  </div>
<?php endif; ?>

      </div>
      <!-- END gallery -->


      <!-- RIGHT: Details -->
      <div class="flex flex-col gap-6">

        <!-- Make + Type -->
        <div class="flex flex-wrap items-center gap-3">
          <?php if ($bsp_make_name) : ?>
            <span class="text-[#ff9101] text-base font-black uppercase tracking-[0.25em]">
              <?php echo esc_html($bsp_make_name); ?>
            </span>
          <?php endif; ?>
          <?php if ($bsp_type_name) : ?>
            <span class="bg-[#ff9101] text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">
              <?php echo esc_html($bsp_type_name); ?>
            </span>
          <?php endif; ?>
          
        </div>

        <!-- Title -->
        <h1 class="text-gray-900 font-black leading-tight" style="font-size: clamp(1.8rem, 4vw, 2.75rem);">
          <?php the_title(); ?>
        </h1>

        <!-- Specs grid -->
        <?php if ($post->boat_length || $post->boat_weight || $post->boat_passengers || $post->boat_hp) : ?>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-px bg-gray-200 rounded-md overflow-hidden">
          <?php
          $bsp_specs = array(
            array('label' => 'Length',       'val' => $post->boat_length     ? $post->boat_length."'"       : null),
            array('label' => 'Weight',       'val' => $post->boat_weight     ? $post->boat_weight." lbs"    : null),
            array('label' => 'Max Capacity', 'val' => $post->boat_passengers ? $post->boat_passengers." pax": null),
            array('label' => 'Max HP',       'val' => $post->boat_hp         ? $post->boat_hp." HP"         : null),
          );
          foreach ($bsp_specs as $bsp_s) :
            if (!$bsp_s['val']) continue;
          ?>
          <div class="bg-white flex flex-col items-center justify-center py-5 px-3 text-center">
            <span class="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1"><?php echo $bsp_s['label']; ?></span>
            <span class="text-gray-900 font-black text-2xl"><?php echo esc_html($bsp_s['val']); ?></span>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Description -->
        <div class="prose prose-gray max-w-none text-gray-600 text-xl leading-relaxed">
          <?php the_content(); ?>
        </div>

        <!-- CTA -->
        <div class="flex flex-col sm:flex-row gap-3 pt-2">
          <?php if (!$post->boat_sold) : ?>
            <a href="<?php echo home_url(); ?>/my-boat-quotes/"
              data-postid="<?php echo get_the_id(); ?>"
              class="mbq-link w-full text-center bg-[#ff9101] hover:bg-[#e07f00] text-white font-black px-8 py-4 text-base uppercase tracking-[0.2em] transition-all duration-200">
              Quote This Boat
            </a>
          <?php else : ?>
            <div class="w-full text-center bg-red-600 text-white font-black px-8 py-4 text-base uppercase tracking-[0.2em] cursor-not-allowed opacity-50">
              SOLD - Not Available
            </div>
          <?php endif; ?>
          <a href="<?php echo home_url(); ?>/contact/"
            class="w-full text-center bg-gray-900 hover:bg-gray-700 text-white font-bold px-8 py-4 text-base uppercase tracking-[0.2em] transition-all duration-200">
            Contact Us
          </a>
        </div>

      </div>
      <!-- END details -->
      
    </div>
  </div>
</div>


<!-- ===== TABS ===== -->
<?php if (!empty($bsp_tabs) || $post->boat_optequip) : ?>
<div class="bg-white border-t border-gray-100">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <!-- Tab buttons -->
    <div class="flex flex-wrap gap-0 border-b border-gray-200" id="bsp-tab-bar">
      <?php foreach ($bsp_tabs as $bsp_ti => $bsp_tab) : ?>
        <button
          onclick="bspShowTab('<?php echo $bsp_tab['id']; ?>')"
          id="<?php echo $bsp_tab['id']; ?>-btn"
          class="bsp-tab-btn px-6 py-4 text-base font-bold uppercase tracking-widest border-b-2 transition-all duration-150
            <?php echo $bsp_ti === 0 ? 'border-[#ff9101] text-[#ff9101]' : 'border-transparent text-gray-400 hover:text-gray-700'; ?>">
          <?php echo $bsp_tab['label']; ?>
        </button>
      <?php endforeach; ?>
      <?php if ($post->boat_optequip) : ?>
        <button
          onclick="bspShowTab('bsp-tab-optequip')"
          id="bsp-tab-optequip-btn"
          class="bsp-tab-btn px-6 py-4 text-base font-bold uppercase tracking-widest border-b-2 border-transparent text-gray-400 hover:text-gray-700 transition-all duration-150 <?php echo empty($bsp_tabs) ? 'border-[#ff9101] text-[#ff9101]' : ''; ?>">
          Optional Equipment
        </button>
      <?php endif; ?>
    </div>

    <!-- Tab panels -->
    <div class="py-10">

      <?php foreach ($bsp_tabs as $bsp_ti => $bsp_tab) : ?>
        <div id="<?php echo $bsp_tab['id']; ?>" class="bsp-tab-panel <?php echo $bsp_ti !== 0 ? 'hidden' : ''; ?>">
          <ul class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            <?php
            $bsp_items = array_filter(explode("\n", str_replace("\r", "", trim($bsp_tab['content'], "\n\r"))));
            foreach ($bsp_items as $bsp_item) :
              if (trim($bsp_item) === '') continue;
            ?>
            <li class="flex items-start gap-3 bg-gray-50 rounded-sm px-4 py-3">
              <svg class="w-4 h-4 text-[#ff9101] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
              </svg>
              <span class="text-gray-700 text-base leading-relaxed"><?php echo esc_html(trim($bsp_item)); ?></span>
            </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endforeach; ?>

      <?php if ($post->boat_optequip) : ?>
        <div id="bsp-tab-optequip" class="bsp-tab-panel <?php echo !empty($bsp_tabs) ? 'hidden' : ''; ?>">
          <div class="prose prose-gray max-w-none text-gray-600">
            <?php echo apply_filters('the_content', $post->boat_optequip); ?>
          </div>
        </div>
      <?php endif; ?>

    </div>
  </div>
</div>
<?php endif; ?>


<!-- ===== RELATED BOATS ===== -->
<div class="bg-[#f7f7f7] border-t border-gray-200 py-16">
  <div class="max-w-screen-2xl mx-auto px-6 md:px-14">

    <div class="flex items-center gap-3 mb-10">
      <span class="block w-8 h-[2px] bg-[#ff9101]"></span>
      <h2 class="text-gray-900 font-black text-2xl uppercase tracking-widest">You May Also Like</h2>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
      <?php
      $bsp_make     = get_the_terms($post->ID, 'make');
      $bsp_this_id  = $post->ID;

      $bsp_rargs = array(
        'post_type'      => 'boats',
        'posts_per_page' => 4,
        'post__not_in'   => array($bsp_this_id),
        'meta_query'     => array(array('key' => 'boat_length', 'value' => $post->boat_length))
      );
      $bsp_related = new WP_Query($bsp_rargs);

      if ($bsp_related->have_posts()) :
        while ($bsp_related->have_posts()) : $bsp_related->the_post();
          $bsp_r_img   = (!empty($post->boat_images['image'][0])) ? $post->boat_images['image'][0] : '';
          $bsp_r_make  = has_term('', 'make') ? get_the_terms($post->ID, 'make') : array();
          $bsp_r_mname = (!empty($bsp_r_make) && !is_wp_error($bsp_r_make)) ? $bsp_r_make[0]->name : '';
      ?>
          <a href="<?php the_permalink(); ?>"
            class="group bg-white rounded-md overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col">
            <div class="relative overflow-hidden bg-gray-100" style="padding-top: 62%;">
              <?php if ($bsp_r_img) : ?>
                <img src="<?php echo esc_url($bsp_r_img); ?>"
                  alt="<?php the_title_attribute(); ?>"
                  class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
              <?php else : ?>
                <div class="absolute inset-0 bg-gray-100 flex items-center justify-center">
                  <svg class="w-10 h-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                  </svg>
                </div>
              <?php endif; ?>
            </div>
            <div class="p-4 flex flex-col flex-1">
              <?php if ($bsp_r_mname) : ?>
                <p class="text-[#ff9101] text-[11px] font-bold uppercase tracking-widest mb-1"><?php echo esc_html($bsp_r_mname); ?></p>
              <?php endif; ?>
              <h3 class="text-gray-900 font-black text-md leading-snug group-hover:text-[#ff9101] transition-colors duration-150">
                <?php the_title(); ?>
              </h3>
            </div>
          </a>
      <?php
        endwhile;
      endif;

      // Fill remaining slots with same-make boats
      if ($bsp_related->found_posts < 4 && !empty($bsp_make)) {
        $bsp_used = array_merge(wp_list_pluck($bsp_related->posts, 'ID'), array($bsp_this_id));
        $bsp_rargs2 = array(
          'post_type'      => 'boats',
          'posts_per_page' => 4 - $bsp_related->found_posts,
          'post__not_in'   => $bsp_used,
          'tax_query'      => array(array('taxonomy' => 'make', 'field' => 'slug', 'terms' => $bsp_make[0]->slug))
        );
        $bsp_related2 = new WP_Query($bsp_rargs2);
        if ($bsp_related2->have_posts()) :
          while ($bsp_related2->have_posts()) : $bsp_related2->the_post();
            $bsp_r2_img   = (!empty($post->boat_images['image'][0])) ? $post->boat_images['image'][0] : '';
            $bsp_r2_make  = has_term('', 'make') ? get_the_terms($post->ID, 'make') : array();
            $bsp_r2_mname = (!empty($bsp_r2_make) && !is_wp_error($bsp_r2_make)) ? $bsp_r2_make[0]->name : '';
        ?>
            <a href="<?php the_permalink(); ?>"
              class="group bg-white rounded-md overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col">
              <div class="relative overflow-hidden bg-gray-100" style="padding-top: 62%;">
                <?php if ($bsp_r2_img) : ?>
                  <img src="<?php echo esc_url($bsp_r2_img); ?>"
                    alt="<?php the_title_attribute(); ?>"
                    class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                <?php else : ?>
                  <div class="absolute inset-0 bg-gray-100 flex items-center justify-center">
                    <svg class="w-10 h-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                  </div>
                <?php endif; ?>
              </div>
              <div class="p-4 flex flex-col flex-1">
                <?php if ($bsp_r2_mname) : ?>
                  <p class="text-[#ff9101] text-[11px] font-bold uppercase tracking-widest mb-1"><?php echo esc_html($bsp_r2_mname); ?></p>
                <?php endif; ?>
                <h3 class="text-gray-900 font-black text-md leading-snug group-hover:text-[#ff9101] transition-colors duration-150">
                  <?php the_title(); ?>
                </h3>
              </div>
            </a>
        <?php
          endwhile;
        endif;
      }

      wp_reset_postdata();
      ?>
    </div>

  </div>
</div>


<!-- ===== CTA BAND ===== -->
<div class="bg-[#032972] py-14 relative overflow-hidden">
  <div class="absolute inset-0 opacity-[0.06]"
   ></div>
  <div class="relative z-10 max-w-screen-2xl mx-auto px-6 md:px-14 flex flex-col sm:flex-row items-center justify-between gap-6">
    <p class="text-white font-black text-2xl md:text-3xl">Ready to get out on the water?</p>
    <a href="<?php echo home_url(); ?>/contact/"
      class="flex-shrink-0 inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-[#ff9101] font-black px-8 py-4 text-base uppercase tracking-[0.2em] transition-all duration-200">
      Contact Us
      <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
      </svg>
    </a>
  </div>
</div>


<script>
function bspShowTab(id) {
  document.querySelectorAll('.bsp-tab-panel').forEach(function(p) { p.classList.add('hidden'); });
  document.querySelectorAll('.bsp-tab-btn').forEach(function(b) {
    b.classList.remove('border-[#ff9101]', 'text-[#ff9101]');
    b.classList.add('border-transparent', 'text-gray-400');
  });
  document.getElementById(id).classList.remove('hidden');
  var btn = document.getElementById(id + '-btn');
  btn.classList.add('border-[#ff9101]', 'text-[#ff9101]');
  btn.classList.remove('border-transparent', 'text-gray-400');
}

function bspOpenVideo(videoId) {
  var modal = document.getElementById('bsp-video-modal');
  var iframe = document.getElementById('bsp-yt-iframe');
  iframe.src = 'https://www.youtube.com/embed/' + videoId + '?autoplay=1&rel=0';
  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function bspCloseVideoBtn() {
  var modal = document.getElementById('bsp-video-modal');
  var iframe = document.getElementById('bsp-yt-iframe');
  iframe.src = '';
  modal.classList.add('hidden');
  document.body.style.overflow = '';
}

function bspCloseVideo(e) {
  // Only close if clicking the backdrop itself, not the video
  if (e.target === document.getElementById('bsp-video-modal')) {
    bspCloseVideoBtn();
  }
}

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') bspCloseVideoBtn();
});

</script>
<?php if (!empty($post->boat_video)) : ?>
<!-- ===== VIDEO MODAL ===== -->
<div id="bsp-video-modal"
  class="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-sm hidden"
  onclick="bspCloseVideo(event)">
  <div class="relative w-full max-w-4xl mx-4">
    <button
      onclick="bspCloseVideoBtn()"
      class="absolute -top-10 right-0 text-white/70 hover:text-white font-bold uppercase tracking-widest text-xs flex items-center gap-2 transition-colors">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
      </svg>
      Close
    </button>
    <div class="relative w-full rounded-md overflow-hidden shadow-2xl" style="padding-top: 56.25%;">
      <iframe
        id="bsp-yt-iframe"
        class="absolute inset-0 w-full h-full"
        frameborder="0"
        allow="autoplay; encrypted-media"
        allowfullscreen>
      </iframe>
    </div>
  </div>
</div>

<?php endif; ?>

<?php endwhile; ?>
<?php get_footer(); ?>
